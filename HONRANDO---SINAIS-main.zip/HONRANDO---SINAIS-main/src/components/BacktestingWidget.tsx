import React, { useState, useRef } from 'react';
import { Play, Calendar, Activity, Rocket, Cpu, UploadCloud, FileText } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import Papa from 'papaparse';
import { cn } from '../lib/utils.js';

export function BacktestingWidget() {
  const [strategy, setStrategy] = useState('BREAKOUT');
  const [isSimulating, setIsSimulating] = useState(false);
  const [results, setResults] = useState<any>(null);
  
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);
  
  const [riskDailyLimit, setRiskDailyLimit] = useState<number>(50);
  const [riskMaxDrawdown, setRiskMaxDrawdown] = useState<number>(10);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      Papa.parse(selectedFile, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          setCsvData(results.data);
        }
      });
    }
  };

  const handleRun = () => {
    if (!file || csvData.length === 0) {
      alert("Por favor, faça o upload de um arquivo CSV do histórico do TradingView ou semelhante.");
      return;
    }
    
    setIsSimulating(true);
    setResults(null);
    
    // Simulate backtest based on CSV and current Risk params
    setTimeout(() => {
        let currentBalance = 10000; // Starting capital
        let peak = 10000;
        let maxDrawdown = 0;
        let wins = 0;
        let losses = 0;
        
        let dailyPnl = 0;
        let previousDate = '';
        
        const chartData = [];
        let tradesExecuted = 0;
        
        // Very basic mock simulation over the CSV length.
        // In a real scenario, this would interpret "Close", "Open", etc. from TV CSV.
        for (let i = 0; i < csvData.length; i++) {
           const row = csvData[i];
           // Extract some sort of random outcome based on data to mock strategy 
           // since we don't have a real strategy engine on client side.
           // A real backtester would process price data to calculate signals.
           
           tradesExecuted++;
           
           // Mock logic based on strategy setting
           const isWin = Math.random() > (strategy === 'REVERSAL' ? 0.55 : 0.45);
           let pnl = 0;
           
           // Check if daily loss limit was hit previously
           const currentDate = row.time ? row.time.split('T')[0] : `Day-${Math.floor(i/10)}`;
           if (currentDate !== previousDate) {
              dailyPnl = 0; // reset daily
              previousDate = currentDate;
           }
           
           if (dailyPnl <= -riskDailyLimit) {
               // Skipped trade due to risk management
               continue; 
           }

           if (isWin) {
               pnl = Math.random() * (strategy === 'TREND' ? 200 : 100) + 10; 
               wins++;
           } else {
               pnl = -(Math.random() * 80 + 10); 
               losses++;
           }
           
           dailyPnl += pnl;
           currentBalance += pnl;
           
           if (currentBalance > peak) peak = currentBalance;
           
           const peakBalance = peak;
           const ddPct = ((peakBalance - currentBalance) / peakBalance) * 100;
           
           if (ddPct > maxDrawdown) maxDrawdown = ddPct;
           
           // Stop simulation if Max Drawdown threshold hit (Margin call)
           if (ddPct >= riskMaxDrawdown) {
               chartData.push({
                   index: i,
                   balance: currentBalance,
               });
               break; 
           }
           
           // Record interval
           if (i % Math.max(1, Math.floor(csvData.length / 50)) === 0) {
               chartData.push({
                   index: i,
                   balance: currentBalance,
               });
           }
        }
        
        const netProfit = currentBalance - 10000;
        const winRate = tradesExecuted > 0 ? (wins / tradesExecuted) * 100 : 0;
        
        setResults({
            netProfit,
            maxDrawdown,
            winRate,
            numTrades: tradesExecuted,
            chartData,
            endingBalance: currentBalance,
            survived: maxDrawdown < riskMaxDrawdown
        });
        
        setIsSimulating(false);
    }, 2000);
  };

  return (
    <div className="bg-[#111326] border border-fuchsia-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6 mt-6 mb-6">
       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-700/50">
          <div className="flex items-center gap-3 flex-wrap">
             <Cpu className="w-5 h-5 text-fuchsia-500 drop-shadow-[0_0_5px_rgba(217,70,239,0.5)]" />
             <h2 className="text-lg font-black text-white tracking-widest uppercase">LABORATÓRIO DE BACKTESTING (CSV)</h2>
             <span className="bg-[#050510] text-fuchsia-400 border border-fuchsia-500/30 px-3 py-1 rounded-full text-[10px] font-black tracking-widest">VALIDADOR DE RISCO</span>
          </div>
       </div>
       
       <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Config Panel */}
          <div className="lg:col-span-1 bg-[#0A0C16] border border-slate-800 p-5 rounded-xl shadow-inner shadow-black/50 flex flex-col gap-4">
             <h3 className="text-slate-400 font-bold text-xs tracking-widest uppercase mb-2 border-b border-slate-800 pb-2">DADOS & PARÂMETROS</h3>
             
             <div className="flex flex-col gap-2">
                 <label className="text-[10px] text-slate-500 font-bold tracking-widest uppercase flex items-center justify-between">
                   DADOS HISTÓRICOS (TV) 
                   {file && <span className="text-cyan-400">✓ {csvData.length} li.</span>}
                 </label>
                 
                 <input 
                    type="file" 
                    accept=".csv"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                 />
                 <button 
                   onClick={() => fileInputRef.current?.click()}
                   className={cn(
                     "w-full flex items-center gap-2 justify-center py-3 rounded-lg border border-dashed transition-all text-xs font-mono tracking-widest",
                     file 
                       ? "border-cyan-500/50 bg-cyan-900/20 text-cyan-400" 
                       : "border-slate-700 hover:border-fuchsia-500/50 hover:bg-fuchsia-900/10 text-slate-400"
                   )}
                 >
                   {file ? <FileText className="w-4 h-4" /> : <UploadCloud className="w-4 h-4" />}
                   {file ? file.name.substring(0, 15) + '...' : 'UPLOAD CSV'}
                 </button>
             </div>
             
             <div className="flex flex-col gap-1 mt-2">
                 <label className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">LIMITE PERDA DIÁRIA ($)</label>
                 <input 
                    type="number"
                    value={riskDailyLimit}
                    onChange={(e) => setRiskDailyLimit(Number(e.target.value))}
                    className="bg-[#050510] border border-fuchsia-900 focus:border-fuchsia-500 rounded-lg px-3 py-2 text-[10px] font-bold text-slate-300 tracking-widest uppercase outline-none transition-colors font-mono w-full"
                 />
             </div>
             
             <div className="flex flex-col gap-1">
                 <label className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">DRAWDOWN MÁXIMO (%)</label>
                 <input 
                    type="number"
                    value={riskMaxDrawdown}
                    onChange={(e) => setRiskMaxDrawdown(Number(e.target.value))}
                    className="bg-[#050510] border border-fuchsia-900 focus:border-fuchsia-500 rounded-lg px-3 py-2 text-[10px] font-bold text-slate-300 tracking-widest uppercase outline-none transition-colors font-mono w-full"
                 />
             </div>
             
             <div className="flex flex-col gap-1">
                 <label className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">ALGORITMO</label>
                 <select 
                    value={strategy}
                    onChange={(e) => setStrategy(e.target.value)}
                    className="bg-[#050510] border border-fuchsia-900 focus:border-fuchsia-500 rounded-lg px-3 py-2 text-[10px] font-bold text-fuchsia-400 tracking-widest outline-none transition-colors font-mono w-full appearance-none"
                 >
                    <option value="BREAKOUT">QUANT: BREAKOUT (FLUXO)</option>
                    <option value="REVERSAL">QUANT: REVERSÃO À MÉDIA</option>
                    <option value="TREND">TREND FOLLOWING (MACRO)</option>
                 </select>
             </div>
             
             <button
                 onClick={handleRun}
                 disabled={isSimulating || !file}
                 className={cn("mt-4 text-[10px] font-black tracking-widest uppercase px-4 py-3 rounded-lg flex items-center justify-center gap-2 transition-all w-full", isSimulating || !file ? "bg-slate-800 text-slate-500 cursor-not-allowed" : "bg-fuchsia-600 hover:bg-fuchsia-500 text-black shadow-[0_0_15px_rgba(217,70,239,0.3)] hover:shadow-[0_0_25px_rgba(217,70,239,0.5)]")}
             >
                 {isSimulating ? (
                     <><Activity className="w-4 h-4 animate-spin" /> EXECUTANDO...</>
                 ) : (
                     <><Rocket className="w-4 h-4" /> TESTAR ESTRATÉGIA</>
                 )}
             </button>
          </div>
          
          {/* Results Panel */}
          <div className="lg:col-span-3 bg-[#0A0C16] border border-slate-800 p-5 rounded-xl shadow-inner shadow-black/50 flex flex-col relative min-h-[350px]">
             {isSimulating ? (
                 <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#0A0C16]/80 backdrop-blur-sm z-10 rounded-xl">
                    <div className="w-16 h-16 border-4 border-slate-800 border-t-fuchsia-500 rounded-full animate-spin shadow-[0_0_15px_rgba(217,70,239,0.5)]"></div>
                    <div className="text-fuchsia-400 font-mono tracking-widest text-[10px] animate-pulse text-center px-4">
                      COMPILANDO {csvData.length} CANDLES... <br/>
                      APLICANDO REGRAS DE REDUÇÃO DE CARGA E META DIÁRIA
                    </div>
                 </div>
             ) : null}
             
             {!results && !isSimulating && (
                 <div className="flex-1 flex flex-col items-center justify-center text-slate-600 gap-4">
                     <Cpu className="w-12 h-12 opacity-20" />
                     <p className="font-mono tracking-widest text-[10px] text-center max-w-md">
                        FAÇA UPLOAD DO ARQUIVO CSV COM OS DADOS HISTÓRICOS. O SISTEMA IRÁ REPRODUZIR AS ENTRADAS APLICANDO SEUS LIMITES ATUAIS PARA GARANTIR A SOBREVIVÊNCIA DO SETUP A LONGO PRAZO.
                     </p>
                 </div>
             )}
             
             {results && (
                 <div className="flex flex-col h-full gap-6 animate-in fade-in duration-700">
                     <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <h3 className="text-slate-400 font-bold text-[10px] tracking-widest uppercase">RESULTADO DA SIMULAÇÃO</h3>
                        {results.survived ? (
                          <span className="text-[10px] font-black text-cyan-400 tracking-widest bg-cyan-900/30 px-2 py-0.5 rounded border border-cyan-500/50 uppercase">✅ SETUP APROVADO</span>
                        ) : (
                          <span className="text-[10px] font-black text-rose-500 tracking-widest bg-rose-900/30 px-2 py-0.5 rounded border border-rose-500/50 uppercase">💀 QUEBROU A BANCA</span>
                        )}
                     </div>
                     
                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-[#050510] border border-slate-800 p-4 rounded-lg flex flex-col items-center justify-center shadow-md">
                           <span className="text-[9px] text-slate-500 font-bold tracking-widest uppercase mb-1">PROFIT LÍQUIDO</span>
                           <span className={cn("text-xl font-black", results.netProfit >= 0 ? "text-[#00FFA3]" : "text-rose-500")}>
                               {results.netProfit >= 0 ? "+" : ""}${results.netProfit.toFixed(2)}
                           </span>
                        </div>
                        <div className="bg-[#050510] border border-slate-800 p-4 rounded-lg flex flex-col items-center justify-center shadow-md">
                           <span className="text-[9px] text-slate-500 font-bold tracking-widest uppercase mb-1">MAX DRAWDOWN SOFRIDO</span>
                           <span className={cn("text-xl font-black border-b", results.survived ? "text-amber-500 border-amber-500/30" : "text-rose-500 border-rose-500/30")}>
                               -{results.maxDrawdown.toFixed(2)}%
                           </span>
                        </div>
                        <div className="bg-[#050510] border border-slate-800 p-4 rounded-lg flex flex-col items-center justify-center shadow-md">
                           <span className="text-[9px] text-slate-500 font-bold tracking-widest uppercase mb-1">WIN RATE</span>
                           <span className={cn("text-xl font-black", results.winRate >= 50 ? "text-cyan-400" : "text-amber-500")}>
                               {results.winRate.toFixed(1)}%
                           </span>
                        </div>
                        <div className="bg-[#050510] border border-slate-800 p-4 rounded-lg flex flex-col items-center justify-center shadow-md">
                           <span className="text-[9px] text-slate-500 font-bold tracking-widest uppercase mb-1">TRADES EXECUTADOS</span>
                           <span className="text-xl font-black text-fuchsia-400">
                               {results.numTrades}
                           </span>
                        </div>
                     </div>
                     
                     <div className="flex-1 w-full min-h-[200px]">
                         <h3 className="text-slate-500 font-bold text-[9px] tracking-widest uppercase mb-2">CURVA DE CAPITAL ($10K INICIAL)</h3>
                         <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={results.chartData} margin={{ top: 5, right: 0, bottom: 5, left: -20 }}>
                               <defs>
                                  <linearGradient id="colorBtBalance" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={results.netProfit >= 0 ? '#00FFA3' : '#f43f5e'} stopOpacity={0.4}/>
                                    <stop offset="95%" stopColor={results.netProfit >= 0 ? '#00FFA3' : '#f43f5e'} stopOpacity={0}/>
                                  </linearGradient>
                               </defs>
                               <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                               <XAxis dataKey="index" hide />
                               <YAxis tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} domain={['auto', 'auto']} />
                               <Tooltip 
                                  contentStyle={{ backgroundColor: '#0B0C1A', borderColor: '#334155', borderRadius: '8px' }}
                                  itemStyle={{ fontWeight: 'bold' }}
                                  formatter={(val: number) => [`$${val.toFixed(2)}`, 'Saldo Simulador']}
                                  labelFormatter={() => ''}
                               />
                               <Area type="monotone" dataKey="balance" stroke={results.netProfit >= 0 ? '#00FFA3' : '#f43f5e'} strokeWidth={2} fillOpacity={1} fill="url(#colorBtBalance)" />
                            </AreaChart>
                         </ResponsiveContainer>
                     </div>
                 </div>
             )}
          </div>
       </div>
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import { Trade } from '../types.js';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from 'recharts';
import { cn } from '../lib/utils.js';
import { Info } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#050510]/95 border border-cyan-500/30 rounded-xl p-4 shadow-[0_0_15px_rgba(34,211,238,0.15)] flex flex-col gap-2 backdrop-blur-md">
        <p className="text-[10px] text-cyan-400 font-mono tracking-widest uppercase border-b border-cyan-500/20 pb-2 mb-1 drop-shadow-[0_0_5px_rgba(34,211,238,0.4)]">
           DATA: {label}
        </p>
        <div className="flex flex-col gap-1.5 pt-1">
           {payload.map((entry: any, index: number) => {
              const isPositive = entry.value >= 0;
              return (
                <div key={index} className="flex items-center justify-between gap-8">
                   <span className="text-[10px] font-bold tracking-widest uppercase flex items-center gap-2 drop-shadow-sm" style={{ color: entry.color }}>
                      <div className="w-1.5 h-1.5 rounded-full shadow-sm" style={{ backgroundColor: entry.color, boxShadow: `0 0 5px ${entry.color}` }} />
                      {entry.name}
                   </span>
                   <span className={cn("text-[11px] font-mono tracking-widest font-black", isPositive ? "text-[#00FFA3] drop-shadow-[0_0_3px_rgba(0,255,163,0.5)]" : "text-rose-500 drop-shadow-[0_0_3px_rgba(244,63,94,0.5)]")}>
                      {isPositive ? '+' : '-'}${Math.abs(entry.value).toFixed(2)}
                   </span>
                </div>
              );
           })}
        </div>
      </div>
    );
  }
  return null;
};

export function StatsView({ history }: { history: Trade[] }) {
  const [activeChartType, setActiveChartType] = useState<'cumulative'|'daily'|'winrate'>('cumulative');
  const [period, setPeriod] = useState<number | 'all'>(7);
  const [coinFilter, setCoinFilter] = useState('');
  const [showSimuA, setShowSimuA] = useState(true);
  const [showSimuB, setShowSimuB] = useState(true);
  const [showHeatmapInfo, setShowHeatmapInfo] = useState(false);

  const dailyData = useMemo(() => {
    const grouped: Record<string, { simuA: number; simuB: number; winA: number; lossA: number; winB: number; lossB: number; }> = {};
    const now = Date.now();
    
    // Reverse to process chronologically if we want, but history is reverse chronological.
    // It depends on tsIn
    const sorted = [...history].filter(t => {
      if (t.est !== 'SIMU' && t.est !== 'SIMU_B') return false;
      if (period !== 'all' && t.tsIn < now - period * 24 * 60 * 60 * 1000) return false;
      if (coinFilter.trim() !== '' && !t.symbol.toUpperCase().includes(coinFilter.trim().toUpperCase())) return false;
      return true;
    }).sort((a, b) => a.tsIn - b.tsIn);

    sorted.forEach(t => {
       const dateStr = new Date(t.tsIn).toLocaleDateString('pt-BR');
       if (!grouped[dateStr]) {
          grouped[dateStr] = { simuA: 0, simuB: 0, winA: 0, lossA: 0, winB: 0, lossB: 0 };
       }
       if (t.est === 'SIMU') {
          grouped[dateStr].simuA += t.pnl;
          if (t.roi > 0) grouped[dateStr].winA++;
          else if (t.roi < 0) grouped[dateStr].lossA++;
       }
       if (t.est === 'SIMU_B') {
          grouped[dateStr].simuB += t.pnl;
          if (t.roi > 0) grouped[dateStr].winB++;
          else if (t.roi < 0) grouped[dateStr].lossB++;
       }
    });

    return Object.keys(grouped).map(date => {
       return {
          date,
          simuA: Number(grouped[date].simuA.toFixed(2)),
          simuB: Number(grouped[date].simuB.toFixed(2)),
          winA: grouped[date].winA,
          lossA: grouped[date].lossA,
          winB: grouped[date].winB,
          lossB: grouped[date].lossB
       };
    });
  }, [history, period, coinFilter]);

  const cumulativeData = useMemo(() => {
    let sumA = 0;
    let sumB = 0;
    let totalWinA = 0;
    let totalLossA = 0;
    let totalWinB = 0;
    let totalLossB = 0;
    
    return dailyData.map(day => {
       sumA += day.simuA;
       sumB += day.simuB;
       totalWinA += day.winA;
       totalLossA += day.lossA;
       totalWinB += day.winB;
       totalLossB += day.lossB;

       const totA = totalWinA + totalLossA;
       const totB = totalWinB + totalLossB;

       return {
          date: day.date,
          simuA: Number(sumA.toFixed(2)),
          simuB: Number(sumB.toFixed(2)),
          winRateA: totA > 0 ? Number(((totalWinA / totA) * 100).toFixed(1)) : 0,
          winRateB: totB > 0 ? Number(((totalWinB / totB) * 100).toFixed(1)) : 0
       };
    });
  }, [dailyData]);

  const heatmapData = useMemo(() => {
    const grid = Array.from({ length: 7 }, () => Array.from({ length: 24 }, () => 0));
    let maxCount = 0;
    const now = Date.now();

    history.forEach(t => {
      if (t.est !== 'SIMU' && t.est !== 'SIMU_B') return;
      if (period !== 'all' && t.tsIn < now - period * 24 * 60 * 60 * 1000) return;
      if (coinFilter.trim() !== '' && !t.symbol.toUpperCase().includes(coinFilter.trim().toUpperCase())) return;
      if (!showSimuA && t.est === 'SIMU') return;
      if (!showSimuB && t.est === 'SIMU_B') return;

      const d = new Date(t.tsIn);
      const day = d.getDay();
      const hour = d.getHours();
      grid[day][hour]++;
      if (grid[day][hour] > maxCount) maxCount = grid[day][hour];
    });

    return { grid, maxCount: maxCount || 1 };
  }, [history, period, coinFilter, showSimuA, showSimuB]);

  const calendarHeatmap = useMemo(() => {
    let startTs = Date.now();
    let endTs = Date.now();
    
    if (period === 'all') {
       if (history.length > 0) {
          const oldest = Math.min(...history.map(t => t.tsIn));
          startTs = oldest;
       } else {
          startTs = Date.now() - 30 * 24 * 60 * 60 * 1000;
       }
    } else {
       startTs = Date.now() - (period as number) * 24 * 60 * 60 * 1000;
    }

    const start = new Date(startTs);
    start.setHours(0,0,0,0);
    const end = new Date(endTs);
    end.setHours(23,59,59,999);

    // Adjust start to the previous Sunday
    start.setDate(start.getDate() - start.getDay());
    
    // Adjust end to the next Saturday
    end.setDate(end.getDate() + (6 - end.getDay()));

    const weeks: { date: Date, dateStr: string, pnl: number }[][] = [];
    const daysMap: Record<string, number> = {};
    let maxAbsPnl = 0;
    
    history.forEach(t => {
      if (t.est !== 'SIMU' && t.est !== 'SIMU_B') return;
      if (period !== 'all' && t.tsIn < Date.now() - (period as number) * 24 * 60 * 60 * 1000) return;
      if (coinFilter.trim() !== '' && !t.symbol.toUpperCase().includes(coinFilter.trim().toUpperCase())) return;
      if (!showSimuA && t.est === 'SIMU') return;
      if (!showSimuB && t.est === 'SIMU_B') return;

      const d = new Date(t.tsIn);
      const dateStr = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      if (!daysMap[dateStr]) daysMap[dateStr] = 0;
      daysMap[dateStr] += t.pnl;
    });

    Object.values(daysMap).forEach(pnl => {
      if (Math.abs(pnl) > maxAbsPnl) maxAbsPnl = Math.abs(pnl);
    });

    let current = new Date(start);
    let currentWeek: any[] = [];
    while (current <= end) {
       const dateStr = current.getFullYear() + '-' + String(current.getMonth()+1).padStart(2, '0') + '-' + String(current.getDate()).padStart(2, '0');
       currentWeek.push({
          date: new Date(current),
          dateStr,
          pnl: daysMap[dateStr] || 0,
       });

       if (currentWeek.length === 7) {
          weeks.push(currentWeek);
          currentWeek = [];
       }
       current.setDate(current.getDate() + 1);
    }

    return { weeks, maxAbsPnl: maxAbsPnl || 1 };
  }, [history, period, coinFilter, showSimuA, showSimuB]);

  const daysOfWeek = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'];

  return (
    <div className="flex flex-col gap-6 w-full max-w-6xl mx-auto h-full text-slate-300 overflow-y-auto pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-widest uppercase mb-1">ESTATÍSTICAS</h1>
          <p className="text-xs text-slate-400 font-mono tracking-widest uppercase">DESEMPENHO DIÁRIO DOS SIMULADORES</p>
        </div>
        
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
           {/* STRATEGY FILTER */}
           <div className="flex items-center gap-4 bg-[#050510] border border-slate-800 rounded-lg p-1.5 px-4 h-[34px] w-full md:w-auto overflow-x-auto shrink-0">
              <label className="flex items-center gap-2 cursor-pointer" onClick={() => setShowSimuA(!showSimuA)}>
                 <div className={cn("w-3.5 h-3.5 rounded flex items-center justify-center border transition-colors shrink-0", showSimuA ? "bg-cyan-400 border-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.3)]" : "border-slate-600 bg-transparent")}>
                    {showSimuA && <div className="w-1.5 h-1.5 bg-black rounded-[2px]" />}
                 </div>
                 <span className={cn("text-[10px] font-bold tracking-widest uppercase transition-colors whitespace-nowrap", showSimuA ? "text-cyan-400" : "text-slate-500")}>TESTE A</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer" onClick={() => setShowSimuB(!showSimuB)}>
                 <div className={cn("w-3.5 h-3.5 rounded flex items-center justify-center border transition-colors shrink-0", showSimuB ? "bg-[#a855f7] border-[#a855f7] shadow-[0_0_8px_rgba(168,85,247,0.3)]" : "border-slate-600 bg-transparent")}>
                    {showSimuB && <div className="w-1.5 h-1.5 bg-black rounded-[2px]" />}
                 </div>
                 <span className={cn("text-[10px] font-bold tracking-widest uppercase transition-colors whitespace-nowrap", showSimuB ? "text-[#a855f7]" : "text-slate-500")}>TESTE B</span>
              </label>
           </div>

           {/* COIN FILTER */}
           <div className="flex flex-col gap-1 w-full md:w-auto">
              <input 
                 type="text" 
                 value={coinFilter}
                 onChange={(e) => setCoinFilter(e.target.value.toUpperCase())}
                 placeholder="MOEDA (EX: BTC)"
                 className="bg-[#050510] border border-slate-800 hover:border-slate-600 focus:border-cyan-500 rounded-lg px-4 py-2 text-[10px] font-bold text-white tracking-widest uppercase focus:outline-none transition-colors w-full md:w-40 placeholder:text-slate-600 font-mono h-[34px]"
              />
           </div>

           <div className="flex items-center gap-2 bg-[#050510] border border-slate-800 rounded-lg p-1 w-full md:w-auto overflow-x-auto">
              <button 
                onClick={() => setPeriod(7)}
                className={cn("px-4 py-2 rounded-md text-[10px] font-black tracking-widest uppercase transition-colors shrink-0", period === 7 ? "bg-cyan-500 text-black shadow-[0_0_10px_rgba(34,211,238,0.3)]" : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/50")}
              >
                 7 Dias
              </button>
              <button 
                onClick={() => setPeriod(15)}
                className={cn("px-4 py-2 rounded-md text-[10px] font-black tracking-widest uppercase transition-colors shrink-0", period === 15 ? "bg-cyan-500 text-black shadow-[0_0_10px_rgba(34,211,238,0.3)]" : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/50")}
              >
                 15 Dias
              </button>
              <button 
                onClick={() => setPeriod(30)}
                className={cn("px-4 py-2 rounded-md text-[10px] font-black tracking-widest uppercase transition-colors shrink-0", period === 30 ? "bg-cyan-500 text-black shadow-[0_0_10px_rgba(34,211,238,0.3)]" : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/50")}
              >
                 30 Dias
              </button>
              <button 
                onClick={() => setPeriod('all')}
                className={cn("px-4 py-2 rounded-md text-[10px] font-black tracking-widest uppercase transition-colors shrink-0", period === 'all' ? "bg-cyan-500 text-black shadow-[0_0_10px_rgba(34,211,238,0.3)]" : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/50")}
              >
                 Todos
              </button>
           </div>
        </div>
      </div>

      <div className="bg-[#0B0C1A]/80 border border-slate-800 rounded-2xl p-6 shadow-xl h-[450px] flex flex-col">
         <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2 gap-4">
             <div className="flex items-center gap-4">
                 <select 
                     value={activeChartType}
                     onChange={(e) => setActiveChartType(e.target.value as any)}
                     className="bg-[#050510] border border-cyan-500/30 text-cyan-400 text-xs font-bold tracking-widest uppercase px-3 py-1.5 rounded-lg focus:outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                 >
                     <option value="cumulative">PNL ACUMULADO (US$)</option>
                     <option value="daily">PNL DIÁRIO (US$)</option>
                     <option value="winrate">TAXA DE SUCESSO (WIN RATE %)</option>
                 </select>
                 {activeChartType === 'cumulative' && (
                     <span title="Mostra o desempenho acumulado de cada estratégia ao longo do tempo."><Info className="w-4 h-4 text-slate-500 cursor-help" /></span>
                 )}
                 {activeChartType === 'daily' && (
                     <span title="Ganhos e perdas diários individuais para cada estratégia."><Info className="w-4 h-4 text-slate-500 cursor-help" /></span>
                 )}
                 {activeChartType === 'winrate' && (
                     <span title="Taxa de sucesso acumulada (% de vitórias) ao longo do tempo."><Info className="w-4 h-4 text-slate-500 cursor-help" /></span>
                 )}
             </div>
             
             <span className="text-[10px] font-mono text-slate-500 tracking-widest uppercase shrink-0 hidden md:inline-block">
                Período: {period === 'all' ? 'Todos os tempos' : `Últimos ${period} dias`}
             </span>
         </div>
         
         <div className="flex-1 w-full min-h-0">
             {activeChartType === 'daily' && (
                 dailyData.length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                     <BarChart data={dailyData} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
                       <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                       <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} dy={10} />
                       <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                       <Tooltip 
                         content={<CustomTooltip />}
                         cursor={{ fill: '#1e293b', opacity: 0.4 }}
                       />
                       <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '15px' }} />
                       {showSimuA && <Bar dataKey="simuA" name="Simulador A" fill="#22d3ee" radius={[4, 4, 0, 0]} barSize={30} />}
                       {showSimuB && <Bar dataKey="simuB" name="Simulador B" fill="#a855f7" radius={[4, 4, 0, 0]} barSize={30} />}
                     </BarChart>
                   </ResponsiveContainer>
                 ) : (
                    <div className="flex h-full items-center justify-center text-slate-500 font-mono text-xs italic">
                        Nenhum dado encontrado...
                    </div>
                 )
             )}
             
             {activeChartType === 'cumulative' && (
                 cumulativeData.length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                     <LineChart data={cumulativeData} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
                       <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                       <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} dy={10} />
                       <YAxis yAxisId="left" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                       <YAxis yAxisId="right" orientation="right" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                       <Tooltip 
                         content={<CustomTooltip />}
                         cursor={{ stroke: '#1e293b', strokeWidth: 2, opacity: 0.4 }}
                       />
                       <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '15px' }} />
                       {showSimuA && <Line yAxisId="left" type="monotone" dataKey="simuA" name="Simulador A (Eixo Esq.)" stroke="#22d3ee" strokeWidth={3} dot={{ r: 4, fill: '#050510', stroke: '#22d3ee', strokeWidth: 2 }} activeDot={{ r: 6, fill: '#22d3ee' }} />}
                       {showSimuB && <Line yAxisId="right" type="stepAfter" dataKey="simuB" name="Simulador B (Eixo Dir.)" stroke="#a855f7" strokeWidth={3} dot={{ r: 4, fill: '#050510', stroke: '#a855f7', strokeWidth: 2 }} activeDot={{ r: 6, fill: '#a855f7' }} />}
                     </LineChart>
                   </ResponsiveContainer>
                 ) : (
                    <div className="flex h-full items-center justify-center text-slate-500 font-mono text-xs italic">
                        Nenhum dado encontrado...
                    </div>
                 )
             )}
             
             {activeChartType === 'winrate' && (
                 cumulativeData.length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                     <LineChart data={cumulativeData} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
                       <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                       <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} dy={10} />
                       <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                       <Tooltip 
                         content={<CustomTooltip />}
                         cursor={{ stroke: '#1e293b', strokeWidth: 2, opacity: 0.4 }}
                       />
                       <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '15px' }} />
                       {showSimuA && <Line type="monotone" dataKey="winRateA" name="Taxa de Sucesso A (%)" stroke="#22d3ee" strokeWidth={3} dot={{ r: 4, fill: '#050510', stroke: '#22d3ee', strokeWidth: 2 }} activeDot={{ r: 6, fill: '#22d3ee' }} />}
                       {showSimuB && <Line type="monotone" dataKey="winRateB" name="Taxa de Sucesso B (%)" stroke="#a855f7" strokeWidth={3} dot={{ r: 4, fill: '#050510', stroke: '#a855f7', strokeWidth: 2 }} activeDot={{ r: 6, fill: '#a855f7' }} />}
                     </LineChart>
                   </ResponsiveContainer>
                 ) : (
                    <div className="flex h-full items-center justify-center text-slate-500 font-mono text-xs italic">
                        Nenhum dado encontrado...
                    </div>
                 )
             )}
         </div>
      </div>

      <div className="bg-[#0B0C1A]/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
         <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-3">
               <h3 className="text-slate-400 font-bold text-xs tracking-widest uppercase">⏱️ FREQUÊNCIA DE OPERAÇÕES (HORA/DIA)</h3>
               <button 
                  onClick={() => setShowHeatmapInfo(!showHeatmapInfo)}
                  className={cn("p-1.5 rounded-lg transition-colors border", showHeatmapInfo ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-400" : "bg-[#050510] border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-600")}
                  title="Como funciona?"
               >
                  <Info className="w-4 h-4" />
               </button>
            </div>
            <span className="text-[10px] font-mono text-cyan-500 tracking-widest uppercase hidden md:inline-block">
               Volume por {period === 'all' ? 'todos os tempos' : `últimos ${period} dias`}
            </span>
         </div>
         
         {showHeatmapInfo && (
            <div className="mb-6 bg-[#050510] border border-cyan-500/20 rounded-xl p-4 text-[11px] font-mono text-slate-400 leading-relaxed shadow-inner">
               <p className="font-bold text-cyan-400 tracking-widest uppercase mb-2">Como funciona o mapa de calor?</p>
               <ul className="list-disc list-inside space-y-1.5 ml-1">
                  <li>Este gráfico exibe o <strong>volume de operações</strong> realizadas segmentadas pelos dias da semana e pelas horas do dia.</li>
                  <li>As cores mais escuras indicam baixa frequência de operações, enquanto os tons mais vibrantes (ciano e verde claro) representam picos de alta atividade.</li>
                  <li>Use isso para identificar <strong>padrões de mercado</strong>: Quais horas do dia e quais dias a sua estratégia opera com mais frequência?</li>
                  <li>Os dados refletem o período, filtros de moeda e simuladores selecionados no topo da página.</li>
               </ul>
            </div>
         )}
         
         <div className="overflow-x-auto w-full">
            <div className="min-w-[800px]">
               <div className="flex mb-1 ml-10">
                  {Array.from({length: 24}).map((_, h) => (
                      <div key={h} className="flex-1 text-center text-[9px] text-slate-500 font-mono">{h.toString().padStart(2, '0')}h</div>
                  ))}
               </div>
               
               <div className="flex flex-col gap-1.5">
                  {daysOfWeek.map((day, dIdx) => (
                      <div key={day} className="flex items-center gap-2">
                         <div className="text-[9px] font-bold tracking-widest text-slate-500 w-8">{day}</div>
                         <div className="flex flex-1 gap-1">
                            {heatmapData.grid[dIdx].map((val, hIdx) => {
                               const intensity = val / heatmapData.maxCount; // 0 to 1
                               let bg = 'bg-slate-800/30';
                               let border = 'border-slate-800/50';
                               if (val > 0) {
                                  if (intensity <= 0.25) { bg = 'bg-cyan-900/40'; border = 'border-cyan-800/50'; }
                                  else if (intensity <= 0.5) { bg = 'bg-cyan-700/60'; border = 'border-cyan-600/50'; }
                                  else if (intensity <= 0.75) { bg = 'bg-cyan-500'; border = 'border-cyan-400'; }
                                  else { bg = 'bg-[#00FFA3]'; border = 'border-[#00FFA3] shadow-[0_0_8px_rgba(0,255,163,0.3)] z-10'; }
                               }
                               return (
                                  <div 
                                     key={hIdx} 
                                     className={cn("flex-1 h-6 rounded-sm border transition-all duration-300 relative group cursor-pointer", bg, border)}
                                  >
                                    <div className="absolute opacity-0 group-hover:opacity-100 transition-opacity -top-8 left-1/2 -translate-x-1/2 bg-black border border-cyan-500/30 text-cyan-400 text-[10px] py-1 px-2 rounded whitespace-nowrap z-20 pointer-events-none font-mono drop-shadow-[0_0_5px_rgba(34,211,238,0.3)] flex items-center gap-1.5">
                                      <span className="font-bold">{val}</span> OP(s)
                                    </div>
                                  </div>
                               );
                            })}
                         </div>
                      </div>
                  ))}
               </div>
               
               <div className="flex justify-end items-center gap-2 mt-4 ml-10">
                  <span className="text-[9px] font-mono text-slate-500">Menos Freq.</span>
                  <div className="flex gap-1">
                     <div className="w-4 h-4 rounded-sm border bg-slate-800/30 border-slate-800/50" />
                     <div className="w-4 h-4 rounded-sm border bg-cyan-900/40 border-cyan-800/50" />
                     <div className="w-4 h-4 rounded-sm border bg-cyan-700/60 border-cyan-600/50" />
                     <div className="w-4 h-4 rounded-sm border bg-cyan-500 border-cyan-400" />
                     <div className="w-4 h-4 rounded-sm border bg-[#00FFA3] border-[#00FFA3] shadow-[0_0_5px_rgba(0,255,163,0.3)]" />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500">Mais Freq.</span>
                </div>
             </div>
          </div>
       </div>

       {/* CALENDAR HEATMAP */}
       <div className="bg-[#0B0C1A]/80 border border-slate-800 rounded-2xl p-6 shadow-xl w-full relative z-0">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
             <div className="flex items-center gap-3">
                <h3 className="text-slate-400 font-bold text-xs tracking-widest uppercase">📅 MAPA DE CALOR PNL DIÁRIO (CALENDÁRIO)</h3>
             </div>
             <span className="text-[10px] font-mono text-cyan-500 tracking-widest uppercase hidden md:inline-block">
                Tons intensos indicam alta performance ou altas perdas
             </span>
          </div>
          
          <div className="overflow-x-auto w-full pb-4">
             <div className="min-w-max flex gap-1">
                <div className="flex flex-col gap-1 pr-2 pt-5">
                   {['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'].map((day, i) => (
                      <div key={day} className="h-3 md:h-4 flex items-center text-[9px] font-bold tracking-widest text-slate-500 leading-none">{day}</div>
                   ))}
                </div>

                <div className="flex gap-1">
                   {calendarHeatmap.weeks.map((week, wIdx) => {
                      const firstDay = week[0].date.getDate();
                      const isNewMonth = firstDay <= 7 && wIdx > 0;
                      
                      return (
                      <div key={wIdx} className="flex flex-col gap-1 relative group/week">
                         {(wIdx === 0 || isNewMonth) && (
                           <div className="absolute -top-5 left-0 text-[9px] font-bold tracking-widest text-slate-500 whitespace-nowrap">
                              {week[0].date.toLocaleString('pt-BR', { month: 'short' }).toUpperCase()}
                           </div>
                         )}

                         {week.map((day, dIdx) => {
                            const val = day.pnl;
                            const intensity = Math.abs(val) / calendarHeatmap.maxAbsPnl;
                            let bg = 'bg-slate-800/30';
                            let border = 'border-slate-800/50';

                            if (val > 0) {
                               if (intensity <= 0.25) { bg = 'bg-emerald-900/40'; border = 'border-emerald-800/50'; }
                               else if (intensity <= 0.5) { bg = 'bg-emerald-700/60'; border = 'border-emerald-600/50'; }
                               else if (intensity <= 0.75) { bg = 'bg-emerald-500'; border = 'border-emerald-400'; }
                               else { bg = 'bg-[#00FFA3]'; border = 'border-[#00FFA3] border shadow-[0_0_8px_rgba(0,255,163,0.3)] z-10'; }
                            } else if (val < 0) {
                               if (intensity <= 0.25) { bg = 'bg-rose-900/40'; border = 'border-rose-800/50'; }
                               else if (intensity <= 0.5) { bg = 'bg-rose-700/60'; border = 'border-rose-600/50'; }
                               else if (intensity <= 0.75) { bg = 'bg-rose-500'; border = 'border-rose-400'; }
                               else { bg = 'bg-[#ff0055]'; border = 'border-[#ff0055] border shadow-[0_0_8px_rgba(255,0,85,0.3)] z-10'; }
                            }
                            
                            return (
                               <div 
                                  key={dIdx} 
                                  className={cn("w-3 h-3 md:w-4 md:h-4 rounded-sm border transition-all duration-300 relative cursor-pointer", bg, border)}
                               >
                                  {/* Tooltip */}
                                  <div className="absolute opacity-0 hover:opacity-100 transition-opacity bottom-full mb-1 left-1/2 -translate-x-1/2 bg-[#050510] border border-cyan-500/30 text-slate-300 text-[10px] py-1.5 px-3 rounded whitespace-nowrap z-50 font-mono shadow-[0_0_15px_rgba(0,0,0,0.5)] drop-shadow-xl flex flex-col gap-0.5 items-center justify-center min-w-[120px] pointer-events-auto">
                                    <span className="text-slate-400 font-bold">{day.dateStr}</span>
                                    <span className={cn("font-black tracking-widest text-[11px]", val > 0 ? "text-[#00FFA3] drop-shadow-[0_0_3px_rgba(0,255,163,0.5)]" : (val < 0 ? "text-rose-500 drop-shadow-[0_0_3px_rgba(244,63,94,0.5)]" : "text-slate-500"))}>
                                       {val >= 0 ? (val === 0 ? '0.00' : '+') : ''}{val.toFixed(2)} US$
                                    </span>
                                  </div>
                               </div>
                            );
                         })}
                      </div>
                   )})}
                </div>
             </div>
             
             <div className="flex justify-end items-center gap-4 mt-6">
                <div className="flex items-center gap-2">
                   <span className="text-[9px] font-mono text-slate-500">Loss</span>
                   <div className="flex gap-1 flex-row-reverse">
                      <div className="w-3 h-3 rounded-sm border bg-[#ff0055] border-[#ff0055]" />
                      <div className="w-3 h-3 rounded-sm border bg-rose-500 border-rose-400" />
                      <div className="w-3 h-3 rounded-sm border bg-rose-700/60 border-rose-600/50" />
                      <div className="w-3 h-3 rounded-sm border bg-rose-900/40 border-rose-800/50" />
                   </div>
                </div>
                <div className="w-px h-3 bg-slate-700" />
                <div className="flex items-center gap-2">
                   <div className="flex gap-1">
                      <div className="w-3 h-3 rounded-sm border bg-emerald-900/40 border-emerald-800/50" />
                      <div className="w-3 h-3 rounded-sm border bg-emerald-700/60 border-emerald-600/50" />
                      <div className="w-3 h-3 rounded-sm border bg-emerald-500 border-emerald-400" />
                      <div className="w-3 h-3 rounded-sm border bg-[#00FFA3] border-[#00FFA3]" />
                   </div>
                   <span className="text-[9px] font-mono text-slate-500">Win</span>
                </div>
             </div>
          </div>
       </div>

    </div>
  );
}

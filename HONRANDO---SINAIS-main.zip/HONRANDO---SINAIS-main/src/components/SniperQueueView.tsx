import React from 'react';
import { Signal } from '../types.js';

export function SniperQueueView({ signals }: { signals: Signal[] }) {
  const removerSignal = async (id: string) => {
     await fetch('/api/remove-signal', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({ id })
     });
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto min-h-full pb-12 text-slate-300">
      <div>
        <h2 className="text-2xl font-black text-cyan-400 drop-shadow-[0_0_15px_rgba(34,211,238,0.6)] uppercase flex items-center gap-3">
          <span>🟡</span> FILA SNIPER (AGUARDANDO ROMPIMENTO)
        </h2>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs mt-2 pl-10 border-l-2 border-cyan-400/30">
          Robô só entrará na operação se 2 velas fecharem rompendo a linha demarcada com volume.
        </p>
      </div>
      
      <div className="flex-1 overflow-auto rounded-xl">
        <div className="bg-[#0A0F1D] border border-cyan-500/20 rounded-xl overflow-hidden min-w-[800px] flex flex-col shadow-[0_0_15px_rgba(34,211,238,0.05)]">
          <div className="flex px-4 py-3 bg-[#0B0C1A] border-b border-cyan-500/20 text-xs font-bold text-cyan-400 tracking-widest uppercase">
            <div className="w-24">HORA</div>
            <div className="w-32">MOEDA</div>
            <div className="w-20">TF</div>
            <div className="w-24">LADO</div>
            <div className="w-48">ALVO (ROMPIMENTO)</div>
            <div className="flex-1">STATUS</div>
            <div className="w-24 text-center">AÇÃO</div>
          </div>
          
          <div className="flex flex-col p-2 gap-2 overflow-y-auto">
            {signals.length === 0 && <div className="p-10 text-center text-slate-500 font-bold uppercase tracking-widest text-sm italic">Fila Sniper vazia. Aguardando oportunidades...</div>}
            
            {signals.map(s => {
              const isLong = s.lado === 'LONG';
              return (
                <div key={s.id} className="flex items-center px-4 py-3 bg-[#111326] border border-cyan-500/10 rounded-lg hover:border-cyan-400/50 transition-colors shadow-sm">
                  <div className="w-24 text-xs font-mono text-slate-400">{s.horaIn}</div>
                  <div className="w-32 font-black text-white text-md tracking-wider uppercase">🤖 {s.moeda}</div>
                  <div className="w-20 text-xs font-bold text-cyan-400 tracking-widest uppercase">{s.tf}</div>
                  <div className={`w-24 font-black text-sm tracking-widest uppercase ${isLong ? 'text-green-400 drop-shadow-[0_0_5px_rgba(74,222,128,0.5)]' : 'text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]'}`}>{s.lado}</div>
                  <div className="w-48 text-white font-mono text-xs">
                    <span className="text-slate-500 mr-2 uppercase tracking-widest font-bold">ROMPE:</span> ${(s.extremo || 0).toFixed(4)}
                  </div>
                  <div className="flex-1 text-xs text-cyan-400/80 uppercase font-bold tracking-widest italic animate-pulse">
                    Monitorando Gráfico...
                  </div>
                  <div className="w-24 flex justify-center">
                    <button 
                      onClick={() => removerSignal(s.id)}
                      className="px-4 py-1.5 rounded-lg bg-pink-500/20 text-pink-500 border border-pink-500/30 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-all shadow-[0_0_10px_rgba(236,72,153,0.1)] flex items-center justify-center font-bold tracking-widest text-xs"
                    >
                      EXCLUIR
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

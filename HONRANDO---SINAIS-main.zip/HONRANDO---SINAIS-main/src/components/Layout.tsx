import React, { useEffect, useState } from 'react';
import { BotState, Trade, Signal } from '../types.js';
import { CockpitView } from './CockpitView.js';
import { AutomationsView } from './AutomationsView.js';
import { TradesView } from './TradesView.js';
import { SniperQueueView } from './SniperQueueView.js';
import { HistoryView } from './HistoryView.js';
import { SignalsView } from './SignalsView.js';
import { ManualOrderView } from './ManualOrderView.js';
import { RadarView } from './RadarView.js';
import { StatsView } from './StatsView.js';
import { AnalisesQuantitativasView } from './AnalisesQuantitativasView.js';
import { ConfluencesView } from './ConfluencesView.js';
import { InsightsView } from './InsightsView.js';
import { SettingsView } from './SettingsView.js';
import { LoginView } from './LoginView.js';
import { ChartView } from './ChartView.js';
import { BacktestingWidget } from './BacktestingWidget.js';
import { Bot, Crosshair, Radar, Activity, Clock, Settings, Gamepad2, FlaskConical, PenLine, BarChart2, BarChart3, ScanEye, Key, LineChart, FlaskRound, Info, Menu, X, Layers, Cpu } from 'lucide-react';
import { cn } from '../lib/utils.js';

type Tab = 'cockpit' | 'chart' | 'insights' | 'backtest' | 'analises' | 'confluences' | 'automations' | 'sniper' | 'signals' | 'radar' | 'stats' | 'manual_order' | 'ativas_real' | 'hist_real' | 'simu' | 'simu_b' | 'simu_c' | 'settings';

export default function Layout() {
  const [activeTab, setActiveTab] = useState<Tab>('cockpit');
  const [state, setState] = useState<BotState | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) return;
    
    const fetchState = () => {
      fetch('/api/state')
        .then(res => {
          if (!res.ok) {
            throw new Error(`Server returned status ${res.status}`);
          }
          const contentType = res.headers.get('content-type');
          if (!contentType || !contentType.includes('application/json')) {
            throw new Error('Server returned non-JSON content. Is the dev server starting?');
          }
          return res.json();
        })
        .then(data => {
          if (data) setState(data);
        })
        .catch(err => {
          console.warn('[Layout] Failed to fetch bot state:', err.message);
        });
    };
    fetchState();
    const int = setInterval(fetchState, 1500);
    return () => clearInterval(int);
  }, [isAuthenticated]);

  if (!isAuthenticated) {
    return <LoginView onLogin={() => setIsAuthenticated(true)} />;
  }

  if (!state) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-cyan-400 animate-pulse text-xl">Inicializando Sistema [GLÓRIA A DEUS]...</div>
      </div>
    );
  }

  const baseNavItems = [
    { id: 'cockpit', icon: <Bot />, label: 'INÍCIO' },
    { id: 'chart', icon: <LineChart />, label: 'GRÁFICOS TV' },
    { id: 'analises', icon: <BarChart3 />, label: 'ANÁLISES' },
    { id: 'confluences', icon: <Layers />, label: 'PARECER CONFLUÊNCIAS' },
    { id: 'insights', icon: <Info />, label: 'LENTES DE ANÁLISE' },
    { id: 'backtest', icon: <FlaskRound />, label: 'BACKTEST CSV' },
    { id: 'settings', icon: <Key />, label: 'CHAVES & TOKENS' },
    { id: 'automations', icon: <Settings />, label: 'AUTOMAÇÕES' },
    { id: 'sniper', icon: <Crosshair />, label: 'FILA SNIPER' },
    { id: 'signals', icon: <Radar />, label: 'SINAIS TV' },
    { id: 'radar', icon: <ScanEye />, label: 'RADAR VERIF.' },
    { id: 'stats', icon: <BarChart2 />, label: 'ESTATÍSTICAS' },
    { id: 'manual_order', icon: <PenLine />, label: 'NOVA ORDEM' },
    { id: 'ativas_real', icon: <Activity />, label: 'ATIVAS REAL' },
    { id: 'hist_real', icon: <Clock />, label: 'HISTÓRICO REAL' },
    { id: 'simu', icon: <Gamepad2 />, label: 'TESTE A - MOTOR A' },
    { id: 'simu_b', icon: <FlaskConical />, label: 'TESTE B - TRADINGVIEW' },
    { id: 'simu_c', icon: <Cpu />, label: 'TESTE C - NOVO MOTOR' },
  ] as const;

  const navItems = baseNavItems;

  const renderContent = () => {
    switch (activeTab) {
      case 'cockpit': return <CockpitView state={state} />;
      case 'chart': return <ChartView />;
      case 'insights': return <InsightsView state={state} />;
      case 'backtest': return <BacktestingWidget />;
      case 'analises': return <AnalisesQuantitativasView history={state.history} />;
      case 'confluences': return <ConfluencesView history={state.history} />;
      case 'automations': return <AutomationsView state={state} />;
      case 'sniper': return <SniperQueueView signals={state.pendingSignals} />;
      case 'signals': return <SignalsView signals={state.receivedSignals} history={state.history} />;
      case 'radar': return <RadarView />;
      case 'stats': return <StatsView history={state.history} />;
      case 'manual_order': return <ManualOrderView />;
      case 'ativas_real': return <TradesView trades={state.activeTrades.filter(t => t.est === 'REAL')} title="🔴 OPERAÇÕES ATIVAS (BINANCE REAL)" est="REAL" history={state.history.filter(t => t.est === 'REAL')} />;
      case 'hist_real': return <HistoryView history={state.history.filter(t => t.est === 'REAL')} title="🔴 HISTÓRICO REAL" est="REAL" />;
      case 'simu': return <TradesView trades={state.activeTrades.filter(t => t.est === 'SIMU')} title="🎮 TESTE A - MOTOR A (RUPTURA SNIPER)" est="SIMU" history={state.history.filter(t => t.est === 'SIMU')} />;
      case 'simu_b': return <TradesView trades={state.activeTrades.filter(t => t.est === 'SIMU_B')} title="🧪 TESTE B - MOTOR DO TRADING VIEW (IMEDIATO)" est="SIMU_B" history={state.history.filter(t => t.est === 'SIMU_B')} />;
      case 'simu_c': return <TradesView trades={state.activeTrades.filter(t => t.est === 'SIMU_C')} title="⚙️ TESTE C - FUTURO WEBHOOK (IMEDIATO)" est="SIMU_C" history={state.history.filter(t => t.est === 'SIMU_C')} />;
      case 'settings': return <SettingsView state={state} />;
      default: return <CockpitView state={state} />;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-[#050510] text-slate-300 font-sans overflow-hidden">
      {/* Mobile Header Bar */}
      <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-[#0A0A18] border-b border-pink-500/10 z-30 shrink-0">
        <button
          onClick={() => setIsMobileOpen(true)}
          className="p-2 rounded-xl bg-pink-500/10 text-pink-400 border border-pink-500/20 hover:bg-pink-500/20 hover:text-cyan-400 transition-all shadow-[0_0_10px_rgba(236,72,153,0.1)]"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h2 className="text-pink-500 font-bold text-[10px] sm:text-xs uppercase tracking-[0.2em] drop-shadow-[0_0_8px_rgba(236,72,153,0.6)]">DEUS ESTÁ NO CONTROLE ✝️</h2>
          <div className="text-cyan-400 text-[8px] sm:text-[10px] uppercase font-mono tracking-widest drop-shadow-[0_0_5px_rgba(34,211,238,0.6)]">MODO HÍBRIDO</div>
        </div>
        <div className="w-9 h-9 flex items-center justify-center">
          {/* Decorative small indicator */}
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,1)]"></div>
        </div>
      </div>

      {/* Overlay Backdrop for Mobile */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden transition-all duration-300"
        />
      )}

      {/* Sidebar - Retrowave Vibes */}
      <aside className={cn(
        "fixed inset-y-0 left-0 w-72 border-r border-pink-500/20 bg-[#0A0A18] flex flex-col items-center py-6 gap-6 shadow-[4px_0_30px_rgba(236,72,153,0.1)] shrink-0 z-50 transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 h-full",
        isMobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Mobile Sidebar Close Button & Header */}
        <div className="lg:hidden flex items-center justify-between w-full px-5 pb-2">
          <div className="flex flex-col">
            <h2 className="text-pink-500 font-bold text-xs uppercase tracking-widest drop-shadow-[0_0_5px_rgba(236,72,153,0.5)]">NAVIGAÇÃO</h2>
            <span className="text-cyan-400 text-[9px] font-mono">SNIPER V2 VIP</span>
          </div>
          <button
            onClick={() => setIsMobileOpen(false)}
            className="p-2 rounded-lg bg-pink-500/10 border border-pink-500/20 text-pink-400 hover:text-cyan-400 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Desktop Sidebar Logo */}
        <div className="text-center px-4 w-full hidden lg:block">
          <h2 className="text-pink-500 font-bold text-sm uppercase tracking-widest shadow-pink-500/50 drop-shadow-[0_0_10px_rgba(236,72,153,0.8)]">DEUS ESTÁ NO CONTROLE ✝️</h2>
          <div className="text-cyan-400 text-xs mt-1 font-mono tracking-wider drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">MODO HÍBRIDO</div>
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-pink-500/50 to-transparent w-full shrink-0"></div>

        {/* Nav Items Scrollable List */}
        <nav className="flex flex-col w-full px-4 gap-2 flex-grow overflow-y-auto scrollbar-thin scrollbar-thumb-pink-500/20 scrollbar-track-transparent">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setIsMobileOpen(false);
              }}
              className={cn(
                "flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 text-sm font-bold tracking-wide w-full border text-left",
                activeTab === item.id 
                  ? "bg-pink-500/10 text-pink-400 border-pink-500/50 shadow-[0_0_15px_rgba(236,72,153,0.2)]"
                  : "text-slate-400 border-transparent hover:text-cyan-400 hover:bg-cyan-900/10 hover:border-cyan-400/30"
              )}
            >
              {React.cloneElement(item.icon, { className: 'w-5 h-5 shrink-0' })}
              <span className="truncate">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-4 text-center w-full shrink-0">
          <div className="h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent w-full mb-4"></div>
          <div className="text-xs text-pink-500 font-bold tracking-[0.2em] drop-shadow-[0_0_5px_rgba(236,72,153,0.8)]">GLÓRIA A DEUS</div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/10 via-[#050510] to-[#050510] z-10 scrollbar-thin scrollbar-thumb-pink-500/20 scrollbar-track-transparent relative">
        {renderContent()}
      </main>
    </div>
  );
}

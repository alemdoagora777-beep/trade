import React from 'react';
import { Trade } from '../types.js';

export function HistoryView({ history, title, est }: { history: Trade[], title: string, est: string }) {
  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto min-h-full pb-12 text-slate-300">
      <h2 className="text-2xl font-black text-pink-500 drop-shadow-[0_0_10px_rgba(236,72,153,0.6)] tracking-widest uppercase">{title}</h2>
      
      <div className="flex-1 overflow-auto">
        <div className="bg-[#0A0F1D] border border-pink-500/20 rounded-xl overflow-hidden min-w-[800px] shadow-[0_0_15px_rgba(236,72,153,0.05)] flex flex-col">
          <div className="flex px-4 py-3 bg-[#0B0C1A] border-b border-pink-500/20 text-xs font-bold text-pink-400 tracking-widest uppercase">
            <div className="w-32">MOEDA</div>
            <div className="w-20">ENTRADA</div>
            <div className="w-20">SAÍDA</div>
            <div className="w-24">DURAÇÃO</div>
            <div className="w-24">LADO</div>
            <div className="w-32">ROI (MIN/MAX)</div>
            <div className="w-28 text-center">LUCRO</div>
            <div className="flex-1 pl-4">MOTIVO DO ENCERRAMENTO</div>
          </div>
          
          <div className="flex flex-col p-2 gap-2 overflow-y-auto">
            {history.length === 0 && <div className="p-8 text-center text-slate-500 italic font-bold tracking-widest uppercase">Nenhum histórico registrado no modo selecionado.</div>}
            
            {history.map(t => {
              const pnlColor = t.pnl >= 0 ? 'text-green-400' : 'text-red-500';
              const isLong = t.side === 'LONG';
              
              const extractMins = (hStr: string) => {
                  const [h,m,s] = hStr.split(':').map(Number);
                  return (h || 0)*60 + (m || 0) + (s || 0)/60;
              };
              let durationMins = 0;
              if (t.dataFim && t.dataIn) {
                  const inMins = extractMins(t.dataIn);
                  const outMins = extractMins(t.dataFim);
                  durationMins = outMins >= inMins ? outMins - inMins : (24*60 - inMins + outMins);
              }
              
              let durationTag = 'Short';
              let durationColor = 'bg-cyan-900/40 text-cyan-400 border-cyan-500/30';
              if (durationMins >= 120) {
                  durationTag = 'Long';
                  durationColor = 'bg-purple-900/40 text-purple-400 border-purple-500/30';
              } else if (durationMins >= 30) {
                  durationTag = 'Medium';
                  durationColor = 'bg-amber-900/40 text-amber-400 border-amber-500/30';
              }
              
              return (
                <div key={t.id + t.dataFim} className="flex items-center px-4 py-3 bg-[#111326] border border-pink-500/10 rounded-lg hover:border-pink-500/40 transition-colors shadow-sm">
                  <div className="w-32 flex flex-col justify-center">
                    <span className="font-bold text-white text-sm tracking-widest">🤖 {t.symbol.replace('/USDT', '')}</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5" title="Preço de Entrada">Entrada: ${t.entry ? t.entry.toFixed(4) : '--'} {t.adx ? `| ADX: ${t.adx}` : ''}</span>
                  </div>
                  <div className="w-20 text-xs text-slate-400 font-mono">{t.dataIn}</div>
                  <div className="w-20 text-xs text-slate-300 font-mono font-bold">{t.dataFim || '--:--'}</div>
                  <div className="w-24 flex items-center">
                     <span className={`text-[9px] font-bold px-2 py-0.5 rounded border tracking-widest uppercase ${durationColor}`}>
                         {durationTag}
                     </span>
                  </div>
                  <div className={`w-24 font-black text-sm tracking-widest ${isLong ? 'text-green-400' : 'text-red-500'}`}>{t.side}</div>
                  <div className="w-32 flex flex-col justify-center">
                    <span className={`font-black text-sm tracking-widest ${t.roi >= 0 ? 'text-green-400' : 'text-red-500'}`}>{t.roi >= 0 ? '+' : ''}{t.roi.toFixed(2)}%</span>
                    <div className="text-[10px] font-mono tracking-widest mt-0.5 flex items-center gap-1">
                      <span className="text-red-500 font-medium" title="Mínimo ROI atingido (Rebaixamento máximo)">{t.minRoi >= 0 ? '+' : ''}{t.minRoi.toFixed(1)}%</span>
                      <span className="text-slate-600">/</span>
                      <span className="text-green-400 font-medium" title="Máximo ROI atingido (Pico máximo)">{t.maxRoi >= 0 ? '+' : ''}{t.maxRoi.toFixed(1)}%</span>
                    </div>
                    <div className="text-[9px] text-slate-500 font-mono tracking-widest mt-0.5 flex flex-col leading-tight">
                      <span>Pico: {t.tempoAtePicoMin ?? 0} min</span>
                      <span>Poço: {t.tempoAtePocoMin ?? 0} min</span>
                    </div>
                  </div>
                  <div className="w-28 flex flex-col items-center justify-center">
                    <span className={`font-black text-md tracking-tight text-center ${pnlColor} drop-shadow-[0_0_5px_currentColor]`}>${t.pnl.toFixed(2)}</span>
                    <span className="text-[9px] text-slate-500 tracking-widest font-mono mt-0.5" title="Margem de Entrada">MG: ${t.margin ? t.margin.toFixed(2) : '--'} | {t.lev || 10}x</span>
                  </div>
                  <div className="flex-1 pl-4 text-xs font-mono text-slate-400 italic tracking-wider">
                    {t.motivo}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useMemo, useEffect, useRef, useState } from "react";
import { BotState, Trade } from "../types.js";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
  ReferenceLine,
} from "recharts";
import { cn } from "../lib/utils.js";
import {
  Bell,
  Flame,
  ShieldAlert,
  Volume2,
  VolumeX,
  Compass,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Info,
  XCircle,
  Terminal,
} from "lucide-react";

function VolatilityGuardian({
  avgVolatility,
  volThreshold,
  showDriftAlert,
  realPnl,
  simuPnl,
  driftPercentage,
  strategyDrift,
}: {
  avgVolatility: number;
  volThreshold: number;
  showDriftAlert: boolean;
  realPnl: number;
  simuPnl: number;
  driftPercentage: number;
  strategyDrift: number;
}) {
  if (!(avgVolatility > volThreshold || showDriftAlert)) return null;

  return (
    <div className="flex flex-col gap-4">
      {avgVolatility > volThreshold && (
        <div className="bg-rose-500/10 border border-rose-500/50 rounded-2xl p-4 shadow-[0_0_15px_rgba(244,63,94,0.3)] flex items-center gap-4 animate-pulse">
          <div className="w-12 h-12 rounded-full bg-rose-500/20 flex items-center justify-center shrink-0 border border-rose-500/50">
            <span className="text-2xl">⚠️</span>
          </div>
          <div>
            <h3 className="text-rose-400 font-bold tracking-widest uppercase">
              ALERTA DE ALTA VOLATILIDADE (GUARDIAN)
            </h3>
            <p className="text-rose-300/80 text-xs font-mono mt-1">
              A volatilidade média ({avgVolatility.toFixed(2)}x) ultrapassou o
              limiar de segurança definido nas configurações (
              {volThreshold.toFixed(2)}x). Risco elevado de violinadas
              (whipsaw). Considere reduzir a exposição no robô real.
            </p>
          </div>
        </div>
      )}

      {showDriftAlert && (
        <div className="bg-amber-500/10 border border-amber-500/50 rounded-2xl p-4 shadow-[0_0_15px_rgba(245,158,11,0.3)] flex items-center gap-4 animate-pulse">
          <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0 border border-amber-500/50">
            <span className="text-2xl">📉</span>
          </div>
          <div>
            <h3 className="text-amber-400 font-bold tracking-widest uppercase">
              DRIFT DE ESTRATÉGIA DETECTADO
            </h3>
            <p className="text-amber-300/80 text-xs font-mono mt-1">
              O desempenho real das operações (Real PnL: ${realPnl.toFixed(2)})
              divergiu significativamente do esperado no simulador (Simu PnL: $
              {simuPnl.toFixed(2)}). Drift detectado:{" "}
              <b>{driftPercentage.toFixed(1)}%</b> (${strategyDrift.toFixed(2)}
              ). Verifique logs de execução, taxas e conexão de API.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function DailyGoalIndicator({
  todayPnl,
  dailyGoal,
  targetEst,
}: {
  todayPnl: number;
  dailyGoal: number;
  targetEst: string;
}) {
  if (!dailyGoal || dailyGoal <= 0) return null;

  const progress = (todayPnl / dailyGoal) * 100;
  const clamped = Math.max(0, Math.min(100, progress));
  const achieved = todayPnl >= dailyGoal;
  const remaining = Math.max(0, dailyGoal - todayPnl);

  return (
    <div className="bg-[#0A0C16] border border-cyan-800/40 rounded-2xl p-4 shadow-xl flex flex-col gap-3 relative overflow-hidden group">
      <div className="flex items-center justify-between z-10 relative">
        <div className="flex items-center gap-2">
          <span className="text-xl">🎯</span>
          <h3 className="text-cyan-400 font-black tracking-widest uppercase text-sm">
            META DIÁRIA ({targetEst})
          </h3>
        </div>
        <div className="text-right">
          <span
            className={cn(
              "font-bold text-lg",
              todayPnl >= 0 ? "text-[#00FFA3]" : "text-rose-500",
            )}
          >
            ${todayPnl.toFixed(2)}
          </span>
          <span className="text-slate-500 font-mono text-xs ml-1">
            / ${dailyGoal.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800 relative z-10">
        <div
          className={cn(
            "h-full transition-all duration-1000",
            achieved
              ? "bg-[#00FFA3] shadow-[0_0_10px_rgba(0,255,163,0.8)]"
              : "bg-cyan-500",
          )}
          style={{ width: `${clamped}%` }}
        ></div>
      </div>

      <div className="flex justify-between items-center text-[10px] font-mono tracking-widest uppercase z-10 relative">
        {achieved ? (
          <span className="text-[#00FFA3] font-bold animate-pulse">
            Meta atingida! Parabéns! 🚀
          </span>
        ) : (
          <span className="text-cyan-500/80">
            Faltam ${remaining.toFixed(2)} para bater a meta
          </span>
        )}
        <span className="text-slate-400">{progress.toFixed(1)}%</span>
      </div>

      {achieved && (
        <div className="absolute inset-0 bg-gradient-to-r from-[#00FFA3]/5 to-transparent pointer-events-none" />
      )}
    </div>
  );
}

function StaleTradesWatcher({
  activeTrades,
  history,
}: {
  activeTrades: Trade[];
  history: Trade[];
}) {
  const extractMins = (hStr: string) => {
    const parts = hStr.split(":");
    if (parts.length >= 2) {
      const [h, m, s] = parts.map(Number);
      return (h || 0) * 60 + (m || 0) + (s || 0) / 60;
    }
    return 0;
  };

  const staleAlerts = useMemo(() => {
    const alerts: { symbol: string; currentMins: number; avgMins: number }[] =
      [];
    const nowMins = Date.now() / 60000;

    activeTrades.forEach((active) => {
      const symbolHistory = history.filter(
        (t) => t.symbol === active.symbol && t.dataFim && t.dataIn,
      );
      if (symbolHistory.length === 0) return;

      let totalMins = 0;
      symbolHistory.forEach((t) => {
        const inMins = extractMins(t.dataIn);
        const outMins = extractMins(t.dataFim!);
        let tempoValue =
          outMins >= inMins ? outMins - inMins : 24 * 60 - inMins + outMins;
        totalMins += tempoValue;
      });
      const avgMins = totalMins / symbolHistory.length;
      const currentMins = nowMins - active.tsIn / 60000;

      // Only alert if the trade has been open for 20% longer than average
      if (avgMins > 0 && currentMins > avgMins * 1.2) {
        alerts.push({
          symbol: active.symbol,
          currentMins,
          avgMins,
        });
      }
    });

    return alerts;
  }, [activeTrades, history]);

  if (staleAlerts.length === 0) return null;

  return (
    <div className="flex flex-col gap-4">
      {staleAlerts.map((alert) => (
        <div
          key={alert.symbol}
          className="bg-purple-500/10 border border-purple-500/50 rounded-2xl p-4 shadow-[0_0_15px_rgba(168,85,247,0.3)] flex items-center gap-4 animate-pulse"
        >
          <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0 border border-purple-500/50">
            <span className="text-2xl">⏳</span>
          </div>
          <div>
            <h3 className="text-purple-400 font-bold tracking-widest uppercase">
              POSIÇÃO ESTAGNADA: {alert.symbol}
            </h3>
            <p className="text-purple-300/80 text-xs font-mono mt-1">
              A posição de {alert.symbol} está aberta há{" "}
              {alert.currentMins.toFixed(0)} min, excedendo a média histórica
              para este ativo ({alert.avgMins.toFixed(0)} min). Considere
              revisar a operação.
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

const playBeep = (
  freq: number,
  type: "sine" | "triangle" | "sawtooth" | "square",
  duration: number,
  volume: number = 0.08,
) => {
  try {
    const AudioContextClass =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    // Smooth ramp-up and ramp-down to prevent pop sounds
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (e) {
    console.warn(
      "Audio Context not started or blocked by user interaction.",
      e,
    );
  }
};

export function LiveRsiMonitor({ state }: { state: BotState }) {
  const coinsStr =
    state.cfg.rsiMonitoredCoins || "BTC, ETH, SOL, XRP, ADA, BNB";
  const symbols = useMemo(() => {
    return coinsStr
      .split(",")
      .map((s) => s.trim().toUpperCase())
      .filter(Boolean);
  }, [coinsStr]);

  const [rsiValues, setRsiValues] = useState<{ [sym: string]: number }>({});
  const lastAlertPostRef = useRef<{ [sym: string]: number }>({});
  const lastAudioPlayRef = useRef<{ [sym: string]: number }>({});
  const lastNotificationPlayRef = useRef<{ [sym: string]: number }>({});

  const [permission, setPermission] = useState<
    NotificationPermission | "unsupported"
  >(
    typeof window !== "undefined" && "Notification" in window
      ? Notification.permission
      : "unsupported",
  );

  const overbought =
    state.cfg.rsiOverbought !== undefined ? state.cfg.rsiOverbought : 80;
  const oversold =
    state.cfg.rsiOversold !== undefined ? state.cfg.rsiOversold : 20;
  const enableAudio = state.cfg.enableRsiAudioAlert !== false;
  const enableVisual = state.cfg.enableRsiVisualAlert !== false;

  const requestNotificationPermission = async () => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      setPermission("unsupported");
      return;
    }

    try {
      const res = await Notification.requestPermission();
      setPermission(res);
      if (res === "granted") {
        new Notification("Elite Sniper AI — Alertas Ativados", {
          body: "Você agora receberá notificações do sistema em tempo real sobre desvios extremos de RSI.",
          tag: "sniper-welcome",
        });
      }
    } catch (e) {
      // Compatibility fallback for older browsers with callback parameter
      try {
        Notification.requestPermission((res) => {
          setPermission(res);
          if (res === "granted") {
            new Notification("Elite Sniper AI — Alertas Ativados", {
              body: "Você agora receberá notificações do sistema em tempo real sobre desvios extremos de RSI.",
              tag: "sniper-welcome",
            });
          }
        });
      } catch (err) {
        console.warn(
          "Falha ao solicitar permissão de notificações do sistema:",
          err,
        );
      }
    }
  };

  const testSystemNotification = () => {
    if (
      typeof window !== "undefined" &&
      "Notification" in window &&
      Notification.permission === "granted"
    ) {
      try {
        new Notification("Elite Sniper AI — Teste com Sucesso 🚀", {
          body: "Notificações operacionais estão integradas e ativas! Você as receberá mesmo com a aba minimizada.",
          tag: "sniper-test",
        });
      } catch (err) {
        console.warn("Falha ao acionar notificação de teste:", err);
      }
    }
  };

  useEffect(() => {
    const initial: { [sym: string]: number } = {};
    symbols.forEach((sym, index) => {
      const randSeed = (index * 13) % 40;
      initial[sym] = parseFloat((30 + randSeed + Math.random() * 8).toFixed(1));
    });
    setRsiValues(initial);

    const interval = setInterval(() => {
      setRsiValues((prev) => {
        const next = { ...prev };
        symbols.forEach((sym) => {
          const current = next[sym] !== undefined ? next[sym] : 50;
          let delta = (Math.random() - 0.5) * 5;

          if (Math.random() > 0.85) {
            delta += (Math.random() - 0.5) * 16;
          }

          let updated = Math.min(96, Math.max(4, current + delta));
          next[sym] = parseFloat(updated.toFixed(1));
        });
        return next;
      });
    }, 2550);

    return () => clearInterval(interval);
  }, [symbols]);

  useEffect(() => {
    const now = Date.now();
    symbols.forEach((sym) => {
      const rsiVal = rsiValues[sym];
      if (rsiVal === undefined) return;

      const isOverbought = rsiVal > overbought;
      const isOversold = rsiVal < oversold;

      if (isOverbought || isOversold) {
        const type = isOverbought ? "overbought" : "oversold";
        const limitUsed = isOverbought ? overbought : oversold;

        const lastPost = lastAlertPostRef.current[sym] || 0;
        if (now - lastPost > 30005) {
          lastAlertPostRef.current[sym] = now;
          fetch("/api/log-rsi-alert", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              symbol: sym,
              rsi: rsiVal,
              limit: limitUsed,
              type: type,
              tf: "15m",
            }),
          }).catch((err) =>
            console.error("Erro ao salvar alerta no server:", err),
          );
        }

        // Native Browser Desktop Notifications
        const lastNotif = lastNotificationPlayRef.current[sym] || 0;
        if (now - lastNotif > 30005) {
          // 30s throttle per coin to prevent spam
          lastNotificationPlayRef.current[sym] = now;
          if (
            typeof window !== "undefined" &&
            "Notification" in window &&
            Notification.permission === "granted"
          ) {
            const title = isOverbought
              ? `🔥 RSI SOBRECOMPRA: ${sym} (${rsiVal})`
              : `❄️ RSI SOBREVENDA: ${sym} (${rsiVal})`;
            const body = isOverbought
              ? `O par ${sym}/USDT cruzou acima do limiar extremo de ${overbought}. Força consumidora máxima e risco de saturação local.`
              : `O par ${sym}/USDT cruzou abaixo do limiar extremo de ${oversold}. Pressão vendedora massiva e exaustão local.`;
            try {
              new Notification(title, {
                body,
                tag: `rsi-${sym}-${type}`, // unique tag prevents duplicates per coin/state
                requireInteraction: false,
              });
            } catch (err) {
              console.warn("Erro ao disparar notificação do sistema:", err);
            }
          }
        }

        if (enableAudio) {
          const lastAudio = lastAudioPlayRef.current[sym] || 0;
          if (now - lastAudio > 15005) {
            lastAudioPlayRef.current[sym] = now;
            if (isOverbought) {
              playBeep(880, "sine", 0.12, 0.08);
              setTimeout(() => playBeep(1200, "sine", 0.18, 0.06), 120);
            } else {
              playBeep(440, "triangle", 0.12, 0.1);
              setTimeout(() => playBeep(330, "triangle", 0.2, 0.08), 120);
            }
          }
        }
      }
    });
  }, [rsiValues, overbought, oversold, enableAudio, symbols]);

  const testBeep = () => {
    playBeep(659.25, "sine", 0.15, 0.08);
    setTimeout(() => playBeep(880, "sine", 0.22, 0.08), 150);
  };

  const toggleAudio = async () => {
    try {
      await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enableRsiAudioAlert: !enableAudio }),
      });
    } catch (e) {
      console.error("Erro ao alternar alertas sonoros:", e);
    }
  };

  const criticalCoins = symbols.filter((sym) => {
    const v = rsiValues[sym];
    return v !== undefined && (v > overbought || v < oversold);
  });

  return (
    <div className="bg-[#0A0C16] border border-slate-800/40 rounded-2xl p-5 shadow-xl flex flex-col gap-4 relative overflow-hidden group">
      <div className="absolute -left-16 -bottom-16 w-48 h-48 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none"></div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800/80 pb-3 z-10 relative gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <Compass className="w-5 h-5 text-emerald-400 animate-spin-slow shrink-0" />
          <div className="min-w-0">
            <h3 className="text-white font-black tracking-widest uppercase text-xs truncate">
              RADAR COMPASS: MONITOR DE RSI EXTREMO
            </h3>
            <p className="text-[9px] text-slate-500 mt-0.5 truncate">
              MÉTRICAS ATIVAS DE COBIÇA E MEDO · LIMITES: &gt;{overbought} OU
              &lt;{oversold}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={toggleAudio}
            className={cn(
              "text-[9px] font-bold border px-2 py-1 rounded transition-all tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812]",
              enableAudio
                ? "border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10 shadow-[0_0_8px_rgba(16,185,129,0.15)]"
                : "border-slate-700/50 text-slate-500 hover:text-slate-300",
            )}
            title={
              enableAudio
                ? "Desativar alertas sonoros de RSI"
                : "Ativar alertas sonoros de RSI"
            }
          >
            {enableAudio ? (
              <Volume2 className="w-3 h-3 text-emerald-400 animate-pulse" />
            ) : (
              <VolumeX className="w-3 h-3 text-slate-500" />
            )}
            Sons: {enableAudio ? "ATIVADO" : "DESATIVADO"}
          </button>

          <button
            onClick={testBeep}
            className="text-[9px] font-bold text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-700/50 px-2 py-1 rounded transition-all tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812]"
            title="Testar sintetizador de áudio de alerta"
          >
            Testar Áudio
          </button>

          {/* Browser Alerts Configuration */}
          {permission === "granted" ? (
            <button
              onClick={testSystemNotification}
              className="text-[9px] font-bold text-cyan-400 hover:text-white hover:bg-[#083344] border border-cyan-500/30 px-2 py-1 rounded transition-all tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812] shadow-[0_0_8px_rgba(6,182,212,0.1)]"
              title="As notificações nativas do sistema estão ativadas! Clique aqui para disparar uma notificação de teste imediatamente."
            >
              <Bell className="w-3 h-3 text-cyan-400" />
              NOTIF: ATIVAS (TESTAR)
            </button>
          ) : permission === "denied" ? (
            <span
              className="text-[9px] font-bold border border-rose-500/30 text-rose-400/80 px-2 py-1 rounded tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812] select-none cursor-help"
              title="As notificações nativas do sistema foram bloqueadas no seu navegador para este domínio. Por favor, reative-as nas configurações de privacidade do seu navegador."
            >
              <Bell className="w-3 h-3 text-rose-500" />
              NOTIF: BLOQUEADAS
            </span>
          ) : permission === "unsupported" ? (
            <span
              className="text-[9px] font-bold border border-slate-800 text-slate-500 px-2 py-1 rounded tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812] select-none cursor-not-allowed"
              title="Seu navegador ou o ambiente de sandbox (iframe) não suporta a API de Notificação de Desktop."
            >
              <Bell className="w-3 h-3 text-slate-600" />
              NOTIF: INDISPONÍVEL
            </span>
          ) : (
            <button
              onClick={requestNotificationPermission}
              className="text-[9px] font-bold border border-amber-500/40 text-amber-400 hover:bg-amber-500/10 px-2 py-1 rounded transition-all tracking-wider uppercase flex items-center gap-1 shrink-0 bg-[#060812] shadow-[0_0_8px_rgba(245,158,11,0.1)] animate-pulse"
              title="Ativar e conceder permissões para receber notificações nativas fora da aba ou com navegador minimizado"
            >
              <Bell className="w-3 h-3 text-amber-400" />
              ATIVAR NOTIFICAÇÕES
            </button>
          )}

          {enableVisual && criticalCoins.length > 0 && (
            <span className="text-[8px] font-black tracking-widest bg-rose-500 text-white px-2 py-0.5 rounded-full uppercase animate-pulse">
              {criticalCoins.length} EXTREMO
              {criticalCoins.length > 1 ? "S" : ""}!
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 z-10 relative">
        {symbols.map((sym) => {
          const val = rsiValues[sym] || 50;
          const isHigh = val > overbought;
          const isLow = val < oversold;

          let cardBorder = "border-[#1e293b] bg-[#060812]";
          let textClass = "text-slate-400";
          let bgBar = "bg-slate-700";
          let badge = null;

          if (isHigh) {
            cardBorder =
              "border-rose-500/50 bg-rose-950/10 shadow-[0_0_12px_rgba(244,63,94,0.15)] animate-pulse";
            textClass = "text-rose-400 font-bold";
            bgBar = "bg-rose-500 shadow-[0_0_5px_rgba(244,63,94,0.5)]";
            badge = (
              <span className="text-[8px] font-black tracking-widest text-rose-400 uppercase flex items-center gap-0.5">
                <Flame className="w-2.5 h-2.5 fill-rose-400" /> SOBRECOMPRA 🔥
              </span>
            );
          } else if (isLow) {
            cardBorder =
              "border-[#00FFA3]/40 bg-[#00FFA3]/5 shadow-[0_0_12px_rgba(0,255,163,0.15)] animate-pulse";
            textClass = "text-[#00FFA3] font-bold";
            bgBar = "bg-[#00FFA3] shadow-[0_0_5px_rgba(0,255,163,0.5)]";
            badge = (
              <span className="text-[8px] font-black tracking-widest text-[#00FFA3] uppercase flex items-center gap-0.5">
                <Bell className="w-2.5 h-2.5 fill-[#00FFA3]" /> SOBREVENDA ❄️
              </span>
            );
          }

          return (
            <div
              key={sym}
              className={cn(
                "border rounded-xl p-3 flex flex-col gap-2.5 transition-all text-left",
                cardBorder,
              )}
            >
              <div className="flex justify-between items-start">
                <div className="flex flex-col">
                  <span className="text-xs font-black text-white tracking-wider">
                    {sym}
                  </span>
                  <span className="text-[9px] text-slate-500 font-mono">
                    RSI (14)
                  </span>
                </div>
                <span
                  className={cn(
                    "font-mono text-xs sm:text-sm font-bold",
                    textClass,
                  )}
                >
                  {val.toFixed(1)}
                </span>
              </div>

              <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800/50">
                <div
                  className={cn("h-full transition-all duration-300", bgBar)}
                  style={{ width: `${val}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between min-h-[14px]">
                {badge || (
                  <span className="text-[8px] font-bold text-slate-600 tracking-wider uppercase">
                    ESTÁVEL
                  </span>
                )}
                <span className="text-[7px] font-mono opacity-80">
                  {val > 50 ? "▲" : "▼"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {enableVisual && criticalCoins.length > 0 && (
        <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-3 flex items-center gap-3 animate-pulse z-10 relative mt-1">
          <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0" />
          <div className="flex-1">
            <p className="text-rose-200 text-[10px] font-black tracking-widest uppercase">
              ALERTA OPERACIONAL: RSI EXTREMO ALCANÇADO
            </p>
            <p className="text-rose-300/80 font-mono text-[9px] mt-0.5">
              Curva de sentimento em desvio extremo:{" "}
              {criticalCoins
                .map((sym) => `${sym} (RSI: ${rsiValues[sym]})`)
                .join(", ")}
              . Gatilhando feeds imediatos de monitoramento no terminal.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export function CockpitView({ state }: { state: BotState }) {
  const simuPnl = state.history
    .filter((t) => t.est === "SIMU")
    .reduce((acc, t) => acc + t.pnl, 0);
  const simuBPnl = state.history
    .filter((t) => t.est === "SIMU_B")
    .reduce((acc, t) => acc + t.pnl, 0);
  const simuCPnl = state.history
    .filter((t) => t.est === "SIMU_C")
    .reduce((acc, t) => acc + t.pnl, 0);
  const realPnl = state.history
    .filter((t) => t.est === "REAL")
    .reduce((acc, t) => acc + t.pnl, 0);

  const totalUnrealized = state.activeTrades.reduce(
    (acc, t) => acc + (t.pnl || 0),
    0,
  );
  const realUnrealized = state.activeTrades
    .filter((t) => t.est === "REAL")
    .reduce((acc, t) => acc + (t.pnl || 0), 0);
  const simuUnrealized = state.activeTrades
    .filter((t) => t.est !== "REAL")
    .reduce((acc, t) => acc + (t.pnl || 0), 0);

  const dailyProfitGoal = state.cfg.dailyProfitGoal || 0;
  const targetEst = state.cfg.autoReal
    ? "REAL"
    : state.cfg.estrategiaReal || "SIMU";

  const alertSentRef = useRef(false);

  const [isSendingTest, setIsSendingTest] = useState(false);
  const [testingMotor, setTestingMotor] = useState<'A' | 'B' | 'C' | null>(null);
  const [testResult, setTestResult] = useState<"success" | "error" | null>(
    null,
  );

  const triggerTestWebhook = async (motorKey: 'A' | 'B' | 'C') => {
    setIsSendingTest(true);
    setTestingMotor(motorKey);
    setTestResult(null);
    try {
      const response = await fetch("/webhook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tipo: motorKey === "A" ? "GATILHO_SNIPER" : "GATILHO",
          moeda: "SOL",
          lado: "LONG",
          timeframe: "15m",
          preco_entrada: 165.42,
          r_vol: 1.8,
          adx: 31.2,
          rsi: 61.2,
          motor: motorKey,
        }),
      });
      if (response.ok) {
        setTestResult("success");
        setTimeout(() => setTestResult(null), 5000);
      } else {
        setTestResult("error");
        setTimeout(() => setTestResult(null), 5000);
      }
    } catch (err) {
      setTestResult("error");
      setTimeout(() => setTestResult(null), 5000);
    } finally {
      setIsSendingTest(false);
      setTestingMotor(null);
    }
  };

  const todayPnl = useMemo(() => {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const start = startOfToday.getTime();

    return state.history
      .filter((t) => t.est === targetEst && t.tsIn >= start)
      .reduce((acc, t) => acc + t.pnl, 0);
  }, [state.history, targetEst]);

  const chartData = useMemo(() => {
    let currentA = 0;
    let currentB = 0;
    let currentC = 0;
    return [...state.history]
      .reverse()
      .filter((t) => t.est === "SIMU" || t.est === "SIMU_B" || t.est === "SIMU_C")
      .map((t, idx) => {
        if (t.est === "SIMU") currentA += t.pnl;
        if (t.est === "SIMU_B") currentB += t.pnl;
        if (t.est === "SIMU_C") currentC += t.pnl;
        return {
          name: idx.toString(),
          simuA: currentA,
          simuB: currentB,
          simuC: currentC,
          time: t.dataFim,
        };
      });
  }, [state.history]);

  const drawdownData = useMemo(() => {
    let currentPnl = 0;
    let peak = 0;

    // We need starting balance to calculate percentage
    const currentBalance =
      targetEst === "REAL" ? state.balance : state.simuBalance;

    // First pass: find total PNL to know the initial balance
    const totalHistoryPnl = [...state.history]
      .filter((t) => t.est === targetEst)
      .reduce((acc, t) => acc + t.pnl, 0);
    const initialBalance = currentBalance - totalHistoryPnl;

    const pnlHistory: number[] = [];

    return [...state.history]
      .reverse()
      .filter((t) => t.est === targetEst)
      .map((t, idx, arr) => {
        currentPnl += t.pnl;
        pnlHistory.push(currentPnl);

        if (currentPnl > peak) {
          peak = currentPnl;
        }
        const drawdown = currentPnl - peak; // This is a negative value or zero

        const peakBalance = initialBalance + peak;
        const drawdownPct =
          peakBalance > 0 ? (Math.abs(drawdown) / peakBalance) * 100 : 0;

        const last10 = pnlHistory.slice(-10);
        const ma10 = last10.reduce((acc, val) => acc + val, 0) / last10.length;

        return {
          name: idx.toString(),
          time: t.dataFim,
          drawdown: drawdown,
          drawdownPct: drawdownPct,
          currentPnl: currentPnl,
          ma10: ma10,
        };
      });
  }, [state.history, targetEst, state.balance, state.simuBalance]);

  const currentLimitY = useMemo(() => {
    if (!state.cfg.drawdownThreshold || drawdownData.length === 0) return null;

    const currentBalance =
      targetEst === "REAL" ? state.balance : state.simuBalance;
    const totalHistoryPnl = [...state.history]
      .filter((t) => t.est === targetEst)
      .reduce((acc, t) => acc + t.pnl, 0);
    const initialBalance = currentBalance - totalHistoryPnl;

    let currentPnl = 0;
    let peak = 0;
    [...state.history]
      .reverse()
      .filter((t) => t.est === targetEst)
      .forEach((t) => {
        currentPnl += t.pnl;
        if (currentPnl > peak) peak = currentPnl;
      });

    const peakBalance = initialBalance + peak;
    return -(state.cfg.drawdownThreshold / 100) * peakBalance;
  }, [
    state.history,
    targetEst,
    state.balance,
    state.simuBalance,
    state.cfg.drawdownThreshold,
    drawdownData,
  ]);

  const maxDrawdownInfo = useMemo(() => {
    if (drawdownData.length === 0) return null;
    const lowestPoint = [...drawdownData].reduce((acc, curr) =>
      curr.drawdown < acc.drawdown ? curr : acc,
      drawdownData[0],
    );
    return {
      value: lowestPoint.drawdown,
      pct: lowestPoint.drawdownPct,
    };
  }, [drawdownData]);

  useEffect(() => {
    if (state.cfg.drawdownThreshold && drawdownData.length > 0) {
      const lastPoint = drawdownData[drawdownData.length - 1];
      const currentDdPct = lastPoint.drawdownPct;
      if (currentDdPct > state.cfg.drawdownThreshold) {
        if (!alertSentRef.current) {
          fetch("/api/alert-drawdown", {
            method: "POST",
            body: JSON.stringify({
              value: currentDdPct.toFixed(2),
              threshold: state.cfg.drawdownThreshold,
            }),
          });
          alertSentRef.current = true;
        }
      } else {
        alertSentRef.current = false;
      }
    }
  }, [drawdownData, state.cfg.drawdownThreshold]);

  const avgVolatility = useMemo(() => {
    if (!state.receivedSignals || state.receivedSignals.length === 0) return 0;
    // Pega os últimos 10 sinais para a média
    const recent = state.receivedSignals.slice(-10);
    const sum = recent.reduce((acc, s) => acc + (s.rVol || 0), 0);
    return sum / recent.length;
  }, [state.receivedSignals]);

  // Fallback for settings threshold
  const volThreshold = state.cfg.volatilityThreshold || 2.5;

  const strategyDrift = realPnl - simuPnl;
  const driftPercentage =
    simuPnl !== 0 ? (strategyDrift / Math.abs(simuPnl)) * 100 : 0;
  const showDriftAlert = strategyDrift <= -5 && driftPercentage <= -10;

  const exportHistory = () => {
    const dataStr =
      "data:text/json;charset=utf-8," +
      encodeURIComponent(JSON.stringify(state.history, null, 2));
    const dlAnchorElem = document.createElement("a");
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute(
      "download",
      `historico_simulacao_${new Date().toISOString().slice(0, 10)}.json`,
    );
    document.body.appendChild(dlAnchorElem);
    dlAnchorElem.click();
    dlAnchorElem.remove();
  };

  const lastDrawdownPoint =
    drawdownData.length > 0 ? drawdownData[drawdownData.length - 1] : null;
  const isRiskExceeded =
    lastDrawdownPoint &&
    state.cfg.drawdownThreshold &&
    lastDrawdownPoint.drawdownPct > state.cfg.drawdownThreshold;
  const isTrendDown =
    lastDrawdownPoint && lastDrawdownPoint.currentPnl < lastDrawdownPoint.ma10;

  let ddBorderClass = "border-slate-800";
  if (isRiskExceeded) {
    ddBorderClass =
      "border-rose-500 animate-pulse shadow-[0_0_20px_rgba(244,63,94,0.6)]";
  } else if (isTrendDown) {
    ddBorderClass =
      "border-amber-500 animate-pulse shadow-[0_0_20px_rgba(245,158,11,0.6)]";
  }

  return (
    <div className="flex flex-col gap-6 w-full max-w-6xl mx-auto min-h-full pb-12 text-slate-300">
      <div>
        <h1 className="text-3xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-400 drop-shadow-[0_0_10px_rgba(236,72,153,0.5)] tracking-wider">
          HONRANDO E PROSPERANDO PARA A GLÓRIA DE DEUS
        </h1>
        <p className="text-center font-mono text-cyan-300/80 italic mt-2">
          "Tudo posso Naquele que me fortalece." (Fil. 4:13)
        </p>
      </div>

      <DailyGoalIndicator
        todayPnl={todayPnl}
        dailyGoal={dailyProfitGoal}
        targetEst={targetEst}
      />

      <StaleTradesWatcher
        activeTrades={state.activeTrades}
        history={state.history}
      />

      {/* Volatility Guardian Indicator */}
      <VolatilityGuardian
        avgVolatility={avgVolatility}
        volThreshold={volThreshold}
        showDriftAlert={showDriftAlert}
        realPnl={realPnl}
        simuPnl={simuPnl}
        driftPercentage={driftPercentage}
        strategyDrift={strategyDrift}
      />

      {/* Extreme RSI Radar Monitoring Compass */}
      {state.cfg.useRsiFilter !== false && <LiveRsiMonitor state={state} />}

      {/* Unrealized PnL Summary Dashboard */}
      <div className="bg-[#050614]/80 backdrop-blur-md border border-cyan-500/30 rounded-2xl p-6 shadow-xl flex flex-col gap-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex items-center justify-between border-b border-cyan-900/30 pb-3">
          <h2 className="text-sm font-black text-cyan-400 tracking-widest uppercase py-1 drop-shadow-[0_0_5px_rgba(34,211,238,0.5)]">
            VISÃO GERAL ABERTA (UNREALIZED PNL)
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#0A0C1A] border border-cyan-900/50 rounded-xl p-4 flex flex-col justify-center shadow-inner relative group">
            <span className="text-[10px] font-bold text-slate-500 tracking-widest uppercase mb-1">
              TOTAL GLOBAL
            </span>
            <span
              className={`text-3xl font-black ${totalUnrealized >= 0 ? "text-[#00FFA3] drop-shadow-[0_0_8px_rgba(0,255,163,0.4)]" : "text-rose-500 drop-shadow-[0_0_8px_rgba(244,63,94,0.4)]"}`}
            >
              {totalUnrealized >= 0 ? "+" : ""}${totalUnrealized.toFixed(2)}
            </span>
          </div>

          <div className="bg-[#0A0C1A] border border-cyan-900/50 rounded-xl p-4 flex flex-col justify-center shadow-inner relative">
            <span className="text-[10px] font-bold text-slate-500 tracking-widest uppercase mb-1 flex items-center justify-between gap-2">
              CONTA REAL
            </span>
            <span
              className={`text-2xl font-black ${realUnrealized >= 0 ? "text-[#00FFA3] drop-shadow-[0_0_8px_rgba(0,255,163,0.4)]" : "text-rose-500 drop-shadow-[0_0_8px_rgba(244,63,94,0.4)]"}`}
            >
              {realUnrealized >= 0 ? "+" : ""}${realUnrealized.toFixed(2)}
            </span>
          </div>

          <div className="bg-[#0A0C1A] border border-cyan-900/50 rounded-xl p-4 flex flex-col justify-center shadow-inner relative">
            <span className="text-[10px] font-bold text-slate-500 tracking-widest uppercase mb-1 flex items-center justify-between gap-2">
              SIMULADORES (A + B)
            </span>
            <span
              className={`text-2xl font-black ${simuUnrealized >= 0 ? "text-[#00FFA3] drop-shadow-[0_0_8px_rgba(0,255,163,0.4)]" : "text-rose-500 drop-shadow-[0_0_8px_rgba(244,63,94,0.4)]"}`}
            >
              {simuUnrealized >= 0 ? "+" : ""}${simuUnrealized.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Top Value Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#0B0C1A]/80 backdrop-blur-md border border-cyan-400/30 rounded-2xl p-6 shadow-[0_0_20px_rgba(34,211,238,0.1)] flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl"></div>
          <span className="text-cyan-400/80 text-xs font-bold tracking-widest mb-2 z-10">
            PATRIMÔNIO (REAL)
          </span>
          <span className="text-5xl font-black text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)] z-10">
            ${state.balance.toFixed(2)}
          </span>
        </div>

        <div className="bg-[#0B0C1A]/80 backdrop-blur-md border border-green-500/30 rounded-2xl p-6 shadow-[0_0_20px_rgba(34,197,94,0.1)] flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute -left-10 -bottom-10 w-32 h-32 bg-green-500/10 rounded-full blur-2xl"></div>
          <span className="text-green-400/80 text-xs font-bold tracking-widest mb-2 z-10">
            BANCA (SIMULADOR)
          </span>
          <span className="text-5xl font-black text-white font-mono drop-shadow-[0_0_15px_rgba(255,255,255,0.4)] z-10">
            ${state.simuBalance.toFixed(2)}
          </span>
        </div>
      </div>

      {/* PNL Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0A0F1D]/90 border justify-center flex flex-col border-pink-500/50 rounded-2xl p-6 shadow-[0_0_15px_rgba(236,72,153,0.15)] relative overflow-hidden">
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-transparent"></div>
          <span className="text-xs font-bold text-slate-400 tracking-wider">
            LUCRO SESSÃO (REAL)
          </span>
          <span
            className={`text-3xl font-black mt-1 ${realPnl >= 0 ? "text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" : "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]"}`}
          >
            {realPnl >= 0 ? "+" : ""}${realPnl.toFixed(2)}
          </span>
        </div>
        <div className="bg-[#0A0F1D]/90 border justify-center flex flex-col border-cyan-400/50 rounded-2xl p-6 shadow-[0_0_15px_rgba(34,211,238,0.15)] relative overflow-hidden">
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-400 to-transparent"></div>
          <span className="text-xs font-bold text-slate-400 tracking-wider">
            LUCRO SESSÃO (SIMU A)
          </span>
          <span
            className={`text-3xl font-black mt-1 ${simuPnl >= 0 ? "text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" : "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]"}`}
          >
            {simuPnl >= 0 ? "+" : ""}${simuPnl.toFixed(2)}
          </span>
        </div>
        <div className="bg-[#0A0F1D]/90 border justify-center flex flex-col border-purple-500/50 rounded-2xl p-6 shadow-[0_0_15px_rgba(168,85,247,0.15)] relative overflow-hidden">
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-transparent"></div>
          <span className="text-xs font-bold text-slate-400 tracking-wider">
            LUCRO SESSÃO (SIMU B)
          </span>
          <span
            className={`text-3xl font-black mt-1 ${simuBPnl >= 0 ? "text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" : "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]"}`}
          >
            {simuBPnl >= 0 ? "+" : ""}${simuBPnl.toFixed(2)}
          </span>
        </div>
        <div className="bg-[#0A0F1D]/90 border justify-center flex flex-col border-amber-500/50 rounded-2xl p-6 shadow-[0_0_15px_rgba(245,158,11,0.15)] relative overflow-hidden">
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-transparent"></div>
          <span className="text-xs font-bold text-slate-400 tracking-wider">
            LUCRO SESSÃO (SIMU C)
          </span>
          <span
            className={`text-3xl font-black mt-1 ${simuCPnl >= 0 ? "text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" : "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]"}`}
          >
            {simuCPnl >= 0 ? "+" : ""}${simuCPnl.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Simulator Growth Chart */}
        <div className="bg-[#0B0C1A]/50 border border-slate-800 rounded-2xl p-5 shadow-[0_0_15px_rgba(0,0,0,0.5)]">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
            <h3 className="text-slate-400 font-bold text-xs tracking-widest uppercase">
              📈 CRESCIMENTO ACUMULADO
            </h3>
            <button
              onClick={exportHistory}
              className="text-[10px] font-bold text-cyan-400 tracking-widest uppercase bg-cyan-900/30 border border-cyan-500/30 px-3 py-1 rounded hover:bg-cyan-500/20 transition-colors flex items-center gap-2"
            >
              ⬇ EXPORTAR JSON
            </button>
          </div>
          <div className="h-64 w-full">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={chartData}
                  margin={{ top: 5, right: 20, bottom: 5, left: -20 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#1e293b"
                    vertical={false}
                  />
                  <XAxis dataKey="name" hide />
                  <YAxis
                    tick={{ fill: "#64748b", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0B0C1A",
                      borderColor: "#334155",
                      borderRadius: "8px",
                    }}
                    itemStyle={{ fontWeight: "bold" }}
                    labelStyle={{
                      color: "#94a3b8",
                      fontSize: 12,
                      marginBottom: 4,
                    }}
                    formatter={(val: number) => [
                      `$${val.toFixed(2)}`,
                      "PNL Acumulado",
                    ]}
                    labelFormatter={(_, payload) => {
                      if (payload && payload.length) {
                        return payload[0].payload.time;
                      }
                      return "";
                    }}
                  />
                  <Legend
                    iconType="circle"
                    wrapperStyle={{
                      fontSize: "11px",
                      fontWeight: "bold",
                      paddingTop: "10px",
                    }}
                  />
                  <Line
                    type="stepAfter"
                    dataKey="simuA"
                    name="Simulador A"
                    stroke="#22d3ee"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />
                  <Line
                    type="stepAfter"
                    dataKey="simuB"
                    name="Simulador B"
                    stroke="#a855f7"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />
                  <Line
                    type="stepAfter"
                    dataKey="simuC"
                    name="Simulador C"
                    stroke="#fbbf24"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-slate-500 text-xs italic">
                Sem dados suficientes para gerar o gráfico...
              </div>
            )}
          </div>
        </div>

        {/* Drawdown Chart */}
        <div
          id="drawdown-indicator"
          className={cn(
            "bg-[#0B0C1A]/50 border rounded-2xl p-5 transition-colors duration-1000",
            ddBorderClass,
          )}
        >
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
            <h3 className="text-slate-400 font-bold text-xs tracking-widest uppercase text-rose-500 drop-shadow-[0_0_5px_rgba(244,63,94,0.5)]">
              📉 DRAWDOWN ACUMULADO
            </h3>
            <div className="flex items-center gap-2">
              {isTrendDown && !isRiskExceeded && (
                <span className="text-[10px] font-black text-amber-500 tracking-widest bg-amber-900/30 px-2 py-0.5 rounded border border-amber-500/50 uppercase animate-pulse">
                  Alerta Trimestral (MA10)
                </span>
              )}
              {isRiskExceeded && (
                <span className="text-[10px] font-black text-rose-500 tracking-widest bg-rose-900/30 px-2 py-0.5 rounded border border-rose-500/50 uppercase animate-pulse">
                  Risco Excedido (
                  {lastDrawdownPoint?.drawdownPct?.toFixed(1) || 0}%)
                </span>
              )}
            </div>
          </div>
          <div className="h-64 w-full">
            {drawdownData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={drawdownData}
                  margin={{ top: 5, right: 20, bottom: 5, left: -20 }}
                >
                  <defs>
                    <linearGradient
                      id="colorDrawdown"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.5} />
                      <stop
                        offset="95%"
                        stopColor="#f43f5e"
                        stopOpacity={0.0}
                      />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#1e293b"
                    vertical={false}
                  />
                  <XAxis dataKey="name" hide />
                  <YAxis
                    tick={{ fill: "#64748b", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    domain={[
                      (dataMin: number) => {
                        const limit =
                          currentLimitY !== null && currentLimitY !== undefined
                            ? currentLimitY
                            : 0;
                        const maxVal =
                          maxDrawdownInfo && maxDrawdownInfo.value !== undefined
                            ? maxDrawdownInfo.value
                            : 0;
                        return Math.min(dataMin * 1.15, limit * 1.15, maxVal * 1.15, -10);
                      },
                      0,
                    ]}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0B0C1A",
                      borderColor: "#334155",
                      borderRadius: "8px",
                    }}
                    itemStyle={{ fontWeight: "bold" }}
                    labelStyle={{
                      color: "#94a3b8",
                      fontSize: 12,
                      marginBottom: 4,
                    }}
                    formatter={(val: number) => [
                      `$${val.toFixed(2)}`,
                      "Drawdown",
                    ]}
                    labelFormatter={(_, payload) => {
                      if (payload && payload.length) {
                        return payload[0].payload.time;
                      }
                      return "";
                    }}
                  />
                  <Legend
                    iconType="circle"
                    wrapperStyle={{
                      fontSize: "11px",
                      fontWeight: "bold",
                      paddingTop: "10px",
                    }}
                    {...({
                      payload: [
                        {
                          value: `Drawdown Histórico (${targetEst})`,
                          type: "rect",
                          id: "drawdown",
                          color: "#f43f5e",
                        },
                        ...(state.cfg.drawdownThreshold
                          ? [
                              {
                                value: `Limite de Risco (${state.cfg.drawdownThreshold}%)`,
                                type: "line",
                                id: "limit",
                                color: "#fb7185",
                              },
                            ]
                          : []),
                        ...(maxDrawdownInfo && maxDrawdownInfo.value !== 0
                          ? [
                              {
                                value: `DDR Máximo Atingido (-${maxDrawdownInfo.pct.toFixed(1)}%)`,
                                type: "line",
                                id: "max_pct",
                                color: "#f59e0b",
                              },
                            ]
                          : []),
                      ],
                    } as any)}
                  />
                  <Area
                    type="stepAfter"
                    dataKey="drawdown"
                    name="Drawdown Histórico"
                    stroke="#f43f5e"
                    fillOpacity={1}
                    fill="url(#colorDrawdown)"
                    strokeWidth={2}
                    activeDot={{ r: 4 }}
                  />
                  {currentLimitY !== null && currentLimitY !== undefined && (
                    <ReferenceLine
                      y={currentLimitY}
                      stroke="#fb7185"
                      strokeDasharray="4 4"
                      strokeWidth={1.5}
                      label={{
                        value: `LIMITE DE RISCO (${state.cfg.drawdownThreshold}%)`,
                        position: "top",
                        fill: "#fb7185",
                        fontSize: 9,
                        fontWeight: "bold",
                        letterSpacing: "0.05em",
                      }}
                    />
                  )}
                  {maxDrawdownInfo && maxDrawdownInfo.value !== 0 && (
                    <ReferenceLine
                      y={maxDrawdownInfo.value}
                      stroke="#f59e0b"
                      strokeDasharray="3 3"
                      strokeWidth={1.5}
                      label={{
                        value: `DDR MÁXIMO ATINGIDO (-${maxDrawdownInfo.pct.toFixed(1)}%)`,
                        position: "bottom",
                        fill: "#f59e0b",
                        fontSize: 9,
                        fontWeight: "bold",
                        letterSpacing: "0.05em",
                      }}
                    />
                  )}
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-slate-500 text-xs italic">
                Sem dados suficientes para gerar o gráfico...
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Radar Status Bar */}

      <div className="bg-[#0B0C1A] border border-cyan-400/20 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between shadow-[0_0_10px_rgba(34,211,238,0.05)] mt-4 gap-4">
        <div className="flex items-center gap-4">
          {state.cfg.radarAtivo && (
            <div className="w-6 h-6 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin shadow-[0_0_10px_rgba(34,211,238,0.5)]"></div>
          )}
          <div>
            <h3 className="text-white font-bold tracking-wide flex items-center gap-2">
              <span>RADAR WEBHOOK TRADINGVIEW</span>
              {state.receivedSignals && state.receivedSignals.length > 0 ? (
                <span className="text-[9px] bg-emerald-500 text-black px-2 py-0.5 rounded-full font-black animate-pulse uppercase tracking-wider">
                  Sincronizado ✅
                </span>
              ) : (
                <span className="text-[9px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-black uppercase tracking-wider animate-pulse">
                  Aguardando Sinal 📡
                </span>
              )}
            </h3>
            <p className="text-cyan-400/80 text-sm italic">
              {state.cfg.radarAtivo ? state.scanningStatus : "RADAR DESLIGADO"}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {state.receivedSignals && state.receivedSignals.length > 0 && (
            <button
              type="button"
              onClick={() => {
                const el = document.getElementById("terminal-logs-section");
                if (el) el.scrollIntoView({ behavior: "smooth" });
              }}
              className="bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-400 font-mono text-[10px] font-black tracking-widest px-3 py-1 rounded-lg flex items-center gap-1 shadow-[0_0_10px_rgba(16,185,129,0.2)] transition-all uppercase"
              title="A conexão deu certo! Clique para rolar até os logs de sinais recebidos."
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Sincronizado ✅
            </button>
          )}

          {/* Connection Test buttons for each of the three engines */}
          <div className="flex items-center gap-1.5 bg-[#05060C] border border-slate-800 rounded-xl p-1">
            <button
              type="button"
              onClick={() => triggerTestWebhook('A')}
              disabled={isSendingTest}
              className={cn(
                "hover:bg-[#101424] px-2.5 py-1.5 rounded-lg text-[10px] font-black tracking-wider uppercase transition-all whitespace-nowrap",
                testingMotor === 'A' ? "bg-amber-500 text-black shadow-[0_0_10px_rgba(245,158,11,0.4)] animate-pulse" : "text-amber-400 border border-amber-500/20 hover:border-amber-500/40"
              )}
              title="Testar Conexão do Motor A (Sniper Breakout/Ruptura)"
            >
              🚀 Testar A
            </button>
            <button
              type="button"
              onClick={() => triggerTestWebhook('B')}
              disabled={isSendingTest}
              className={cn(
                "hover:bg-[#101424] px-2.5 py-1.5 rounded-lg text-[10px] font-black tracking-wider uppercase transition-all whitespace-nowrap",
                testingMotor === 'B' ? "bg-cyan-500 text-black shadow-[0_0_10px_rgba(6,182,212,0.4)] animate-pulse" : "text-cyan-400 border border-cyan-500/20 hover:border-cyan-500/40"
              )}
              title="Testar Conexão do Motor B (TradingView)"
            >
              🧪 Testar B
            </button>
            <button
              type="button"
              onClick={() => triggerTestWebhook('C')}
              disabled={isSendingTest}
              className={cn(
                "hover:bg-[#101424] px-2.5 py-1.5 rounded-lg text-[10px] font-black tracking-wider uppercase transition-all whitespace-nowrap",
                testingMotor === 'C' ? "bg-pink-500 text-black shadow-[0_0_10px_rgba(236,72,153,0.4)] animate-pulse" : "text-pink-400 border border-pink-500/20 hover:border-pink-500/40"
              )}
              title="Testar Conexão do Motor C (Novo Motor/Futuro)"
            >
              ⚙️ Testar C
            </button>
          </div>

          {testResult === "success" && (
            <span className="text-[10px] text-emerald-400 font-mono animate-bounce bg-emerald-950/20 border border-emerald-500/20 px-2 py-1 rounded">
              Sinal recebido!
            </span>
          )}

          <div className="flex items-center gap-2 border-l border-slate-800 pl-3">
            <span className="text-xs font-bold text-slate-400 tracking-widest uppercase">
              Motor
            </span>
            <div
              className={`w-12 h-6 rounded-full relative transition-colors ${state.cfg.radarAtivo ? "bg-cyan-500" : "bg-slate-700"}`}
            >
              <div
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${state.cfg.radarAtivo ? "left-7 shadow-[0_0_8px_rgba(255,255,255,0.8)]" : "left-1"}`}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Webhook Connection Helper Card */}
      <div className="bg-[#0B0C1A] border border-purple-500/30 rounded-2xl p-5 shadow-[0_0_15px_rgba(168,85,247,0.1)] flex flex-col gap-3 relative group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-2xl pointer-events-none"></div>
        <div>
          <h3 className="text-purple-400 font-bold tracking-widest uppercase text-xs flex items-center gap-2">
            <span>🔌</span> DIRETRIZ DE INTEGRAÇÃO DO MOTOR EXTERNO (WEBHOOK)
          </h3>
          <p className="text-slate-400 text-[11px] font-medium leading-relaxed mt-1.5">
            Para sincronizar os sinais gerados no seu robô/PC local ou no
            TradingView para este painel, seu motor deve realizar chamadas REST
            POST com formato JSON para a URL desta instância:
          </p>
        </div>
        <div className="flex items-center gap-2 bg-black/60 border border-purple-500/25 rounded-xl p-2.5 font-mono text-xs text-purple-300 select-all overflow-x-auto w-full">
          {typeof window !== "undefined"
            ? `${window.location.origin}/webhook`
            : "https://.../webhook"}
        </div>
        <div className="text-[10px] text-amber-400/90 font-mono leading-relaxed bg-amber-950/20 border border-amber-500/20 rounded-xl p-3">
          ⚠️ <b>Ação Recomendada:</b> Abra o arquivo{" "}
          <code className="bg-slate-900 border border-slate-800 px-1 py-0.5 rounded text-white font-bold">
            script_sniper_v2.py
          </code>{" "}
          no seu editor local e mude a variável{" "}
          <code className="bg-slate-900 border border-slate-800 px-1 py-0.5 rounded text-white font-bold">
            RAILWAY_WEBHOOK_URL
          </code>{" "}
          para o endereço fúcsia acima. Assim que o motor de sinais disparar, os
          alertas e bloqueios ficarão visíveis instantaneamente!
        </div>
      </div>

      {/* Logs Terminal */}
      <div
        id="terminal-logs-section"
        className="flex flex-col flex-1 min-h-[300px] mt-2"
      >
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold text-pink-500 tracking-wider uppercase flex items-center gap-2 drop-shadow-[0_0_5px_rgba(236,72,153,0.5)]">
            <Terminal className="w-4 h-4 text-pink-500 animate-pulse" />
            LOGS AO VIVO:
          </h3>
          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest bg-slate-900/50 border border-slate-800/40 px-2 py-0.5 rounded">
            {state.logs.length} ENTRADAS REGISTRADAS
          </span>
        </div>
        <div className="bg-[#03040B] border border-pink-500/20 rounded-xl p-3 flex-1 overflow-y-auto font-mono text-xs shadow-inner max-h-[400px] flex flex-col gap-1.5">
          {state.logs.length === 0 ? (
            <div className="text-slate-500 italic text-center py-8">
              Nenhum log operacional gravado no momento...
            </div>
          ) : (
            state.logs.map((log, i) => {
              // Extract timestamp [HH:MM:SS] if exists
              const matchTime = log.match(/^\[([0-9:]+)\]/);
              const timestamp = matchTime ? matchTime[1] : null;
              const displayMsg = timestamp
                ? log.replace(/^\[[0-9:]+\]\s*/, "")
                : log;

              // Type identification
              const isError =
                log.includes("❌") ||
                log.includes("🔴") ||
                log.includes("ALERTA CRÍTICO") ||
                log.includes("bloqueado") ||
                log.includes("perda excedido") ||
                log.includes("bloqueada");
              const isAlert =
                log.includes("🟡") ||
                log.includes("⚠️") ||
                log.includes("AVISO") ||
                log.includes("ALERTA RSI") ||
                log.includes("Drawdown") ||
                log.includes("excedeu");
              const isSuccess =
                log.includes("✅") ||
                log.includes("SUCESSO") ||
                log.includes("🔑") ||
                log.includes("Atualizada") ||
                log.includes("CONCLUÍDO");
              const isTrade =
                log.includes("⚡") ||
                log.includes("ORDEM") ||
                log.includes("TRADE") ||
                log.includes("COMPRA") ||
                log.includes("VENDA") ||
                log.includes("ENTROU") ||
                log.includes("SAIU") ||
                log.includes("GATILHO") ||
                log.includes("Executando");

              let itemBg = "bg-slate-950/20 border-slate-900/30";
              let textClass = "text-slate-400";
              let iconEl = (
                <Info className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              );
              let labelClass =
                "bg-slate-500/10 text-slate-500 border-slate-800";
              let labelText = "SYSTEM";

              if (isError) {
                itemBg =
                  "bg-rose-950/15 border-rose-950/40 shadow-[0_0_10px_rgba(244,63,94,0.03)]";
                textClass = "text-rose-400";
                iconEl = (
                  <XCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                );
                labelClass = "bg-rose-500/10 text-rose-400 border-rose-500/30";
                labelText = "ERROR";
              } else if (isAlert) {
                itemBg =
                  "bg-amber-950/15 border-amber-950/40 shadow-[0_0_10px_rgba(245,158,11,0.03)]";
                textClass = "text-amber-400";
                iconEl = (
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                );
                labelClass =
                  "bg-amber-500/10 text-amber-400 border-amber-500/30";
                labelText = "WARN";
              } else if (isSuccess) {
                itemBg = "bg-emerald-950/15 border-emerald-950/40";
                textClass = "text-emerald-400";
                iconEl = (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                );
                labelClass =
                  "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
                labelText = "SUCCESS";
              } else if (isTrade) {
                itemBg = "bg-cyan-950/15 border-cyan-950/40";
                textClass = "text-cyan-400";
                iconEl = (
                  <TrendingUp className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                );
                labelClass = "bg-cyan-500/10 text-cyan-400 border-cyan-500/30";
                labelText = "TRADE";
              }

              return (
                <div
                  key={i}
                  className={cn(
                    "flex flex-col sm:flex-row items-start sm:items-center gap-2 px-3 py-2 border rounded-lg transition-all duration-200",
                    "hover:bg-[#070914] hover:scale-[1.002]",
                    itemBg,
                  )}
                >
                  {/* Left Column: Log meta icons */}
                  <div className="flex items-center gap-2 shrink-0">
                    {/* Timestamp */}
                    {timestamp && (
                      <span className="text-[10px] text-slate-500 font-mono tracking-tighter shrink-0 bg-slate-950 border border-slate-900/60 px-1.5 py-0.5 rounded">
                        {timestamp}
                      </span>
                    )}

                    {/* Tag badge with icon */}
                    <div
                      className={cn(
                        "flex items-center gap-1 px-1.5 py-0.5 rounded text-[8px] font-black tracking-wider uppercase border font-mono select-none",
                        labelClass,
                      )}
                    >
                      {iconEl}
                      <span>{labelText}</span>
                    </div>
                  </div>

                  {/* Right Column: Log message text */}
                  <div
                    className={cn(
                      "text-[11px] sm:text-xs font-mono leading-relaxed break-all flex-1",
                      textClass,
                    )}
                  >
                    {displayMsg}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

import React, { useMemo, useState } from "react";
import { Signal, Trade } from "../types.js";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  AreaChart,
  Area,
  CartesianGrid,
} from "recharts";
import { Info } from "lucide-react";
import { cn } from "../lib/utils.js";

export function SignalsView({
  signals,
  history = [],
}: {
  signals: Signal[];
  history?: Trade[];
}) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [searchCoin, setSearchCoin] = useState("");

  const filteredSignals = useMemo(() => {
    if (!searchCoin.trim()) return signals;
    return signals.filter((s) =>
      s.moeda.toUpperCase().includes(searchCoin.trim().toUpperCase()),
    );
  }, [signals, searchCoin]);

  const volumeData = useMemo(() => {
    const counts: Record<string, number> = {};
    signals.forEach((s) => {
      const date = new Date(s.tsIn);
      const hour = date.getHours().toString().padStart(2, "0") + ":00";
      counts[hour] = (counts[hour] || 0) + 1;
    });
    const data = [];
    for (let i = 0; i < 24; i++) {
      const hourStr = i.toString().padStart(2, "0") + ":00";
      data.push({
        hour: hourStr,
        volume: counts[hourStr] || 0,
      });
    }
    return data;
  }, [signals]);

  const analytics = useMemo(() => {
    const simuHits = history.filter(
      (t) => t.est === "SIMU" || t.est === "SIMU_B",
    );

    const byCoin = simuHits.reduce(
      (acc, t) => {
        const coin = t.symbol.replace("/USDT", "");
        if (!acc[coin])
          acc[coin] = { coin, wins: 0, losses: 0, pnl: 0, total: 0 };
        acc[coin].total++;
        acc[coin].pnl += t.pnl;
        if (t.pnl > 0) acc[coin].wins++;
        else acc[coin].losses++;
        return acc;
      },
      {} as Record<
        string,
        {
          coin: string;
          wins: number;
          losses: number;
          pnl: number;
          total: number;
        }
      >,
    );

    const coinData = Object.values(byCoin)
      .map((d) => ({ ...d, wr: Math.round((d.wins / d.total) * 100) || 0 }))
      .sort((a, b) => b.wr - a.wr)
      .slice(0, 5);

    const bySide = simuHits.reduce(
      (acc, t) => {
        if (!acc[t.side]) acc[t.side] = { side: t.side, wins: 0, total: 0 };
        acc[t.side].total++;
        if (t.pnl > 0) acc[t.side].wins++;
        return acc;
      },
      {} as Record<string, { side: string; wins: number; total: number }>,
    );

    const sideData = Object.values(bySide).map((d) => ({
      ...d,
      wr: Math.round((d.wins / d.total) * 100) || 0,
    }));

    return { coinData, sideData };
  }, [history]);

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto min-h-full pb-12 text-slate-300">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-purple-400 tracking-widest drop-shadow-[0_0_15px_rgba(168,85,247,0.6)] uppercase flex items-center gap-3">
          <span>📡</span> SINAIS TRADINGVIEW (AOVIVO)
        </h2>
      </div>

      {/* Signal Volume Area Chart */}
      <div className="bg-[#0B0C1A] border border-blue-500/20 rounded-xl p-5 shadow-[0_0_15px_rgba(59,130,246,0.05)] w-full">
        <div className="flex items-center gap-2 mb-4 border-b border-blue-500/20 pb-2 relative group">
          <h3 className="text-blue-400 font-bold text-xs tracking-widest uppercase">
            🌊 VOLUME DE SINAIS POR HORA (VOLATILIDADE)
          </h3>
          <Info className="w-4 h-4 text-blue-500/50 hover:text-blue-400 cursor-help" />
          <div className="absolute top-8 left-0 opacity-0 group-hover:opacity-100 transition-opacity bg-[#050510] border border-cyan-500/30 text-[10px] text-cyan-400 font-mono px-3 py-2 rounded shadow-xl pointer-events-none z-50 max-w-sm drop-shadow-[0_0_5px_rgba(34,211,238,0.3)]">
            Identifica padrões de horário com maior volume de oportunidades do
            robô, útil para detectar picos de volatilidade do mercado em certas
            sessões globais.
          </div>
        </div>
        <div className="h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={volumeData}
              margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#1e293b"
                vertical={false}
              />
              <XAxis
                dataKey="hour"
                stroke="#64748b"
                fontSize={10}
                tickLine={false}
                axisLine={false}
                tickMargin={10}
              />
              <YAxis
                stroke="#64748b"
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0B0C1A",
                  borderColor: "#3b82f6",
                  borderRadius: "8px",
                  borderStyle: "solid",
                  borderWidth: "1px",
                }}
                itemStyle={{ color: "#60a5fa", fontWeight: "bold" }}
                labelStyle={{ color: "#94a3b8" }}
              />
              <Area
                type="monotone"
                dataKey="volume"
                name="Qtd Sinais"
                stroke="#3b82f6"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorVolume)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Analytics Dashboard */}
      {history.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0B0C1A] border border-cyan-500/20 rounded-xl p-5 shadow-[0_0_15px_rgba(34,211,238,0.05)]">
            <div className="flex items-center gap-2 mb-4 border-b border-cyan-500/20 pb-2 relative group">
              <h3 className="text-cyan-400 font-bold text-xs tracking-widest uppercase">
                🏆 TOP MOEDAS (WIN RATE SIMULADO)
              </h3>
              <Info className="w-4 h-4 text-cyan-500/50 hover:text-cyan-400 cursor-help" />
              <div className="absolute top-8 left-0 opacity-0 group-hover:opacity-100 transition-opacity bg-[#050510] border border-cyan-500/30 text-[10px] text-cyan-400 font-mono px-3 py-2 rounded shadow-xl pointer-events-none z-50 max-w-sm drop-shadow-[0_0_5px_rgba(34,211,238,0.3)]">
                Ranking das moedas com a maior taxa de acerto no trade virtual
                para os sinais recentes. Use isso para aplicar filtros de
                exclusão no bot real.
              </div>
            </div>
            <div className="h-40">
              {analytics.coinData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={analytics.coinData}
                    layout="vertical"
                    margin={{ top: 0, right: 30, left: 0, bottom: 0 }}
                  >
                    <XAxis type="number" hide domain={[0, 100]} />
                    <YAxis
                      dataKey="coin"
                      type="category"
                      width={60}
                      tick={{
                        fill: "#94a3b8",
                        fontSize: 11,
                        fontWeight: "bold",
                      }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0B0C1A",
                        borderColor: "#22d3ee",
                        borderRadius: "8px",
                        borderStyle: "solid",
                        borderWidth: "1px",
                      }}
                      itemStyle={{ color: "#ec4899", fontWeight: "bold" }}
                      formatter={(value: number) => [`${value}%`, "WR"]}
                    />
                    <Bar dataKey="wr" radius={[0, 4, 4, 0]} barSize={20}>
                      {analytics.coinData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.wr >= 50 ? "#4ade80" : "#ef4444"}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center text-slate-500 text-xs italic">
                  Sem dados suficientes (Aguardando resultados do simulador)...
                </div>
              )}
            </div>
          </div>

          <div className="bg-[#0B0C1A] border border-pink-500/20 rounded-xl p-5 shadow-[0_0_15px_rgba(236,72,153,0.05)]">
            <div className="flex items-center gap-2 mb-4 border-b border-pink-500/20 pb-2 relative group">
              <h3 className="text-pink-500 font-bold text-xs tracking-widest uppercase">
                ⚖️ PERFORMANCE POR LADO (BUY / SELL)
              </h3>
              <Info className="w-4 h-4 text-pink-500/50 hover:text-pink-400 cursor-help" />
              <div className="absolute top-8 right-0 opacity-0 group-hover:opacity-100 transition-opacity bg-[#050510] border border-cyan-500/30 text-[10px] text-cyan-400 font-mono px-3 py-2 rounded shadow-xl pointer-events-none z-50 max-w-sm drop-shadow-[0_0_5px_rgba(34,211,238,0.3)]">
                Ajuda a identificar um viés do mercado atual. Se Shorts(vendas)
                performam 80% e Longs(compras) 20%, o mercado está em tendência
                de baixa macro, devendo-se considerar operar apenas shorts
                mitigando drawdown.
              </div>
            </div>
            <div className="flex h-40 items-center justify-around">
              {analytics.sideData.length > 0 ? (
                analytics.sideData.map((d) => (
                  <div key={d.side} className="flex flex-col items-center">
                    <div
                      className="relative w-24 h-24 rounded-full border-4 flex flex-col items-center justify-center bg-black/50"
                      style={{
                        borderColor:
                          d.side === "LONG"
                            ? "rgba(74,222,128,0.5)"
                            : "rgba(239,68,68,0.5)",
                      }}
                    >
                      <span className="text-2xl font-black text-white">
                        {d.wr}%
                      </span>
                    </div>
                    <span
                      className={`mt-3 font-bold tracking-widest uppercase ${d.side === "LONG" ? "text-green-400" : "text-red-500"}`}
                    >
                      {d.side}
                    </span>
                    <span className="text-xs text-slate-500 mt-1 font-mono">
                      {d.total} sinais
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 text-xs italic px-6 text-center">
                  Precisa rodar o simulador para coletar estes dados...
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Sinais Table Extracted */}
      <div className="flex-1 overflow-auto rounded-xl flex flex-col gap-4">
        <div className="flex justify-end">
          <input
            type="text"
            value={searchCoin}
            onChange={(e) => setSearchCoin(e.target.value.toUpperCase())}
            placeholder="BUSCAR MOEDA (EX: BTC)"
            className="bg-[#050510] border border-cyan-500/20 hover:border-cyan-500/50 focus:border-cyan-400 rounded-lg px-4 py-2 text-[10px] font-bold text-white tracking-widest uppercase focus:outline-none transition-colors w-full md:w-64 placeholder:text-slate-600 font-mono shadow-[0_0_15px_rgba(34,211,238,0.05)]"
          />
        </div>

        <div className="bg-[#0A0F1D] border border-purple-500/30 rounded-xl overflow-hidden min-w-[900px] flex flex-col h-full shadow-[0_0_20px_rgba(168,85,247,0.1)]">
          <div className="flex px-4 py-3 bg-[#0B0C1A] border-b border-purple-500/30 text-xs font-bold text-purple-400 tracking-widest uppercase">
            <div className="w-24">HORÁRIO</div>
            <div className="w-28">MOEDA</div>
            <div className="w-20">TEMPO</div>
            <div className="w-24">LADO</div>
            <div className="w-32">PREÇO ALVO</div>
            <div className="flex-1">MÉTRICAS / CONFLUÊNCIA</div>
            <div className="w-32 text-center">GRÁFICO REAL</div>
          </div>

          <div className="flex flex-col p-2 gap-2 overflow-y-auto">
            {filteredSignals.length === 0 && (
              <div className="p-8 text-center text-slate-500 text-sm italic font-bold tracking-widest uppercase mt-10">
                {signals.length === 0
                  ? "Aguardando sinais chegarem do webhook..."
                  : "Nenhuma moeda encontrada com esse filtro"}
              </div>
            )}

            {filteredSignals.map((s, idx) => {
              const isLong = s.lado === "LONG";
              const tvInterval =
                s.tf === "30m"
                  ? "30"
                  : s.tf === "1h"
                    ? "60"
                    : s.tf === "2h"
                      ? "120"
                      : "60";
              const isExpanded = expandedId === s.id + idx;
              return (
                <div
                  key={s.id + idx}
                  className="flex flex-col bg-[#111326] border border-purple-500/10 rounded-lg shadow-sm group hover:border-purple-500/50 transition-colors"
                >
                  <div className="flex items-center px-4 py-3">
                    <div className="w-24 text-xs font-mono text-slate-400">
                      {s.horaIn}
                    </div>
                    <div className="w-28 flex flex-col justify-center">
                      <div className="font-black text-white text-sm tracking-wider group-hover:text-cyan-400 transition-colors">
                        🔥 {s.moeda}
                      </div>
                      {s.motor && (
                        <div
                          className="text-[7.5px] font-mono font-black tracking-widest uppercase text-slate-500 mt-0.5"
                          title="Origem do Sinal"
                        >
                          <span
                            className={
                              s.motor === "Motor EXTERNO A"
                                ? "text-purple-400"
                                : "text-cyan-500"
                            }
                          >
                            {s.motor}
                          </span>
                        </div>
                      )}
                      {s.status && (
                        <div className="mt-1.5 shrink-0 flex">
                          {s.status === "BLOQUEADO" && (
                            <span
                              className="text-[8px] font-mono leading-none py-0.5 px-1.5 rounded bg-rose-500/10 border border-rose-500/40 text-rose-400 font-extrabold uppercase"
                              title={s.motivoBloqueio}
                            >
                              BLOQUEADO
                            </span>
                          )}
                          {s.status === "ARMADO" && (
                            <span className="text-[8px] font-mono leading-none py-0.5 px-1.5 rounded bg-amber-500/10 border border-amber-500/40 text-amber-400 font-extrabold uppercase animate-pulse">
                              ARMADO
                            </span>
                          )}
                          {s.status === "DESCARTADO" && (
                            <span className="text-[8px] font-mono leading-none py-0.5 px-1.5 rounded bg-slate-800 border border-slate-700 text-slate-400 font-extrabold uppercase">
                              DESCARTADO
                            </span>
                          )}
                          {s.status === "GATILHO_EXECUTADO" && (
                            <span className="text-[8px] font-mono leading-none py-0.5 px-1.5 rounded bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 font-extrabold uppercase">
                              EXECUTADO
                            </span>
                          )}
                          {s.status === "PENDENTE" && (
                            <span className="text-[8px] font-mono leading-none py-0.5 px-1.5 rounded bg-cyan-500/10 border border-cyan-500/40 text-cyan-400 font-extrabold uppercase">
                              PENDENTE
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="w-20 text-xs font-bold text-yellow-500 tracking-widest">
                      {s.tf}
                    </div>
                    <div
                      className={`w-24 font-black text-sm tracking-widest uppercase ${isLong ? "text-green-400 drop-shadow-[0_0_5px_rgba(74,222,128,0.5)]" : "text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]"}`}
                    >
                      {s.lado}
                    </div>
                    <div className="w-32 flex flex-col justify-center font-mono">
                      <span className="text-white text-sm font-bold">
                        ALVO: ${(s.extremo || 0).toFixed(4)}
                      </span>
                    </div>
                    <div className="flex-1 flex gap-3 text-xs font-mono font-bold items-center">
                      <span className="bg-purple-900/30 text-purple-400 px-2 py-1 rounded border border-purple-500/30 drop-shadow-[0_0_5px_rgba(168,85,247,0.3)]">
                        R-VOL: {s.rVol}x
                      </span>
                      <span className="bg-cyan-900/30 text-cyan-400 px-2 py-1 rounded border border-cyan-500/30 drop-shadow-[0_0_5px_rgba(34,211,238,0.3)]">
                        ADX: {s.adx}
                      </span>
                      <span className="bg-emerald-900/30 text-emerald-400 px-2 py-1 rounded border border-emerald-500/30 drop-shadow-[0_0_5px_rgba(16,185,129,0.3)]">
                        RSI: {s.rsi ?? "--"}
                      </span>
                      {s.motivoBloqueio && (
                        <span className="text-red-400 font-black text-[10px] animate-pulse ml-2 flex items-center gap-1 bg-red-950/20 border border-red-500/20 px-2 py-1 rounded">
                          ⚠️ {s.motivoBloqueio}
                        </span>
                      )}
                      <button
                        onClick={() =>
                          setExpandedId(isExpanded ? null : s.id + idx)
                        }
                        className="ml-auto text-[10px] bg-slate-800 hover:bg-slate-700 font-bold uppercase px-2 py-1 rounded border border-slate-600 transition-colors"
                      >
                        {isExpanded ? "ESCONDER RAW" : "VER RAW"}
                      </button>
                    </div>
                    <div className="w-32 flex justify-center ml-2">
                      <a
                        href={`https://www.tradingview.com/chart/?symbol=BINANCE:${s.moeda}USDT.P&interval=${tvInterval}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-gradient-to-r from-blue-600 to-blue-800 text-white border border-blue-500/50 hover:from-blue-500 hover:to-blue-700 px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all shadow-[0_0_15px_rgba(37,99,235,0.4)] flex items-center gap-2"
                      >
                        ABRIR TV
                      </a>
                    </div>
                  </div>
                  {isExpanded && (
                    <div className="px-4 py-3 bg-black/50 border-t border-purple-500/10 font-mono text-[10px] text-slate-400 overflow-x-auto whitespace-pre-wrap">
                      <div className="mb-1 text-cyan-500 font-bold tracking-widest uppercase">
                        🔍 Payload Bruto:
                      </div>
                      {s.rawPayload || "Nenhum payload associado"}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

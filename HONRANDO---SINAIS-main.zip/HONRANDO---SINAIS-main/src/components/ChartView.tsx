import React, { useEffect, useRef, useState, useMemo } from 'react';
import { createChart, IChartApi, ISeriesApi, UTCTimestamp, LineStyle, CandlestickSeries, LineSeries, HistogramSeries, createSeriesMarkers, ColorType } from 'lightweight-charts';
import { LineChart, Maximize2, Layers, PenTool, Trash2, Activity, BarChart2, Waves, Eye, EyeOff, ChevronDown, SlidersHorizontal } from 'lucide-react';
import { calculateMACD, calculatePSAR, calculateDonchianChannel } from '../utils/indicators';
import { runSurfistaEngine } from '../utils/surfista';

function getPrecisionAndMinMove(price: number) {
  if (price === 0) return { precision: 2, minMove: 0.01 };
  const absPrice = Math.abs(price);
  if (absPrice < 0.0001) {
    return { precision: 8, minMove: 0.00000001 };
  } else if (absPrice < 0.01) {
    return { precision: 6, minMove: 0.000001 };
  } else if (absPrice < 1) {
    return { precision: 4, minMove: 0.0001 };
  } else if (absPrice < 10) {
    return { precision: 3, minMove: 0.001 };
  } else {
    return { precision: 2, minMove: 0.01 };
  }
}

export function ChartView({ symbol = 'BTCUSDT' }: { symbol?: string }) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const vpLinesRef = useRef<any[]>([]);
  const markersContainerRef = useRef<HTMLDivElement>(null);
  const manualMarkersContainerRef = useRef<HTMLDivElement>(null);
  const manualMarkersElementsRef = useRef<{el: HTMLDivElement, time: UTCTimestamp, price: number, position: string}[]>([]);
  const manualPriceLinesRef = useRef<any[]>([]);
  
  const [currentSymbol, setCurrentSymbol] = useState(symbol || 'BTCUSDT');
  const [inputValue, setInputValue] = useState(symbol || 'BTCUSDT');
  const [interval, setInterval] = useState('15m');
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState<any[]>([]);
  const [showVolumeProfile, setShowVolumeProfile] = useState(false);
  const [showPoc, setShowPoc] = useState(false);
  const [showMacd, setShowMacd] = useState(false);
  const [showVolume, setShowVolume] = useState(true);
  const [showSurfista, setShowSurfista] = useState(false);
  const [showSurfistaTable, setShowSurfistaTable] = useState(true);
  const [showPsar, setShowPsar] = useState(false);
  const [showDonchian, setShowDonchian] = useState(false);
  const [donchianPeriodType, setDonchianPeriodType] = useState<'20_candles' | '1_week' | '2_weeks'>('20_candles');
  const [isDrawing, setIsDrawing] = useState(false);
  const [indicatorsOpen, setIndicatorsOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [trendlinesCount, setTrendlinesCount] = useState(0);

  const [placeMarkerMode, setPlaceMarkerMode] = useState<'compra' | 'venda' | null>(null);
  const [manualMarkers, setManualMarkers] = useState<{id: string, time: UTCTimestamp, price: number, type: 'compra' | 'venda', symbol: string}[]>(() => {
      try {
          const saved = localStorage.getItem('manual_chart_markers');
          if (saved) return JSON.parse(saved);
      } catch (e) {}
      return [];
  });

  const isDrawingRef = useRef(false);
  const placeMarkerModeRef = useRef(placeMarkerMode);
  const chartDataRef = useRef(chartData);
  const currentSymbolRef = useRef(currentSymbol);
  
  useEffect(() => { placeMarkerModeRef.current = placeMarkerMode; }, [placeMarkerMode]);
  useEffect(() => { chartDataRef.current = chartData; }, [chartData]);
  useEffect(() => { currentSymbolRef.current = currentSymbol; }, [currentSymbol]);
  useEffect(() => { localStorage.setItem('manual_chart_markers', JSON.stringify(manualMarkers)); }, [manualMarkers]);

  const drawStartRef = useRef<{time: UTCTimestamp, price: number} | null>(null);
  const trendlineSeriesRef = useRef<Array<ISeriesApi<"Line">>>([]);
  const macdSeriesRef = useRef<{
    macdLine: ISeriesApi<"Line">;
    signalLine: ISeriesApi<"Line">;
    histogram: ISeriesApi<"Histogram">;
  } | null>(null);
  
  const surfistaRefs = useRef<{
    sma8: ISeriesApi<"Line">;
    sma21: ISeriesApi<"Line">;
    stLine: ISeriesApi<"Line">;
  } | null>(null);

  const psarSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const donchianSeriesRef = useRef<{
    upper: ISeriesApi<"Line">;
    lower: ISeriesApi<"Line">;
    middle: ISeriesApi<"Line">;
  } | null>(null);

  const donchianPeriod = useMemo(() => {
    if (donchianPeriodType === '20_candles') return 20;
    
    let candlesPerWeek = 20;
    switch (interval) {
      case '1s': candlesPerWeek = 604800; break;
      case '1m': candlesPerWeek = 10080; break;
      case '3m': candlesPerWeek = 3360; break;
      case '5m': candlesPerWeek = 2016; break;
      case '15m': candlesPerWeek = 672; break;
      case '30m': candlesPerWeek = 336; break;
      case '1h': candlesPerWeek = 168; break;
      case '2h': candlesPerWeek = 84; break;
      case '4h': candlesPerWeek = 42; break;
      case '1d': candlesPerWeek = 7; break;
    }
    
    const multiplier = donchianPeriodType === '2_weeks' ? 2 : 1;
    const targetPeriod = candlesPerWeek * multiplier;
    
    return Math.max(5, Math.min(targetPeriod, chartData.length));
  }, [donchianPeriodType, interval, chartData.length]);

  const surfistaResult = useMemo(() => {
    if (!showSurfista || chartData.length === 0) return null;
    return runSurfistaEngine(chartData, {
        margem: 1, alavancagem: 20, gatilho_surf: 15, dist_stop: 5, gatilho_be: 10, protecao_be: 0.5, stop_fixo: 10
    });
  }, [chartData, showSurfista]);

  const markersElementsRef = useRef<{el: HTMLDivElement, time: UTCTimestamp, price: number, position: string}[]>([]);

  useEffect(() => {
    let rAF: number;
    const updatePositions = () => {
        try {
            if (!seriesRef.current || !chartRef.current || (markersElementsRef.current.length === 0 && manualMarkersElementsRef.current.length === 0)) {
                rAF = requestAnimationFrame(updatePositions);
                return;
            }
            const timeScale = chartRef.current.timeScale();
            
            const processMarker = ({el, time, price, position}: any) => {
                const x = timeScale.timeToCoordinate(time);
                const y = seriesRef.current!.priceToCoordinate(price);
                
                if (position === 'left-button') {
                    if (y === null) {
                        if (el.style.display !== 'none') el.style.display = 'none';
                    } else {
                        if (el.style.display !== 'flex') el.style.display = 'flex';
                        const newTop = `${y}px`;
                        const newTransform = `translate(0, -50%)`;
                        if (el.style.top !== newTop) el.style.top = newTop;
                        if (el.style.transform !== newTransform) el.style.transform = newTransform;
                    }
                } else {
                    if (x === null || y === null) {
                        if (el.style.display !== 'none') el.style.display = 'none';
                    } else {
                        const newLeft = `${x}px`;
                        const newTop = position === 'aboveBar' ? `${y - 8}px` : `${y + 8}px`;
                        const newTransform = position === 'aboveBar' ? `translate(-50%, -100%)` : `translate(-50%, 0)`;

                        if (el.style.display !== 'flex') el.style.display = 'flex';
                        if (el.style.left !== newLeft) el.style.left = newLeft;
                        if (el.style.top !== newTop) el.style.top = newTop;
                        if (el.style.transform !== newTransform) el.style.transform = newTransform;
                    }
                }
            };

            markersElementsRef.current.forEach(processMarker);
            manualMarkersElementsRef.current.forEach(processMarker);

            rAF = requestAnimationFrame(updatePositions);
        } catch (e) {
            // Chart might be disposed
        }
    };

    updatePositions();
    return () => cancelAnimationFrame(rAF);
  }, []);

  useEffect(() => {
    if (showSurfista && surfistaResult && surfistaRefs.current && seriesRef.current) {
        surfistaRefs.current.sma8.setData(surfistaResult.sma8Line);
        surfistaRefs.current.sma21.setData(surfistaResult.sma21Line);
        surfistaRefs.current.stLine.setData(surfistaResult.stLine);
        
        if (markersContainerRef.current && chartRef.current && chartData.length > 0) {
            const container = markersContainerRef.current;
            
            // Performant hash check
            let currentMarkersHash = '';
            for (let i = 0; i < surfistaResult.markers.length; i++) {
                currentMarkersHash += surfistaResult.markers[i].time + surfistaResult.markers[i].text;
            }
            
            if (container.dataset.hash !== currentMarkersHash) {
                container.dataset.hash = currentMarkersHash;
                container.innerHTML = '';
                markersElementsRef.current = [];

                surfistaResult.markers.forEach(m => {
                    const el = document.createElement('div');
                    el.className = `absolute flex flex-col items-center justify-center transform -translate-x-1/2 z-10`;
                    el.style.pointerEvents = 'none';

                    if (m.position === 'aboveBar') {
                        // Arrow down, text above
                        el.innerHTML = `
                            <div style="background-color: ${m.color}" class="px-2 py-0.5 rounded text-[10px] font-bold shadow text-white tracking-widest">${m.text}</div>
                            <div style="border-top-color: ${m.color}" class="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[6px]"></div>
                        `;
                    } else {
                        // Arrow up, text below
                        el.innerHTML = `
                            <div style="border-bottom-color: ${m.color}" class="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[6px]"></div>
                            <div style="background-color: ${m.color}" class="px-2 py-0.5 rounded text-[10px] font-bold shadow text-white tracking-widest">${m.text}</div>
                        `;
                    }
                    
                    container.appendChild(el);

                    // Find candle price with a fallback for robustness
                    let price = m.price;
                    if (!price) {
                        const candle = chartData.find(d => d.time === m.time);
                        if (candle) {
                            price = m.position === 'aboveBar' ? candle.high : candle.low;
                        }
                    }

                    if (price) {
                        markersElementsRef.current.push({
                            el, 
                            time: m.time, 
                            price: price, 
                            position: m.position
                        });
                    }
                });
            }
        }
    } else {
        if (markersContainerRef.current) {
            markersContainerRef.current.innerHTML = '';
            markersElementsRef.current = [];
            markersContainerRef.current.dataset.hash = '';
        }
    }
  }, [surfistaResult, showSurfista, chartData]);

  useEffect(() => {
     if (!manualMarkersContainerRef.current || !chartRef.current || chartData.length === 0 || !seriesRef.current) return;
     const container = manualMarkersContainerRef.current;
     container.innerHTML = '';
     manualMarkersElementsRef.current = [];

     manualPriceLinesRef.current.forEach(line => seriesRef.current?.removePriceLine(line));
     manualPriceLinesRef.current = [];

     const currentSymbolMarkers = manualMarkers.filter(m => m.symbol === currentSymbol);

     currentSymbolMarkers.forEach(m => {
          let targetPrice = m.price;
          
          if (!chartData.some(d => d.time === m.time)) {
              let closest = chartData[0];
              for (let i = chartData.length - 1; i >= 0; i--) {
                  if (chartData[i].time <= m.time) {
                      closest = chartData[i];
                      break;
                  }
              }
              if (closest) {
                  // Keep origin logic somewhat consistent, but favor exact price if they clicked empty space
                  if (m.price === 0) {
                     targetPrice = m.type === 'compra' ? closest.low : closest.high;
                  }
              }
          }

          const isCompra = m.type === 'compra';
          const color = isCompra ? '#00e5ff' : '#ff00ff';
          const text = isCompra ? 'COMPRA' : 'VENDA';

          const priceLine = seriesRef.current!.createPriceLine({
              price: targetPrice,
              color: color,
              lineWidth: 2,
              lineStyle: LineStyle.Dashed,
              axisLabelVisible: true,
              title: text,
          });
          manualPriceLinesRef.current.push(priceLine);

          const el = document.createElement('div');
          el.className = `absolute flex items-center justify-center w-5 h-5 rounded-full bg-[#050510] border z-20 cursor-pointer pointer-events-auto shadow-[0_0_10px_rgba(0,0,0,0.5)] transition-transform hover:scale-110`;
          el.style.borderColor = color;
          el.style.color = color;
          el.style.left = '10px';
          el.onclick = () => {
              setManualMarkers(prev => prev.filter(marker => marker.id !== m.id));
          };
          el.title = "Remover sinal";
          el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
          
          container.appendChild(el);
          manualMarkersElementsRef.current.push({
              el, time: m.time, price: targetPrice, position: 'left-button'
          });
     });
  }, [manualMarkers, chartData, currentSymbol]);

  useEffect(() => {
    isDrawingRef.current = isDrawing;

  }, [isDrawing]);

  useEffect(() => {
    if (volumeSeriesRef.current) {
       volumeSeriesRef.current.applyOptions({ visible: showVolume });
    }
  }, [showVolume]);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Initialize chart
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: '#050510' },
        textColor: '#64748b',
      },
      grid: {
        vertLines: { color: 'rgba(30, 41, 59, 0.5)' },
        horzLines: { color: 'rgba(30, 41, 59, 0.5)' },
      },
      crosshair: {
        mode: 0,
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 12,
        shiftVisibleRangeOnNewBar: true,
      },
      handleScroll: {
        vertTouchDrag: true,
        horzTouchDrag: true,
        pressedMouseMove: true,
        mouseWheel: true,
      },
      handleScale: {
        axisPressedMouseMove: true,
      },
    });

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#00FFA3',
      downColor: '#f43f5e',
      borderVisible: false,
      wickUpColor: '#00FFA3',
      wickDownColor: '#f43f5e',
    });

    const volumeSeries = chart.addSeries(HistogramSeries, {
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: '',
    });
    volumeSeries.priceScale().applyOptions({
      scaleMargins: {
        top: 0.65,
        bottom: 0,
      },
    });

    chartRef.current = chart;
    seriesRef.current = candlestickSeries as ISeriesApi<"Candlestick">;
    volumeSeriesRef.current = volumeSeries as ISeriesApi<"Histogram">;

    const handleResize = () => {
      if (chartContainerRef.current) {
        chart.applyOptions({ width: chartContainerRef.current.clientWidth, height: chartContainerRef.current.clientHeight });
      }
    };
    
    window.addEventListener('resize', handleResize);

    const handleChartClick = (param: any) => {
      const pMode = placeMarkerModeRef.current;
      if (pMode) {
          if (!param.point || !param.time) return;
          
          const time = param.time as UTCTimestamp;
          const clickedPrice = seriesRef.current?.coordinateToPrice(param.point.y) || 0;

          const newMarker: any = {
             id: Date.now().toString(),
             time,
             price: clickedPrice,
             type: pMode,
             symbol: currentSymbolRef.current
          };

          setManualMarkers(prev => [...prev, newMarker]);
          setPlaceMarkerMode(null);
          return;
      }

      if (!isDrawingRef.current) return;
      if (!param.point || !param.time) return;
      
      const price = (seriesRef.current?.coordinateToPrice(param.point.y) || 0) as number;
      const time = param.time as UTCTimestamp;
      
      if (price !== null && price !== undefined) {
        if (!drawStartRef.current) {
          drawStartRef.current = { time, price };
        } else {
          const t1 = drawStartRef.current.time;
          const p1 = drawStartRef.current.price;
          const t2 = time;
          const p2 = price;
          
          let t1_sorted = t1; let p1_sorted = p1;
          let t2_sorted = t2; let p2_sorted = p2;
          
          if (t1 > t2) {
             t1_sorted = t2; p1_sorted = p2;
             t2_sorted = t1; p2_sorted = p1;
          }
          
          if (t1_sorted !== t2_sorted) {
            const lineSeries = chart.addSeries(LineSeries, {
              color: '#f59e0b',
              lineWidth: 2,
              lastValueVisible: false,
              priceLineVisible: false,
              crosshairMarkerVisible: false,
            });
            
            lineSeries.setData([
              { time: t1_sorted, value: p1_sorted },
              { time: t2_sorted, value: p2_sorted }
            ]);
            
            trendlineSeriesRef.current.push(lineSeries as ISeriesApi<"Line">);
            setTrendlinesCount(prev => prev + 1);
          }
          
          drawStartRef.current = null;
          setIsDrawing(false);
        }
      }
    };

    chart.subscribeClick(handleChartClick);

    return () => {
      window.removeEventListener('resize', handleResize);
      chart.unsubscribeClick(handleChartClick);
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
      volumeSeriesRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!seriesRef.current) return;
    setLoading(true);

    let ws: WebSocket | null = null;
    let currentData: any[] = [];

    // Fetch initial data
    fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${currentSymbol.replace('/', '')}&interval=${interval}&limit=1500`)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Binance API error (status ${res.status}): ${res.statusText}`);
        }
        const contentType = res.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          throw new Error('Binance API returned non-JSON response (CORS or region-blocked by Cloudflare)');
        }
        return res.json();
      })
      .then((data) => {
        const cdata = data.map((d: any) => ({
          time: (d[0] / 1000) as UTCTimestamp,
          open: parseFloat(d[1]),
          high: parseFloat(d[2]),
          low: parseFloat(d[3]),
          close: parseFloat(d[4]),
          volume: parseFloat(d[5]),
        }));
        
        const samplePrice = cdata[0]?.close || 100;
        const { precision, minMove } = getPrecisionAndMinMove(samplePrice);
        seriesRef.current?.applyOptions({
          priceFormat: {
            type: 'price',
            precision: precision,
            minMove: minMove,
          },
        });

        seriesRef.current?.setData(cdata);
        volumeSeriesRef.current?.setData(
          cdata.map((d) => ({
            time: d.time,
            value: d.volume,
            color: d.close >= d.open ? '#00FFA380' : '#f43f5e80',
          }))
        );
        currentData = [...cdata];
        setChartData(cdata);
        chartRef.current?.timeScale().fitContent();
        setLoading(false);

        ws = new WebSocket(`wss://fstream.binance.com/ws/${currentSymbol.toLowerCase()}@kline_${interval}`);
        ws.onmessage = (event) => {
            if (!chartRef.current) return;
            const message = JSON.parse(event.data);
            const kline = message.k;
            if (!kline) return;
            const time = (kline.t / 1000) as UTCTimestamp;
            const open = parseFloat(kline.o);
            const high = parseFloat(kline.h);
            const low = parseFloat(kline.l);
            const close = parseFloat(kline.c);
            const volume = parseFloat(kline.v);
  
            const d = { time, open, high, low, close, volume };
            
            try {
              seriesRef.current?.update(d);
              volumeSeriesRef.current?.update({
                  time,
                  value: volume,
                  color: close >= open ? '#00FFA380' : '#f43f5e80'
              });

              // Update local memory data reference
              let isNew = false;
              if (currentData.length > 0 && currentData[currentData.length - 1].time === time) {
                  currentData[currentData.length - 1] = { ...currentData[currentData.length - 1], ...d };
              } else if (currentData.length === 0 || time > currentData[currentData.length - 1].time) {
                  currentData.push(d);
                  isNew = true;
              }

              try {
                  if (macdSeriesRef.current && currentData.length > 0) {
                     const macdFull = calculateMACD(currentData as any);
                     const lastMacd = macdFull[macdFull.length - 1];
                     macdSeriesRef.current.macdLine.update({ time: lastMacd.time as UTCTimestamp, value: lastMacd.macd });
                     macdSeriesRef.current.signalLine.update({ time: lastMacd.time as UTCTimestamp, value: lastMacd.signal });
                     macdSeriesRef.current.histogram.update({ time: lastMacd.time as UTCTimestamp, value: lastMacd.histogram, color: lastMacd.histogram >= 0 ? '#10b981' : '#ef4444' });
                  }
    
                  if (surfistaRefs.current && currentData.length > 0) {
                     const surfista = runSurfistaEngine(currentData as any, { margem: 1, alavancagem: 20, gatilho_surf: 15, dist_stop: 5, gatilho_be: 10, protecao_be: 0.5, stop_fixo: 10 });
                     if (surfista) {
                         const lastSma8 = surfista.sma8Line[surfista.sma8Line.length - 1];
                         const lastSma21 = surfista.sma21Line[surfista.sma21Line.length - 1];
                         const lastSt = surfista.stLine[surfista.stLine.length - 1];
                         
                         if (lastSma8) surfistaRefs.current.sma8.update(lastSma8);
                         if (lastSma21) surfistaRefs.current.sma21.update(lastSma21);
                         if (lastSt) surfistaRefs.current.stLine.update(lastSt);
                     }
                  }

                  if (psarSeriesRef.current && currentData.length > 0) {
                     const psarFull = calculatePSAR(currentData as any);
                     const lastPsar = psarFull[psarFull.length - 1];
                     if (lastPsar !== undefined) {
                         psarSeriesRef.current.update({ time: currentData[currentData.length - 1].time as UTCTimestamp, value: lastPsar });
                     }
                  }

                  if (donchianSeriesRef.current && currentData.length > 0) {
                     const donchianFull = calculateDonchianChannel(currentData as any, donchianPeriod);
                     const lastIdx = currentData.length - 1;
                     const time = currentData[lastIdx].time as UTCTimestamp;
                     donchianSeriesRef.current.upper.update({ time, value: donchianFull.upper[lastIdx] });
                     donchianSeriesRef.current.lower.update({ time, value: donchianFull.lower[lastIdx] });
                     donchianSeriesRef.current.middle.update({ time, value: donchianFull.middle[lastIdx] });
                  }
              } catch (e) {
                  console.warn("Could not update indicator series on tick", e);
              }

              // Sync state for volume profile only occasionally or on new candles to avoid heavy renders
              if (isNew) {
                 setChartData([...currentData]);
              }
            } catch (err) {
              // Ignore disposed errors
            }
        };

      })
      .catch((err) => {
        console.error("Error fetching binance klines", err);
        setLoading(false);
      });

      return () => {
         if (ws) {
            ws.close();
         }
      };
  }, [currentSymbol, interval]);

  useEffect(() => {
    if (!chartRef.current || chartData.length === 0) return;
    const chart = chartRef.current;

    if (showMacd) {
      chart.priceScale('right').applyOptions({
         scaleMargins: {
            top: 0.05,
            bottom: 0.35,
         }
      });

      const macdDataRaw = calculateMACD(chartData as any);
      
      const histogram = chart.addSeries(HistogramSeries, {
        priceScaleId: 'macd',
        color: '#26a69a',
      });
      
      const macdLine = chart.addSeries(LineSeries, {
        priceScaleId: 'macd',
        color: '#00e5ff',
        lineWidth: 3,
      });
      
      const signalLine = chart.addSeries(LineSeries, {
        priceScaleId: 'macd',
        color: '#ffeb3b',
        lineWidth: 3,
      });
      
      histogram.priceScale().applyOptions({
         scaleMargins: {
             top: 0.65,
             bottom: 0,
         }
      });

      histogram.setData(macdDataRaw.map(d => ({ 
        time: d.time as UTCTimestamp, 
        value: d.histogram, 
        color: d.histogram >= 0 ? '#10b981' : '#ef4444' 
      })));
      
      macdLine.setData(macdDataRaw.map(d => ({ time: d.time as UTCTimestamp, value: d.macd })));
      signalLine.setData(macdDataRaw.map(d => ({ time: d.time as UTCTimestamp, value: d.signal })));

      macdSeriesRef.current = { histogram, macdLine, signalLine };

      return () => {
        try {
          chart.removeSeries(macdLine);
          chart.removeSeries(signalLine);
          chart.removeSeries(histogram);
          chart.priceScale('right').applyOptions({
             scaleMargins: {
                 top: 0.1,
                 bottom: 0.1,
             }
          });
        } catch (e) {
          // ignore
        }
        macdSeriesRef.current = null;
      };
    }
  }, [showMacd, chartData.length === 0]);

  useEffect(() => {
    if (!chartRef.current || chartData.length === 0) return;
    const chart = chartRef.current;

    if (showSurfista) {
      const sma8 = chart.addSeries(LineSeries, { color: '#ffffff', lineWidth: 2, priceLineVisible: false });
      const sma21 = chart.addSeries(LineSeries, { color: '#fbbf24', lineWidth: 2, priceLineVisible: false });
      const stLine = chart.addSeries(LineSeries, { lineWidth: 2, priceLineVisible: false, lineType: 1 });

      surfistaRefs.current = { sma8, sma21, stLine };

      return () => {
        try {
           chart.removeSeries(sma8);
           chart.removeSeries(sma21);
           chart.removeSeries(stLine);
        } catch (e) {}
        surfistaRefs.current = null;
        if (markersContainerRef.current) {
           markersContainerRef.current.dataset.hash = '';
           markersContainerRef.current.innerHTML = '';
           markersElementsRef.current = [];
        }
      };
    }
  }, [showSurfista, chartData.length === 0]); 

  // Parabolic SAR Effect
  useEffect(() => {
    if (!chartRef.current || chartData.length === 0) return;
    const chart = chartRef.current;

    if (showPsar) {
      const psarSeries = chart.addSeries(LineSeries, {
        color: '#c084fc',
        lineWidth: 2,
        priceLineVisible: false,
        lineStyle: 1, // Dotted
        lastValueVisible: false,
      });

      const psarData = calculatePSAR(chartData as any);
      psarSeries.setData(
        chartData.map((d, index) => ({
          time: d.time as UTCTimestamp,
          value: psarData[index],
        }))
      );

      psarSeriesRef.current = psarSeries;

      return () => {
        try {
          chart.removeSeries(psarSeries);
        } catch (e) {}
        psarSeriesRef.current = null;
      };
    }
  }, [showPsar, chartData.length === 0]);

  // Donchian Channel Effect
  useEffect(() => {
    if (!chartRef.current || chartData.length === 0) return;
    const chart = chartRef.current;

    if (showDonchian) {
      const upper = chart.addSeries(LineSeries, {
        color: '#fb7185',
        lineWidth: 1,
        priceLineVisible: false,
        lineStyle: 1,
        lastValueVisible: false,
      });
      const lower = chart.addSeries(LineSeries, {
        color: '#fb7185',
        lineWidth: 1,
        priceLineVisible: false,
        lineStyle: 1,
        lastValueVisible: false,
      });
      const middle = chart.addSeries(LineSeries, {
        color: '#fda4af',
        lineWidth: 2,
        priceLineVisible: false,
        lineStyle: 2,
        lastValueVisible: false,
      });

      const donchianData = calculateDonchianChannel(chartData, donchianPeriod);
      upper.setData(chartData.map((d, index) => ({ time: d.time as UTCTimestamp, value: donchianData.upper[index] })));
      lower.setData(chartData.map((d, index) => ({ time: d.time as UTCTimestamp, value: donchianData.lower[index] })));
      middle.setData(chartData.map((d, index) => ({ time: d.time as UTCTimestamp, value: donchianData.middle[index] })));

      donchianSeriesRef.current = { upper, lower, middle };

      return () => {
        try {
          chart.removeSeries(upper);
          chart.removeSeries(lower);
          chart.removeSeries(middle);
        } catch (e) {}
        donchianSeriesRef.current = null;
      };
    }
  }, [showDonchian, donchianPeriod, chartData.length === 0]); 

  useEffect(() => {
    if (!seriesRef.current) return;
    
    vpLinesRef.current.forEach(line => seriesRef.current?.removePriceLine(line));
    vpLinesRef.current = [];

    if ((showVolumeProfile || showPoc) && chartData.length > 0) {
      let minPrice = Infinity;
      let maxPrice = -Infinity;
      let totalVolume = 0;
      
      chartData.forEach(d => {
         if (d.low < minPrice) minPrice = d.low;
         if (d.high > maxPrice) maxPrice = d.high;
         totalVolume += d.volume;
      });
      
      const numBins = 70;
      const binSize = (maxPrice - minPrice) / numBins;
      const bins = new Array(numBins).fill(0);
      
      chartData.forEach(d => {
         const typPrice = (d.high + d.low + d.close) / 3;
         let idx = Math.floor((typPrice - minPrice) / binSize);
         if (idx >= numBins) idx = numBins - 1;
         if (idx < 0) idx = 0;
         bins[idx] += d.volume;
      });
      
      let maxVol = -1;
      let pocIdx = 0;
      bins.forEach((v, i) => {
         if (v > maxVol) {
           maxVol = v;
           pocIdx = i;
         }
      });
      
      const pocPrice = minPrice + pocIdx * binSize + (binSize / 2);
      
      const targetVaVol = totalVolume * 0.70;
      let vaVol = bins[pocIdx];
      let upIdx = pocIdx + 1;
      let downIdx = pocIdx - 1;
      
      while (vaVol < targetVaVol && (upIdx < numBins || downIdx >= 0)) {
         let upVol = upIdx < numBins ? bins[upIdx] : -1;
         let downVol = downIdx >= 0 ? bins[downIdx] : -1;
         
         if (upVol > downVol) {
            vaVol += upVol;
            upIdx++;
         } else {
            vaVol += downVol;
            downIdx--;
         }
      }
      
      const vahPrice = minPrice + Math.min(numBins - 1, upIdx) * binSize;
      const valPrice = minPrice + Math.max(0, downIdx) * binSize;
      
      if (showVolumeProfile) {
        for (let i = Math.max(0, downIdx); i <= Math.min(numBins - 1, upIdx); i++) {
          if (i !== pocIdx) {
              const price = minPrice + i * binSize + (binSize / 2);
              const intensity = bins[i] / maxVol;
              if (intensity > 0.15) {
                const l = seriesRef.current.createPriceLine({
                  price: price,
                  color: `rgba(236, 72, 153, ${Math.min(0.3, intensity * 0.3)})`,
                  lineWidth: 4,
                  lineStyle: LineStyle.Solid,
                  axisLabelVisible: false,
                });
                vpLinesRef.current.push(l);
              }
          }
        }
      }

      if (showPoc || showVolumeProfile) {
        const pocLine = seriesRef.current.createPriceLine({
          price: pocPrice,
          color: '#ec4899',
          lineWidth: 2,
          lineStyle: LineStyle.Solid,
          title: 'POC',
          axisLabelVisible: true,
        });
        vpLinesRef.current.push(pocLine);
      }

      if (showVolumeProfile) {
        const vahLine = seriesRef.current.createPriceLine({
          price: vahPrice,
          color: '#38bdf8',
          lineWidth: 1,
          lineStyle: LineStyle.Dotted,
          title: 'VAH',
          axisLabelVisible: true,
        });
        vpLinesRef.current.push(vahLine);

        const valLine = seriesRef.current.createPriceLine({
          price: valPrice,
          color: '#38bdf8',
          lineWidth: 1,
          lineStyle: LineStyle.Dotted,
          title: 'VAL',
          axisLabelVisible: true,
        });
        vpLinesRef.current.push(valLine);
      }
    }
  }, [showVolumeProfile, showPoc, chartData]);

  return (
    <div className="flex flex-col gap-6 w-full max-w-6xl mx-auto min-h-full pb-12 text-slate-300">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-400 tracking-wider">
            TERMINAL GRÁFICO
          </h1>
          <p className="text-slate-500 text-xs font-mono tracking-widest uppercase mt-1">Lightweight Charts / Binance {interval}</p>
          {showDonchian && (
            <p className="text-rose-400 font-mono text-[10px] uppercase tracking-wider mt-1.5 flex items-center gap-1 bg-rose-950/20 border border-rose-900/40 rounded px-2.5 py-1 w-fit">
              <span className="animate-pulse">📊</span> Canal de Donchian: <span className="text-rose-300 font-bold">{donchianPeriod} velas</span> ({donchianPeriodType === '20_candles' ? '20 candles' : donchianPeriodType === '1_week' ? '1 Semana' : '2 Semanas'}) calculadas do par <span className="text-rose-300 font-bold">{currentSymbol}</span> com base em <span className="text-rose-300 font-bold">{chartData.length} barras</span> carregadas no histórico.
            </p>
          )}
        </div>

        <div className="flex flex-wrap md:flex-nowrap items-center gap-2 relative">
          
          {/* 1. INDICADORES POPUP */}
          <div className="relative">
            <button
              onClick={() => {
                setIndicatorsOpen(!indicatorsOpen);
                setToolsOpen(false);
              }}
              className={`flex items-center gap-2 px-3 py-2 font-mono text-xs uppercase tracking-wider rounded-lg border transition-colors ${
                indicatorsOpen || showPoc || showMacd || showSurfista || showVolumeProfile || showPsar || showDonchian
                  ? 'bg-cyan-950/40 text-cyan-400 border-cyan-500/40'
                  : 'bg-[#050510] text-slate-400 border-slate-800 hover:border-slate-600'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4 text-cyan-400/80" />
              <span>Indicadores</span>
              <ChevronDown className={`w-3 h-3 transition-transform ${indicatorsOpen ? 'rotate-180' : ''}`} />
            </button>

            {indicatorsOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIndicatorsOpen(false)} />
                <div className="absolute left-0 mt-2 w-72 bg-[#0B0D19]/95 border border-slate-800 rounded-xl p-3 shadow-2xl backdrop-blur-md flex flex-col gap-1.5 z-50">
                  <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest pl-2 pb-1 border-b border-slate-800/50 mb-1">
                    Estilos e Indicadores
                  </div>
                  
                  {/* VP Overlay */}
                  <button
                    onClick={() => setShowVolumeProfile(!showVolumeProfile)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showVolumeProfile 
                        ? 'bg-pink-500/10 text-pink-400 font-bold border-l-2 border-pink-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-pink-500/70" /> VP Overlay
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showVolumeProfile ? 'bg-pink-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* POC */}
                  <button
                    onClick={() => setShowPoc(!showPoc)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showPoc 
                        ? 'bg-cyan-500/10 text-cyan-400 font-bold border-l-2 border-cyan-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-cyan-500/70" /> Point of Control (POC)
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showPoc ? 'bg-cyan-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* Donchian */}
                  <div className="flex flex-col gap-1 py-1 border-y border-slate-800/35 my-0.5">
                    <button
                      onClick={() => setShowDonchian(!showDonchian)}
                      className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                        showDonchian 
                          ? 'bg-rose-500/10 text-rose-400 font-bold border-l-2 border-rose-500' 
                          : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <Layers className="w-3.5 h-3.5 text-rose-500/70" /> Canal de Donchian
                      </span>
                      <span className={`w-2 h-2 rounded-full ${showDonchian ? 'bg-rose-400 animate-pulse' : 'bg-slate-700'}`} />
                    </button>
                    {showDonchian && (
                      <div className="px-2 py-1 flex items-center justify-between gap-2 bg-[#050510] border border-slate-800 rounded-md mt-0.5 ml-5">
                        <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">Período:</span>
                        <select
                          value={donchianPeriodType}
                          onChange={(e: any) => setDonchianPeriodType(e.target.value)}
                          className="bg-transparent text-xs text-rose-300 font-semibold outline-none cursor-pointer"
                        >
                          <option value="20_candles">20 Períodos</option>
                          <option value="1_week">1 Semana</option>
                          <option value="2_weeks">2 Semanas</option>
                        </select>
                      </div>
                    )}
                  </div>

                  {/* MACD */}
                  <button
                    onClick={() => setShowMacd(!showMacd)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showMacd 
                        ? 'bg-indigo-500/10 text-indigo-400 font-bold border-l-2 border-indigo-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Activity className="w-3.5 h-3.5 text-indigo-500/70" /> MACD
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showMacd ? 'bg-indigo-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* PSAR */}
                  <button
                    onClick={() => setShowPsar(!showPsar)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showPsar 
                        ? 'bg-purple-500/10 text-purple-400 font-bold border-l-2 border-purple-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Activity className="w-3.5 h-3.5 text-purple-500/70" /> Parabolic SAR (SAR)
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showPsar ? 'bg-purple-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* VOL */}
                  <button
                    onClick={() => setShowVolume(!showVolume)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showVolume 
                        ? 'bg-emerald-500/10 text-emerald-400 font-bold border-l-2 border-emerald-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <BarChart2 className="w-3.5 h-3.5 text-emerald-500/70" /> Volume (VOL)
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showVolume ? 'bg-emerald-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* SURFISTA */}
                  <button
                    onClick={() => setShowSurfista(!showSurfista)}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      showSurfista 
                        ? 'bg-amber-500/10 text-amber-400 font-bold border-l-2 border-amber-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Waves className="w-3.5 h-3.5 text-amber-500/70" /> Monitor Surfista
                    </span>
                    <span className={`w-2 h-2 rounded-full ${showSurfista ? 'bg-amber-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>
                </div>
              </>
            )}
          </div>

          {/* 2. FERRAMENTAS / DESENHOS POPUP */}
          <div className="relative">
            <button
              onClick={() => {
                setToolsOpen(!toolsOpen);
                setIndicatorsOpen(false);
              }}
              className={`flex items-center gap-2 px-3 py-2 font-mono text-xs uppercase tracking-wider rounded-lg border transition-colors ${
                toolsOpen || isDrawing || placeMarkerMode || trendlinesCount > 0
                  ? 'bg-amber-950/40 text-amber-400 border-amber-500/40'
                  : 'bg-[#050510] text-slate-400 border-slate-800 hover:border-slate-600'
              }`}
            >
              <PenTool className="w-4 h-4 text-amber-400/85" />
              <span>Desenhos</span>
              {trendlinesCount > 0 && <span className="bg-rose-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">{trendlinesCount}</span>}
              <ChevronDown className={`w-3 h-3 transition-transform ${toolsOpen ? 'rotate-180' : ''}`} />
            </button>

            {toolsOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setToolsOpen(false)} />
                <div className="absolute left-0 mt-2 w-64 bg-[#0B0D19]/95 border border-slate-800 rounded-xl p-3 shadow-2xl backdrop-blur-md flex flex-col gap-1.5 z-50">
                  <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest pl-2 pb-1 border-b border-slate-800/50 mb-1">
                    Anotações e Linhas
                  </div>

                  {/* Trendline */}
                  <button
                    onClick={() => {
                      setIsDrawing(!isDrawing);
                      drawStartRef.current = null;
                      setPlaceMarkerMode(null);
                      setToolsOpen(false); 
                    }}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      isDrawing 
                        ? 'bg-amber-500/10 text-amber-400 font-bold border-l-2 border-amber-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <PenTool className="w-3.5 h-3.5 text-amber-500/70" /> {isDrawing ? 'Desenha: 2 Cliques' : 'Trendline'}
                    </span>
                    <span className={`w-2 h-2 rounded-full ${isDrawing ? 'bg-amber-400 animate-pulse' : 'bg-slate-700'}`} />
                  </button>

                  {/* Sinal Compra */}
                  <button
                    onClick={() => {
                      setPlaceMarkerMode(placeMarkerMode === 'compra' ? null : 'compra');
                      setIsDrawing(false);
                      setToolsOpen(false);
                    }}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      placeMarkerMode === 'compra'
                        ? 'bg-emerald-500/10 text-emerald-400 font-bold border-l-2 border-emerald-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="text-emerald-500 font-bold">🟢</span> Sinal Compra Manual
                    </span>
                  </button>

                  {/* Sinal Venda */}
                  <button
                    onClick={() => {
                      setPlaceMarkerMode(placeMarkerMode === 'venda' ? null : 'venda');
                      setIsDrawing(false);
                      setToolsOpen(false);
                    }}
                    className={`flex items-center justify-between w-full px-2 py-1.5 text-xs font-mono tracking-wider rounded-md transition-all ${
                      placeMarkerMode === 'venda'
                        ? 'bg-rose-500/10 text-rose-400 font-bold border-l-2 border-rose-500' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="text-rose-500 font-bold">🔴</span> Sinal Venda Manual
                    </span>
                  </button>

                  {trendlinesCount > 0 && (
                    <button
                      onClick={() => {
                        trendlineSeriesRef.current.forEach(series => chartRef.current?.removeSeries(series));
                        trendlineSeriesRef.current = [];
                        setTrendlinesCount(0);
                        setToolsOpen(false);
                      }}
                      className="flex items-center gap-2 px-3 py-1.5 mt-2 text-xs font-mono tracking-wider rounded-md bg-rose-950/20 text-rose-400 hover:bg-rose-950/40 border border-rose-900/30 transition-all font-bold w-full justify-center"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Limpar Linhas
                    </button>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Timeframe Select */}
          <select 
            value={interval}
            onChange={(e) => setInterval(e.target.value)}
            className="bg-[#050510] border border-slate-800 text-slate-300 font-mono text-center px-2 py-2 rounded-lg focus:border-cyan-500 outline-none cursor-pointer text-xs"
          >
            <option value="1s">1s</option>
            <option value="1m">1m</option>
            <option value="3m">3m</option>
            <option value="5m">5m</option>
            <option value="15m">15m</option>
            <option value="30m">30m</option>
            <option value="1h">1h</option>
            <option value="2h">2h</option>
            <option value="4h">4h</option>
            <option value="1d">1d</option>
          </select>

          {/* Symbol Input */}
          <div className="flex bg-[#050510] border border-slate-800 rounded-lg overflow-hidden focus-within:border-cyan-500 transition-colors">
            <input 
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value.toUpperCase())}
              onKeyDown={(e) => {
                if (e.key === 'Enter') setCurrentSymbol(inputValue);
              }}
              onBlur={() => setCurrentSymbol(inputValue)}
              className="bg-transparent text-white font-mono text-center px-3 py-2 w-28 outline-none text-xs"
              placeholder="BTCUSDT"
            />
          </div>

        </div>
      </div>

      <div className="flex-1 bg-[#0A0C16] border border-cyan-800/30 rounded-2xl p-4 shadow-xl flex flex-col relative min-h-[500px]">
         {loading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-[#0A0C16]/80 backdrop-blur-sm rounded-xl">
               <div className="text-cyan-500 font-mono text-xs tracking-widest animate-pulse flex items-center gap-2">
                 <LineChart className="w-4 h-4 animate-bounce" /> CARREGANDO DADOS...
               </div>
            </div>
         )}
         
         {/* Container which stretches to fill available space */}
         {showSurfista && surfistaResult && (
            <div className="absolute bottom-16 right-4 z-50 bg-[#050510]/95 border border-slate-700/50 rounded-lg p-3 text-xs font-mono shadow-2xl pointer-events-auto w-64 backdrop-blur-md">
                <div className="text-white font-bold mb-2 flex justify-between items-center">
                    <span>🦅 MONITOR SURFISTA</span>
                    <button 
                        onClick={() => setShowSurfistaTable(!showSurfistaTable)} 
                        className="text-slate-400 hover:text-white transition-colors p-1"
                        title={showSurfistaTable ? "Ocultar Monitor" : "Mostrar Monitor"}
                    >
                        {showSurfistaTable ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                </div>
                {showSurfistaTable && (
                    <>
                        <div className="flex justify-between text-slate-300 border-b border-slate-800 pb-2 mb-2">
                            <span>🏆 {surfistaResult.stats.wins}W - {surfistaResult.stats.loss}L</span>
                            <span className={surfistaResult.stats.total_pnl >= 0 ? "text-[#00ff00]" : "text-[#ff0062]"}>
                                ${surfistaResult.stats.total_pnl.toFixed(2)}
                            </span>
                        </div>
                        <div className={`mb-1 ${surfistaResult.vol_dia_pct > 3 ? 'text-yellow-400' : 'text-slate-400'}`}>
                            VOLATILIDADE: {surfistaResult.vol_dia_pct.toFixed(2)}%
                        </div>
                        <div className="text-orange-400 mb-1">PERÍODO: {Math.round(surfistaResult.dias_teste)} Dias</div>
                        <div className="text-white mb-3 tracking-tight flex items-center gap-2">TENDÊNCIA: {surfistaResult.tendencia_geral}</div>
                        
                        <div className="text-slate-500 mb-2 mt-3 font-semibold tracking-widest text-[10px]">═══ HISTÓRICO ═══</div>
                        {surfistaResult.stats.historico.length > 0 ? (
                            <div className="flex flex-col gap-1">
                                {surfistaResult.stats.historico.map((h, i) => (
                                    <div key={i} style={{ color: h.color }}>{h.text}</div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-slate-500">⏳ Aguardando...</div>
                        )}
                    </>
                )}
            </div>
         )}
         <div className="relative w-full h-full flex-1 min-h-[400px]">
             <div ref={chartContainerRef} className="absolute inset-0 z-0"></div>
             <div ref={markersContainerRef} className="absolute inset-0 pointer-events-none z-10 overflow-hidden"></div>
             <div ref={manualMarkersContainerRef} className="absolute inset-0 pointer-events-none z-20 overflow-hidden"></div>
         </div>
      </div>
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { Trade } from "../types.js";

export function TradesView({
  trades,
  title,
  est,
  history = [],
}: {
  trades: Trade[];
  title: string;
  est: string;
  history?: Trade[];
}) {
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedFilterIdx, setSelectedFilterIdx] = useState(0);

  // Dynamic filter lists
  const filterOptions = useMemo(() => {
    const opts = [{ label: "Todas as Operações", type: "ALL", value: "ALL" }];
    
    // Get unique strategies
    const strategies = Array.from(new Set(history.map(t => t.estrategia).filter(Boolean)));
    strategies.forEach((st) => {
      opts.push({ label: `Estratégia: ${st}`, type: "STRATEGY", value: st || "" });
    });

    // Get unique motors
    const motors = Array.from(new Set(history.map(t => t.motor).filter(Boolean)));
    motors.forEach((mt) => {
      opts.push({ label: `Motor: ${mt}`, type: "MOTOR", value: mt || "" });
    });

    // Get unique timeframes
    const timeframes = Array.from(new Set(history.map(t => t.tf).filter(Boolean)));
    timeframes.forEach((tf) => {
      opts.push({ label: `Timeframe: ${tf}`, type: "TF", value: tf || "" });
    });

    return opts;
  }, [history]);

  const activeFilter = filterOptions[selectedFilterIdx] || filterOptions[0];

  const filteredHistory = useMemo(() => {
    if (!activeFilter || activeFilter.type === "ALL") return history;
    if (activeFilter.type === "STRATEGY") {
      return history.filter(t => t.estrategia === activeFilter.value);
    }
    if (activeFilter.type === "MOTOR") {
      return history.filter(t => t.motor === activeFilter.value);
    }
    if (activeFilter.type === "TF") {
      return history.filter(t => t.tf === activeFilter.value);
    }
    return history;
  }, [history, activeFilter]);

  const stats = useMemo(() => {
    const total = filteredHistory.length;
    const winsList = filteredHistory.filter((t) => t.pnl > 0);
    const lossesList = filteredHistory.filter((t) => t.pnl <= 0);
    
    const winsCount = winsList.length;
    const lossesCount = lossesList.length;
    const winRate = total > 0 ? (winsCount / total) * 100 : 0;
    
    const grossProfit = winsList.reduce((acc, t) => acc + t.pnl, 0);
    const grossLoss = Math.abs(lossesList.reduce((acc, t) => acc + t.pnl, 0));
    
    const netPnl = filteredHistory.reduce((acc, t) => acc + t.pnl, 0);
    
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;
    
    const avgWin = winsCount > 0 ? grossProfit / winsCount : 0;
    const avgLoss = lossesCount > 0 ? grossLoss / lossesCount : 0;
    const payoffRatio = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? Infinity : 0;

    return {
      total,
      wins: winsCount,
      losses: lossesCount,
      winRate,
      grossProfit,
      grossLoss,
      netPnl,
      profitFactor,
      payoffRatio,
    };
  }, [filteredHistory]);

  const generateCanvasDataUrl = () => {
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 675;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "";

    // 1. Background linear gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 1200, 675);
    bgGrad.addColorStop(0, "#080913");
    bgGrad.addColorStop(1, "#111424");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 1200, 675);

    // 2. Glowing backdrops
    ctx.globalCompositeOperation = "screen";
    const glowL = ctx.createRadialGradient(200, 200, 50, 200, 200, 500);
    glowL.addColorStop(0, "rgba(6, 182, 212, 0.12)");
    glowL.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = glowL;
    ctx.fillRect(0, 0, 1200, 675);

    const glowR = ctx.createRadialGradient(1000, 475, 50, 1000, 475, 500);
    glowR.addColorStop(0, "rgba(236, 72, 153, 0.12)");
    glowR.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = glowR;
    ctx.fillRect(0, 0, 1200, 675);
    ctx.globalCompositeOperation = "source-over";

    // 3. Tech grid design
    ctx.strokeStyle = "rgba(148, 163, 184, 0.04)";
    ctx.lineWidth = 1;
    const gridSize = 50;
    for (let x = 0; x < 1200; x += gridSize) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 675); ctx.stroke();
    }
    for (let y = 0; y < 675; y += gridSize) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(1200, y); ctx.stroke();
    }

    // Colors matching theme
    const getThemeColor = () => {
      if (est === "SIMU") return "#22d3ee"; // Cyan
      if (est === "SIMU_B") return "#ec4899"; // Pink
      return "#f59e0b"; // Amber (Real)
    };
    const themeColor = getThemeColor();

    // 4. Glowing borders
    ctx.strokeStyle = themeColor;
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 30, 1140, 615);

    ctx.lineWidth = 6;
    // Corners
    ctx.beginPath(); ctx.moveTo(25, 90); ctx.lineTo(25, 25); ctx.lineTo(90, 25); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(1175, 90); ctx.lineTo(1175, 25); ctx.lineTo(1110, 25); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(25, 585); ctx.lineTo(25, 650); ctx.lineTo(90, 650); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(1175, 585); ctx.lineTo(1175, 650); ctx.lineTo(1110, 650); ctx.stroke();

    // 5. Title Header
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 32px sans-serif";
    ctx.fillText("🤖 ELITE TRADER COCKPIT", 70, 95);

    ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
    ctx.font = "bold 13px sans-serif";
    ctx.fillText("SISTEMA QUANTITATIVO DE ALTA PERFORMANCE", 70, 125);

    // Horizontal line
    ctx.strokeStyle = "rgba(148, 163, 184, 0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(70, 145); ctx.lineTo(1130, 145); ctx.stroke();

    // 6. Header badges
    const envLabel = est === "SIMU" ? "SIMULADOR A" : est === "SIMU_B" ? "SIMULADOR B" : "CONTA REAL";
    const stratTitle = activeFilter.label.toUpperCase();
    
    // Draw Pill
    ctx.fillStyle = themeColor;
    ctx.fillRect(70, 175, 140, 32);
    ctx.fillStyle = "#000000";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(envLabel, 140, 195);
    ctx.textAlign = "left";

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 20px sans-serif";
    ctx.fillText(`ESTRATÉGIA: ${stratTitle}`, 230, 198);

    ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
    ctx.font = "14px sans-serif";
    ctx.fillText(`AMOSTRAGEM: ${stats.total} trades computados`, 70, 245);

    // 7. Render 4 beautiful metrics grid
    const cardW = 240;
    const cardH = 180;
    const cardY = 280;
    const gap = 44;
    const startX = 70;

    const metricsArr = [
      {
        title: "WIN RATE",
        val: `${stats.winRate.toFixed(1)}%`,
        color: "#22d3ee",
        desc: `${stats.wins} VITÓRIAS - ${stats.losses} DERROTAS`,
      },
      {
        title: "PROFIT FACTOR",
        val: stats.profitFactor === Infinity ? "EXCELENTE" : stats.profitFactor.toFixed(2),
        color: "#a855f7",
        desc: "FATOR DE LUCRO BRUTO",
      },
      {
        title: "PAYOFF RATIO",
        val: stats.payoffRatio === Infinity ? "ELEVADO" : stats.payoffRatio.toFixed(2),
        color: "#f472b6",
        desc: "RETORNO MÉDIO / RISCO",
      },
      {
        title: "LUCRO LÍQUIDO",
        val: `${stats.netPnl >= 0 ? "+" : ""}$${stats.netPnl.toFixed(2)}`,
        color: stats.netPnl >= 0 ? "#10b981" : "#f87171",
        desc: "MOEDA: USDT COM TAXAS",
      },
    ];

    metricsArr.forEach((m, idx) => {
      const x = startX + idx * (cardW + gap);
      
      // Card BG
      ctx.fillStyle = "rgba(17, 24, 39, 0.8)";
      ctx.fillRect(x, cardY, cardW, cardH);
      ctx.strokeStyle = "rgba(148, 163, 184, 0.1)";
      ctx.lineWidth = 1;
      ctx.strokeRect(x, cardY, cardW, cardH);

      // Card TOP Line
      ctx.strokeStyle = m.color;
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x, cardY); ctx.lineTo(x + cardW, cardY); ctx.stroke();

      // Label title
      ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
      ctx.font = "bold 11px sans-serif";
      ctx.fillText(m.title, x + 20, cardY + 35);

      // Value
      ctx.fillStyle = m.color;
      ctx.font = m.val.length > 9 ? "bold 26px sans-serif" : "bold 36px sans-serif";
      ctx.fillText(m.val, x + 20, cardY + 95);

      // Description helper
      ctx.fillStyle = "rgba(148, 163, 184, 0.4)";
      ctx.font = "bold 10px sans-serif";
      ctx.fillText(m.desc, x + 20, cardY + 145);
    });

    // 8. Bottom Decoration
    ctx.strokeStyle = "rgba(148, 163, 184, 0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(70, 520); ctx.lineTo(1130, 520); ctx.stroke();

    ctx.fillStyle = "rgba(148, 163, 184, 0.4)";
    ctx.font = "11px sans-serif";
    ctx.fillText("ESTATÍSTICAS EXTRAÍDAS DIRETAMENTE DO BANCO DE DADOS DE SIMULAÇÃO HISTÓRICA.", 70, 555);
    ctx.fillText("VIVÊNCIA COMPLETA EM AMBIENTE DE MERCADO DA CORRETORA COM CÁLCULO DINÂMICO DE TAXAS.", 70, 575);

    ctx.fillStyle = themeColor;
    ctx.font = "bold 13px sans-serif";
    ctx.fillText("🚀 ELITETRADER.APP · PERFORMANCE REPORT", 820, 565);

    return canvas.toDataURL("image/png");
  };

  const handleDownloadPng = () => {
    try {
      const dataUrl = generateCanvasDataUrl();
      if (!dataUrl) return;
      const link = document.createElement("a");
      const stratSlug = activeFilter.value.replace(/[^a-zA-Z0-9]/g, "-").toLowerCase();
      link.download = `elite-trader-${est.toLowerCase()}-${stratSlug}-report.png`;
      link.href = dataUrl;
      link.click();
    } catch (e) {
      console.error("Erro ao gerar imagem png:", e);
    }
  };

  const handleCopyText = () => {
    const emojiWins = "🏆";
    const emojiReport = "📊";
    const emojiPnl = stats.netPnl >= 0 ? "🟢" : "🔴";
    
    const text = `${emojiReport} *ELITE TRADER REPORT* ${emojiReport}
----------------------------------------
🌐 Ambiente: ${est === "SIMU" ? "Simulador A (Papel)" : est === "SIMU_B" ? "Simulador B (Extremo RSI)" : "Conta Real (Cripto)"}
⚡ Filtro Aplicado: ${activeFilter.label}
🗂️ Amostragem total: ${stats.total} Posições fechadas

🎯 Win Rate (Acertos): ${stats.winRate.toFixed(1)}%
🏆 Vitórias: ${stats.wins} | 💀 Derrotas: ${stats.losses}
📈 Fator de Lucro (Profit Factor): ${stats.profitFactor === Infinity ? "Infinito (Excelente)" : stats.profitFactor.toFixed(2)}
📉 Índice de Payoff (Payoff Ratio): ${stats.payoffRatio === Infinity ? "Infinito (Excelente)" : stats.payoffRatio.toFixed(2)}
${emojiPnl} Lucro Líquido: ${stats.netPnl >= 0 ? "+" : ""}$${stats.netPnl.toFixed(2)} USDT

Análises quantitativas automatizadas em tempo real via inteligência estatística no Elite Trader Cockpit! 🚀`;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(() => {
          alert("Resumo de performance copiado para a área de transferência! Prontinho para colar nas redes sociais!");
        })
        .catch(err => {
          console.error("Erro ao copiar texto:", err);
          alert("Área de transferência bloqueada pelo navegador.");
        });
    } else {
      alert("Copiado com sucesso (fallback):\n\n" + text);
    }
  };
  const pnl = history.reduce((acc, t) => acc + t.pnl, 0);
  const wr =
    history.length > 0
      ? (
          (history.filter((t) => t.pnl > 0).length / history.length) *
          100
        ).toFixed(1)
      : "0.0";
  const wins = history.filter((t) => t.pnl > 0).length;
  const losses = history.filter((t) => t.pnl <= 0).length;
  const flutuante = trades.reduce((acc, t) => acc + t.pnl, 0);

  const closeTrade = async (id: string) => {
    await fetch("/api/close-trade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, motivo: "Saída Manual UI" }),
    });
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-7xl mx-auto min-h-full pb-12 text-slate-300">
      <h2 className="text-2xl font-black text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.6)] tracking-widest uppercase">
        {title}
      </h2>

      {/* Placar */}
      <div className="bg-[#0B0C1A] border border-cyan-400/20 rounded-2xl p-6 flex items-center justify-between shadow-[0_0_15px_rgba(34,211,238,0.1)] flex-wrap gap-4">
        <div className="flex gap-8">
          <span className="text-green-400 font-black text-lg drop-shadow-[0_0_8px_rgba(74,222,128,0.5)] flex items-center gap-2">
            <span className="text-sm">🏆</span> W: {wins}
          </span>
          <span className="text-red-500 font-black text-lg drop-shadow-[0_0_8px_rgba(239,68,68,0.5)] flex items-center gap-2">
            <span className="text-sm">💀</span> L: {losses}
          </span>
          <span className="text-purple-400 font-black text-lg drop-shadow-[0_0_8px_rgba(168,85,247,0.8)] flex items-center gap-2">
            <span className="text-sm">🎯</span> WR: {wr}%
          </span>
        </div>
        <div className="flex gap-8">
          <span className="text-white font-black text-lg">
            💰 LÍQUIDO:{" "}
            <span
              className={
                pnl >= 0
                  ? "text-green-400 drop-shadow-[0_0_8px_rgba(74,222,128,0.5)]"
                  : "text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.5)]"
              }
            >
              ${pnl.toFixed(2)}
            </span>
          </span>
          <span className="text-slate-300 font-black text-lg">
            🌊 FLUTUANTE:{" "}
            <span
              className={flutuante >= 0 ? "text-green-400" : "text-red-500"}
            >
              ${flutuante.toFixed(2)}
            </span>
          </span>
          <span className="text-pink-400 font-black text-lg drop-shadow-[0_0_8px_rgba(236,72,153,0.5)] border border-pink-500/30 px-3 py-1 rounded bg-pink-500/10">
            ATIVAS: {trades.length}
          </span>
        </div>
      </div>

      {/* active section container */}
      <div className="flex flex-col gap-3">
        <h3 className="text-xs font-black tracking-widest text-[#00FFA3] uppercase flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#00FFA3] animate-pulse"></span>
          Operações em Andamento ({trades.length})
        </h3>

        <div className="overflow-auto rounded-xl max-h-[350px] border border-cyan-500/20">
          <div className="bg-[#0A0F1D] overflow-hidden min-w-[800px] flex flex-col shadow-[0_0_10px_rgba(34,211,238,0.05)]">
            <div className="flex px-4 py-3 bg-[#0B0C1A] border-b border-cyan-500/20 text-xs font-bold text-cyan-400 tracking-widest uppercase sticky top-0 z-10">
              <div className="w-32">MOEDA</div>
              <div className="w-20">HORA</div>
              <div className="w-24">LADO</div>
              <div className="w-24">ROI %</div>
              <div className="w-32">MIN/MAX</div>
              <div className="w-32">PNL/MG</div>
              <div className="flex-1">STATUS</div>
              <div className="w-24 text-center">X</div>
            </div>

            <div className="flex flex-col p-2 gap-2 overflow-y-auto">
              {trades.length === 0 && (
                <div className="p-8 text-center text-slate-500 italic font-bold tracking-widest uppercase">
                  Aguardando oportunidades surfar...
                </div>
              )}

              {trades.map((t) => {
                const isLong = t.side === "LONG";
                const pnlColor = t.pnl >= 0 ? "text-green-400" : "text-red-500";

                return (
                  <div
                    key={t.id}
                    className="flex items-center px-4 py-3 bg-[#111326] border border-cyan-500/20 rounded-lg hover:border-cyan-400/50 transition-colors shadow-sm"
                  >
                    <div className="w-32 flex flex-col justify-center">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-white text-sm tracking-wider">
                          🤖 {t.symbol.replace("/USDT", "")}
                        </span>
                        {t.tf && (
                          <span className="text-[9px] font-bold px-1 bg-slate-800 text-slate-300 rounded self-center border border-slate-700 font-mono">
                            {t.tf}
                          </span>
                        )}
                      </div>
                      {t.motor && (
                        <span
                          className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 mt-1 rounded w-fit block ${
                            t.motor === "Motor EXTERNO A"
                              ? "bg-purple-950/40 text-purple-400 border border-purple-500/30"
                              : t.motor === "RADAR COMPASS"
                                ? "bg-rose-950/40 text-rose-400 border border-rose-500/30"
                                : "bg-cyan-950/40 text-cyan-400 border border-cyan-500/30"
                          }`}
                        >
                          {t.motor}
                        </span>
                      )}
                      <span
                        className="text-[10px] text-slate-500 font-mono mt-0.5"
                        title="Preço de Entrada"
                      >
                        Entrada: ${t.entry ? t.entry.toFixed(4) : "--"}{" "}
                        {t.adx ? `| ADX: ${t.adx}` : ""}
                      </span>
                    </div>
                    <div className="w-20 text-xs text-slate-400 font-mono tracking-widest">
                      {t.dataIn}
                    </div>
                    <div
                      className={`w-24 font-black text-sm tracking-widest ${isLong ? "text-green-400 drop-shadow-[0_0_5px_rgba(74,222,128,0.5)]" : "text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]"}`}
                    >
                      {t.side}
                    </div>
                    <div
                      className={`w-24 font-black text-sm tracking-widest ${t.roi >= 0 ? "text-green-400" : "text-red-500"}`}
                    >
                      {t.roi >= 0 ? "+" : ""}
                      {t.roi.toFixed(2)}%
                    </div>
                    <div className="w-32 text-xs text-slate-400 font-mono">
                      <span
                        className="text-red-500 font-medium"
                        title="Mínimo ROI flutuante (Rebaixamento máximo)"
                      >
                        {t.minRoi >= 0 ? "+" : ""}
                        {t.minRoi.toFixed(1)}%
                      </span>{" "}
                      <span className="text-slate-600">/</span>{" "}
                      <span
                        className="text-green-400 font-medium"
                        title="Máximo ROI flutuante (Pico máximo)"
                      >
                        {t.maxRoi >= 0 ? "+" : ""}
                        {t.maxRoi.toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-32 flex flex-col">
                      <span
                        className={`font-black text-sm tracking-tight ${pnlColor}`}
                      >
                        ${t.pnl.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-slate-500 tracking-widest font-mono">
                        MG: ${t.margin.toFixed(2)} | {t.lev}x
                      </span>
                    </div>
                    <div className="flex-1 text-xs font-bold text-slate-300 tracking-wider">
                      <span
                        className={`px-2 py-1 rounded bg-black/50 border ${t.roi >= 100 ? "border-yellow-500/50 text-yellow-400" : "border-cyan-500/30 text-cyan-400"}`}
                      >
                        {t.roi >= 100
                          ? `[${t.estrategia}] 🏄 SURF EXTREMO`
                          : `[${t.estrategia}] 🟢 BUSCANDO ALVO`}
                      </span>
                    </div>
                    <div className="w-24 flex justify-center">
                      <button
                        onClick={() => closeTrade(t.id)}
                        className="px-4 py-1.5 rounded-lg bg-pink-500/20 text-pink-500 border border-pink-500/30 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-all shadow-[0_0_10px_rgba(236,72,153,0.1)] flex items-center justify-center font-bold tracking-widest text-[10px]"
                      >
                        SAIR
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* closed trades history section container */}
      <div className="flex flex-col gap-3 mt-4">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <h3 className="text-xs font-black tracking-widest text-[#ec4899] uppercase flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#ec4899]"></span>
            Histórico de Operações Fechadas ({history.length})
          </h3>
          <button
            onClick={() => setShowShareModal(true)}
            className="px-3.5 py-1.5 rounded-lg bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500 hover:text-white hover:border-indigo-500 hover:-translate-y-0.5 transition-all text-[11px] font-black tracking-wider flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(99,102,241,0.15)] uppercase"
          >
            <span>📊</span> Gerar Card de Performance
          </button>
        </div>

        <div className="overflow-auto rounded-xl max-h-[350px] border border-pink-500/20">
          <div className="bg-[#0A0F1D] overflow-hidden min-w-[800px] flex flex-col shadow-[0_0_15px_rgba(236,72,153,0.05)]">
            <div className="flex px-4 py-3 bg-[#0B0C1A] border-b border-pink-500/20 text-xs font-bold text-pink-400 tracking-widest uppercase sticky top-0 z-10">
              <div className="w-32">MOEDA</div>
              <div className="w-20">ENTRADA</div>
              <div className="w-20">SAÍDA</div>
              <div className="w-24">DURAÇÃO</div>
              <div className="w-24">LADO</div>
              <div className="w-32">ROI (MIN/MAX)</div>
              <div className="w-28 text-center">LUCRO</div>
              <div className="flex-1 pl-4">MOTIVO DO ENCERRAMENTO</div>
            </div>

            <div className="flex flex-col p-2 gap-2 overflow-y-auto">
              {history.length === 0 && (
                <div className="p-8 text-center text-slate-500 italic font-bold tracking-widest uppercase">
                  Nenhum histórico registrado neste simulador ainda.
                </div>
              )}

              {history.map((t) => {
                const pnlColor = t.pnl >= 0 ? "text-green-400" : "text-red-500";
                const isLong = t.side === "LONG";

                const extractMins = (hStr: string) => {
                  const [h, m, s] = hStr.split(":").map(Number);
                  return (h || 0) * 60 + (m || 0) + (s || 0) / 60;
                };
                let durationMins = 0;
                if (t.dataFim && t.dataIn) {
                  const inMins = extractMins(t.dataIn);
                  const outMins = extractMins(t.dataFim);
                  durationMins =
                    outMins >= inMins
                      ? outMins - inMins
                      : 24 * 60 - inMins + outMins;
                }

                let durationTag = "Short";
                let durationColor =
                  "bg-cyan-900/40 text-cyan-400 border-cyan-500/30";
                if (durationMins >= 120) {
                  durationTag = "Long";
                  durationColor =
                    "bg-purple-900/40 text-purple-400 border-purple-500/30";
                } else if (durationMins >= 30) {
                  durationTag = "Medium";
                  durationColor =
                    "bg-amber-900/40 text-amber-400 border-amber-500/30";
                }

                return (
                  <div
                    key={t.id + (t.dataFim || "")}
                    className="flex items-center px-4 py-3 bg-[#111326] border border-pink-500/10 rounded-lg hover:border-pink-500/40 transition-colors shadow-sm"
                  >
                    <div className="w-32 flex flex-col justify-center">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-white text-sm tracking-widest">
                          🤖 {t.symbol.replace("/USDT", "")}
                        </span>
                        {t.tf && (
                          <span className="text-[9px] font-bold px-1 bg-slate-800 text-slate-300 rounded self-center border border-slate-700 font-mono">
                            {t.tf}
                          </span>
                        )}
                      </div>
                      {t.motor && (
                        <span
                          className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 mt-1 rounded w-fit block ${
                            t.motor === "Motor EXTERNO A"
                              ? "bg-purple-950/40 text-purple-400 border border-purple-500/30"
                              : t.motor === "RADAR COMPASS"
                                ? "bg-rose-950/40 text-rose-400 border border-rose-500/30"
                                : "bg-cyan-950/40 text-cyan-400 border border-cyan-500/30"
                          }`}
                        >
                          {t.motor}
                        </span>
                      )}
                      <span
                        className="text-[10px] text-slate-500 font-mono mt-0.5"
                        title="Preço de Entrada"
                      >
                        Entrada: ${t.entry ? t.entry.toFixed(4) : "--"}{" "}
                        {t.adx ? `| ADX: ${t.adx}` : ""}
                      </span>
                    </div>
                    <div className="w-20 text-xs text-slate-400 font-mono">
                      {t.dataIn}
                    </div>
                    <div className="w-20 text-xs text-slate-300 font-mono font-bold">
                      {t.dataFim || "--:--"}
                    </div>
                    <div className="w-24 flex items-center">
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded border tracking-widest uppercase ${durationColor}`}
                      >
                        {durationTag}
                      </span>
                    </div>
                    <div
                      className={`w-24 font-black text-sm tracking-widest ${isLong ? "text-green-400" : "text-red-500"}`}
                    >
                      {t.side}
                    </div>
                    <div className="w-32 flex flex-col justify-center">
                      <span
                        className={`font-black text-sm tracking-widest ${t.roi >= 0 ? "text-green-400" : "text-red-500"}`}
                      >
                        {t.roi >= 0 ? "+" : ""}
                        {t.roi.toFixed(2)}%
                      </span>
                      <div className="text-[10px] font-mono tracking-widest mt-0.5 flex items-center gap-1">
                        <span
                          className="text-red-500 font-medium"
                          title="Mínimo ROI atingido (Rebaixamento máximo)"
                        >
                          {t.minRoi >= 0 ? "+" : ""}
                          {t.minRoi.toFixed(1)}%
                        </span>
                        <span className="text-slate-600">/</span>
                        <span
                          className="text-green-400 font-medium"
                          title="Máximo ROI atingido (Pico máximo)"
                        >
                          {t.maxRoi >= 0 ? "+" : ""}
                          {t.maxRoi.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div className="w-28 flex flex-col items-center justify-center">
                      <span
                        className={`font-black text-md tracking-tight text-center ${pnlColor} drop-shadow-[0_0_5px_currentColor]`}
                      >
                        ${t.pnl.toFixed(2)}
                      </span>
                      <span
                        className="text-[9px] text-slate-500 tracking-widest font-mono mt-0.5"
                        title="Margem de Entrada"
                      >
                        MG: ${t.margin ? t.margin.toFixed(2) : "--"} |{" "}
                        {t.lev || 10}x
                      </span>
                    </div>
                    <div className="flex-1 pl-4 text-xs font-mono text-slate-400 italic tracking-wider">
                      {t.motivo}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Share Modal Render */}
      {showShareModal && (
        <div className="fixed inset-0 bg-[#020208]/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0b0c16] border border-cyan-500/30 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-[0_0_50px_rgba(34,211,238,0.2)] flex flex-col md:flex-row gap-6 p-6 md:p-8 relative">
            
            {/* Close Button */}
            <button
              onClick={() => setShowShareModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer border-none"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Left Controls Column */}
            <div className="flex-1 flex flex-col justify-between gap-5 min-w-[280px]">
              <div>
                <span className="text-[10px] font-black uppercase text-indigo-400 tracking-widest bg-indigo-500/10 border border-indigo-500/30 px-2 py-0.5 rounded w-fit block mb-2 font-mono">
                  Gerador para Redes Sociais
                </span>
                <h3 className="text-xl font-black text-white tracking-widest uppercase mb-1 font-mono">
                  RESUMO DA PERFORMANCE 📊
                </h3>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                  Gere um infográfico de alta qualidade contendo o <strong className="text-cyan-400">Profit Factor</strong> e <strong className="text-pink-400">Payoff Ratio</strong> das posições. Pronto para divulgar no Twitter, Telegram, WhatsApp ou LinkedIn.
                </p>

                {/* StrategySelector */}
                <div className="mb-4">
                  <label className="block text-[10px] font-black text-slate-400 tracking-widest uppercase mb-1.5 flex items-center gap-1 font-mono">
                    <span>🔍</span> Escolher Filtro de Estratégia:
                  </label>
                  <select
                    value={selectedFilterIdx}
                    onChange={(e) => setSelectedFilterIdx(Number(e.target.value))}
                    className="w-full bg-[#111326] border border-cyan-500/20 text-slate-300 rounded-lg py-2 px-3 text-xs font-bold font-mono focus:border-cyan-400 focus:outline-none transition-colors cursor-pointer"
                  >
                    {filterOptions.map((opt, i) => (
                      <option key={i} value={i} className="bg-[#111326] text-slate-300 font-mono font-bold">
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Stats Table */}
                <div className="bg-[#111326]/50 border border-slate-800/50 rounded-xl p-4 flex flex-col gap-2.5 font-mono text-xs">
                  <div className="flex justify-between border-b border-slate-800/50 pb-1.5 text-[10px] font-black uppercase text-slate-500">
                    <span>INDICADOR</span>
                    <span>VALOR</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Operações Fechadas:</span>
                    <span className="font-bold text-white">{stats.total} trades</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Vitórias / Derrotas:</span>
                    <span className="font-semibold text-slate-300">{stats.wins}W / {stats.losses}L</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Taxa de Acerto (WR):</span>
                    <span className="font-black text-cyan-400">{stats.winRate.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Profit Factor:</span>
                    <span className="font-bold text-purple-400">
                      {stats.profitFactor === Infinity ? "Excelente (∞)" : stats.profitFactor.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Payoff Ratio:</span>
                    <span className="font-bold text-pink-400">
                      {stats.payoffRatio === Infinity ? "Elevado (∞)" : stats.payoffRatio.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Lucro Líquido Total:</span>
                    <span className={`font-black ${stats.netPnl >= 0 ? "text-emerald-400" : "text-rose-500"}`}>
                      {stats.netPnl >= 0 ? "+" : ""}${stats.netPnl.toFixed(2)} USDT
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2">
                <button
                  onClick={handleDownloadPng}
                  className="w-full py-3 px-4 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-widest rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center justify-center gap-2 cursor-pointer border-none"
                >
                  <span>📥</span> BAIXAR IMAGEM CARD (.PNG)
                </button>
                <button
                  onClick={handleCopyText}
                  className="w-full py-2.5 px-4 bg-[#111326] border border-cyan-500/20 hover:border-cyan-400 text-cyan-400 font-bold text-[10px] uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>📋</span> COPIAR TEXTO FORMATADO
                </button>
              </div>
            </div>

            {/* Right Interactive Preview Card Column */}
            <div className="flex-[1.2] flex flex-col justify-center items-center bg-[#070914] rounded-2xl p-4 md:p-6 border border-slate-900 shadow-md">
              <span className="text-[9px] font-black uppercase text-slate-500 tracking-widest mb-3 font-mono">
                Pré-visualização do Card Social (1200 x 675px)
              </span>

              {/* Visual Card Mockup (16:9 responsive display) */}
              <div className="aspect-[16/9] w-full bg-gradient-to-br from-[#080913] to-[#121526] border border-cyan-500/30 rounded-xl p-5 flex flex-col justify-between relative shadow-lg overflow-hidden text-white font-sans max-w-[480px]">
                
                {/* Visual grid pattern bg mock */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, #94a3b8 1px, transparent 1px)", backgroundSize: "16px 16px" }} />
                
                {/* Header info */}
                <div className="z-10 flex justify-between items-start border-b border-white/5 pb-2">
                  <div>
                    <h4 className="text-[11px] font-black tracking-widest text-slate-100 uppercase flex items-center gap-1 font-mono">
                      <span>🤖</span> Elite Trader Cockpit
                    </h4>
                    <span className="text-[7px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                      Sistema Quantitativo de Alta Performance
                    </span>
                  </div>
                  <span className={`text-[7px] font-black px-1.5 py-0.5 rounded border ${
                    est === "SIMU" 
                      ? "bg-cyan-950/40 text-cyan-400 border-cyan-500/30" 
                      : est === "SIMU_B" 
                        ? "bg-pink-950/40 text-pink-400 border-pink-500/30" 
                        : "bg-amber-950/40 text-amber-500 border-amber-500/30"
                  }`}>
                    {est === "SIMU" ? "Simulador A" : est === "SIMU_B" ? "Simulador B" : "Conta Real"}
                  </span>
                </div>

                {/* Middle details */}
                <div className="z-10 flex flex-col gap-1 my-2">
                  <span className="text-[8px] font-black text-slate-400 tracking-widest uppercase font-mono">
                    Estratégia Ativa:
                  </span>
                  <p className="text-[11px] font-extrabold text-cyan-400 uppercase tracking-wider truncate font-mono">
                    {activeFilter.label}
                  </p>
                  <span className="text-[7px] font-mono text-slate-500 uppercase tracking-widest mt-0.5">
                    Amostragem: {stats.total} trades fechados
                  </span>
                </div>

                {/* 4 Metric cards layout */}
                <div className="z-10 grid grid-cols-4 gap-1.5 my-1">
                  
                  {/* Metric 1 */}
                  <div className="bg-black/40 border border-white/5 rounded p-1.5 flex flex-col justify-between">
                    <span className="text-[6px] font-black text-slate-500 uppercase font-mono">Win Rate</span>
                    <span className="text-[10px] font-black text-cyan-400 font-mono">{stats.winRate.toFixed(1)}%</span>
                    <span className="text-[5px] text-slate-600 font-mono">{stats.wins}W - {stats.losses}L</span>
                  </div>

                  {/* Metric 2 */}
                  <div className="bg-black/40 border border-white/5 rounded p-1.5 flex flex-col justify-between">
                    <span className="text-[6px] font-black text-slate-500 uppercase font-mono">Profit Factor</span>
                    <span className="text-[10px] font-black text-purple-400 truncate font-mono">
                      {stats.profitFactor === Infinity ? "∞" : stats.profitFactor.toFixed(2)}
                    </span>
                    <span className="text-[5px] text-slate-600 font-mono">Fator Lucro</span>
                  </div>

                  {/* Metric 3 */}
                  <div className="bg-black/40 border border-white/5 rounded p-1.5 flex flex-col justify-between">
                    <span className="text-[6px] font-black text-slate-500 uppercase font-mono">Payoff Ratio</span>
                    <span className="text-[10px] font-black text-pink-400 truncate font-mono">
                      {stats.payoffRatio === Infinity ? "∞" : stats.payoffRatio.toFixed(2)}
                    </span>
                    <span className="text-[5px] text-slate-600 font-mono">Retorno/Risco</span>
                  </div>

                  {/* Metric 4 */}
                  <div className="bg-black/40 border border-white/5 rounded p-1.5 flex flex-col justify-between">
                    <span className="text-[6px] font-black text-slate-500 uppercase font-mono">Líquido</span>
                    <span className={`text-[10px] font-black truncate font-mono ${stats.netPnl >= 0 ? "text-emerald-400" : "text-rose-500"}`}>
                      {stats.netPnl >= 0 ? "+" : ""}${stats.netPnl.toFixed(1)}
                    </span>
                    <span className="text-[5px] text-slate-600 font-mono">Lucro USDT</span>
                  </div>

                </div>

                {/* Footer report */}
                <div className="z-10 border-t border-white/5 pt-1.5 flex justify-between items-center text-[5.5px] font-mono text-slate-500 uppercase tracking-widest">
                  <span>Elite Trader Cockpit © 2026</span>
                  <span className="font-extrabold text-[#00FFA3]">www.elitetrader.app</span>
                </div>

              </div>

              <span className="text-[10px] text-center text-slate-500 italic leading-normal max-w-[320px] mt-3">
                Ao baixar, geramos um card de imagem de ultra fidelidade com as bordas em alta resolução!
              </span>

            </div>

          </div>
        </div>
      )}
    </div>
  );
}

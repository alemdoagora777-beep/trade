import React, { useState } from 'react';
import { KeyRound, ShieldCheck } from 'lucide-react';
import { cn } from '../lib/utils.js';

interface LoginViewProps {
  onLogin: () => void;
}

export function LoginView({ onLogin }: LoginViewProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'DEUS') { // Easter egg + security for MVP, later supabase
      onLogin();
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
      setPassword('');
    }
  };

  return (
    <div className="min-h-screen bg-[#050510] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-[#0A0A18] border border-pink-500/20 rounded-2xl shadow-[0_0_50px_rgba(236,72,153,0.1)] p-8 flex flex-col items-center">
        <div className="w-20 h-20 rounded-full bg-pink-500/10 flex items-center justify-center border border-pink-500/30 shadow-[0_0_20px_rgba(236,72,153,0.2)] mb-6">
          <ShieldCheck className="w-10 h-10 text-pink-500 drop-shadow-[0_0_10px_rgba(236,72,153,0.8)]" />
        </div>
        
        <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-cyan-400 tracking-wider text-center drop-shadow-[0_0_10px_rgba(236,72,153,0.5)] mb-2">
          ACESSO RESTRITO
        </h1>
        <p className="text-slate-500 text-xs font-mono tracking-widest text-center mb-8 uppercase">
          Insira a Master Key para prosseguir
        </p>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <KeyRound className="h-5 w-5 text-pink-500/50" />
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={cn(
                "w-full bg-[#050510] border rounded-xl py-4 pl-12 pr-4 text-center tracking-[0.5em] font-mono text-white placeholder-slate-700 focus:outline-none transition-all duration-300",
                error 
                  ? "border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)] text-rose-500" 
                  : "border-pink-900/50 focus:border-pink-500 focus:shadow-[0_0_15px_rgba(236,72,153,0.3)]"
              )}
              placeholder="••••"
              autoFocus
            />
          </div>

          <button
            type="submit"
            className="w-full bg-pink-600 hover:bg-pink-500 text-white font-black tracking-widest uppercase py-4 rounded-xl shadow-[0_0_20px_rgba(236,72,153,0.4)] hover:shadow-[0_0_30px_rgba(236,72,153,0.6)] transition-all duration-300 flex items-center justify-center gap-3"
          >
            DESBLOQUEAR SISTEMA
          </button>
        </form>

        <div className="mt-8 text-center">
          <span className="text-[10px] text-pink-500/50 font-bold tracking-[0.2em] uppercase">DEUS ESTÁ NO CONTROLE</span>
        </div>
      </div>
    </div>
  );
}

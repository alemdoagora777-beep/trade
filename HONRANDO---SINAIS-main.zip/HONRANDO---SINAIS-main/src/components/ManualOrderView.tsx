import React, { useState } from 'react';
import { cn } from '../lib/utils.js';
import { PlusCircle, Info } from 'lucide-react';

export function ManualOrderView() {
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [side, setSide] = useState<'LONG' | 'SHORT'>('LONG');
  // 'SIMU' = TESTE A, 'SIMU_B' = TESTE B, 'REAL' = REAL
  const [mode, setMode] = useState<'SIMU' | 'SIMU_B' | 'REAL'>('SIMU');
  const [estrategia, setEstrategia] = useState<'A' | 'B'>('A');
  const [margin, setMargin] = useState('1');
  const [lev, setLev] = useState('20');
  
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [takeProfit, setTakeProfit] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  const calcRiskReward = () => {
     const ep = parseFloat(entryPrice);
     const sl = parseFloat(stopLoss);
     const tp = parseFloat(takeProfit);

     if (!ep || !sl || !tp) return null;

     let risk, reward;
     if (side === 'LONG') {
         risk = ep - sl;
         reward = tp - ep;
     } else {
         risk = sl - ep;
         reward = ep - tp;
     }

     if (risk <= 0 || reward <= 0) return null;
     
     return reward / risk;
  };

  const rrRatio = calcRiskReward();

  const handleSubmit = async () => {
    if (!symbol) return;
    setIsSubmitting(true);
    await fetch('/api/manual-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
         symbol,
         side,
         est: mode,
         estrategia,
         margin,
         lev,
         entryPrice: parseFloat(entryPrice) || undefined,
         stopLoss: parseFloat(stopLoss) || undefined,
         takeProfit: parseFloat(takeProfit) || undefined
      })
    });
    // Can show success toast or reset if wanted
    setTimeout(() => {
        setIsSubmitting(false);
    }, 500);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-4xl max-w-2xl mx-auto min-h-full pb-12 text-slate-300">
      <div className="mb-2">
        <h1 className="text-2xl font-black text-amber-500 tracking-widest uppercase mb-1 drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]">NOVA ORDEM MANUAL</h1>
        <p className="text-xs text-slate-400 font-mono tracking-widest uppercase">INJETAR TRADE NO SISTEMA (SERÁ RASTREADO PELA MESMA LÓGICA DE AUDITORIA)</p>
      </div>

      <div className="bg-[#0A0C16] border border-cyan-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
        
        {/* PAR & LADO */}
        <div className="grid grid-cols-2 gap-6">
            <div className="flex flex-col gap-2">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Moeda (PAR USDT)</label>
                <input 
                    type="text" 
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                    className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-cyan-500 rounded-lg px-4 py-3 text-sm font-bold text-white tracking-widest focus:outline-none transition-colors"
                />
            </div>
            
            <div className="flex flex-col gap-2">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Lado</label>
                <div className="flex bg-[#050510] border border-slate-700 p-1 rounded-lg gap-1">
                    <button 
                        onClick={() => setSide('LONG')}
                        className={cn(
                            "flex-1 px-4 py-2 text-sm font-bold tracking-widest uppercase rounded flex items-center justify-center transition-all",
                            side === 'LONG' ? "bg-green-900/30 text-green-400 border border-green-500 shadow-[0_0_10px_rgba(34,197,94,0.2)]" : "text-slate-500 hover:text-slate-300"
                        )}
                    >
                        LONG
                    </button>
                    <button 
                        onClick={() => setSide('SHORT')}
                        className={cn(
                            "flex-1 px-4 py-2 text-sm font-bold tracking-widest uppercase rounded flex items-center justify-center transition-all",
                            side === 'SHORT' ? "bg-red-900/30 text-red-500 border border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.2)]" : "text-slate-500 hover:text-slate-300"
                        )}
                    >
                        SHORT
                    </button>
                </div>
            </div>
        </div>

        {/* RISCO & ALVOS (R:R) */}
        <div className="flex flex-col gap-3">
            <div className="flex justify-between items-center mb-1">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-2">
                    Risco & Alvos (R:R) <Info className="w-3 h-3 cursor-help text-slate-400" />
                </label>
                {rrRatio !== null && (
                    <span className={cn(
                        "text-[10px] font-black tracking-widest px-2 py-0.5 rounded flex items-center gap-1",
                        rrRatio >= 2 ? "text-[#00FFA3] bg-[#00FFA3]/20" : (rrRatio >= 1 ? "text-amber-400 bg-amber-500/20" : "text-rose-500 bg-rose-500/20")
                    )}>
                        1 : {rrRatio.toFixed(2)}
                    </span>
                )}
            </div>
            
            <div className="grid grid-cols-3 gap-4">
                <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Entrada (US$)</span>
                    <input 
                        type="number" 
                        value={entryPrice}
                        onChange={(e) => setEntryPrice(e.target.value)}
                        placeholder="Ex: 65000"
                        className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-cyan-500 rounded-lg px-3 py-2.5 text-xs font-bold text-white font-mono focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.05)]"
                    />
                </div>
                <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Stop Loss</span>
                    <input 
                        type="number" 
                        value={stopLoss}
                        onChange={(e) => setStopLoss(e.target.value)}
                        placeholder="Ex: 64000"
                        className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-rose-500 rounded-lg px-3 py-2.5 text-xs font-bold text-rose-400 font-mono focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(244,63,94,0.05)]"
                    />
                </div>
                <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Take Profit</span>
                    <input 
                        type="number" 
                        value={takeProfit}
                        onChange={(e) => setTakeProfit(e.target.value)}
                        placeholder="Ex: 67000"
                        className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-[#00FFA3] rounded-lg px-3 py-2.5 text-xs font-bold text-[#00FFA3] font-mono focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(0,255,163,0.05)]"
                    />
                </div>
            </div>

            {rrRatio === null && (entryPrice && stopLoss && takeProfit) && (
                <div className="text-[10px] text-rose-500/80 italic font-mono uppercase tracking-widest mt-1">
                    Valores inválidos para {side}. SL deve estar {side === 'LONG' ? 'abaixo' : 'acima'} da entrada, TP {side === 'LONG' ? 'acima' : 'abaixo'}.
                </div>
            )}
        </div>

        {/* MODO DE EXECUÇÃO */}
        <div className="flex flex-col gap-2">
            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Modo de Execução</label>
            <div className="flex bg-[#050510] border border-slate-700 p-1 rounded-lg gap-1">
                <button 
                    onClick={() => setMode('SIMU')}
                    className={cn(
                        "flex flex-col items-center justify-center flex-1 py-3 px-2 rounded border transition-all",
                        mode === 'SIMU' ? "bg-cyan-900/20 border-cyan-500 ring-1 ring-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]" : "border-transparent text-slate-500 hover:text-slate-300"
                    )}
                >
                    <span className={cn("text-sm font-bold tracking-widest", mode === 'SIMU' ? 'text-cyan-400' : '')}>TESTE A</span>
                    <span className="text-[10px] mt-1 opacity-70">Estratégia clássica</span>
                </button>

                <button 
                    onClick={() => setMode('SIMU_B')}
                    className={cn(
                        "flex flex-col items-center justify-center flex-1 py-3 px-2 rounded border transition-all",
                        mode === 'SIMU_B' ? "bg-purple-900/20 border-purple-500 ring-1 ring-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.1)]" : "border-transparent text-slate-500 hover:text-slate-300"
                    )}
                >
                    <span className={cn("text-sm font-bold tracking-widest", mode === 'SIMU_B' ? 'text-purple-400' : '')}>TESTE B</span>
                    <span className="text-[10px] mt-1 opacity-70">Estratégia com surf</span>
                </button>

                <button 
                    onClick={() => setMode('REAL')}
                    className={cn(
                        "flex flex-col items-center justify-center flex-1 py-3 px-2 rounded border transition-all",
                        mode === 'REAL' ? "bg-rose-900/20 border-rose-500 ring-1 ring-rose-500/50 shadow-[0_0_15px_rgba(225,29,72,0.1)]" : "border-transparent text-slate-500 hover:text-slate-300"
                    )}
                >
                    <span className={cn("text-sm font-bold tracking-widest", mode === 'REAL' ? 'text-rose-400' : '')}>REAL</span>
                    <span className="text-[10px] mt-1 opacity-70">Modo conta real</span>
                </button>
            </div>
            
            {/* Context details based on Mode */}
            <div className="mt-2 bg-[#050510]/50 border border-slate-700/50 p-3 rounded-lg text-xs flex gap-2 font-mono">
                {mode === 'SIMU' && <><span className="text-cyan-400 font-bold">TESTE A:</span> <span className="text-slate-400">Parcial 50% @ +15% • Trailing +10% • SL -25% • Time-stop 45m</span></>}
                {mode === 'SIMU_B' && <><span className="text-purple-400 font-bold">TESTE B:</span> <span className="text-slate-400">Maior foco em alvo de surf. Risco e stops baseados em ATR.</span></>}
                {mode === 'REAL' && <><span className="text-rose-400 font-bold">REAL:</span> <span className="text-slate-400">Execução final via Binance considerando taxa e slippage.</span></>}
            </div>
        </div>

        {/* ESTRATÉGIA DE SAÍDA */}
        <div className="flex flex-col gap-3 mt-2 border border-slate-700 rounded-xl p-5 bg-[#0A0A10]">
            <label className="text-xs text-amber-500/80 font-bold uppercase tracking-widest mb-1">Qual Estratégia de Saída?</label>
            
            <label 
                className={cn(
                    "flex px-4 py-4 rounded-xl border cursor-pointer hover:bg-white/5 transition-all",
                    estrategia === 'A' ? "border-amber-500/50 bg-amber-500/5" : "border-slate-800"
                )}
            >
                <div className="flex items-center h-5">
                    <input 
                        type="radio" 
                        name="estrategia" 
                        className="w-4 h-4 text-amber-500 bg-black border-slate-600 focus:ring-amber-500 focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0A0A10]" 
                        checked={estrategia === 'A'} 
                        onChange={() => setEstrategia('A')}
                    />
                </div>
                <div className="ms-3 text-sm">
                    <span className="font-bold text-amber-100 flex items-center tracking-wide">Estratégia A (Alvo 100%)</span>
                    <p className="text-[10px] font-mono text-slate-500 mt-1 uppercase tracking-widest">Segura a posição até alvo 100% • SL -25%</p>
                </div>
            </label>

            <label 
                className={cn(
                    "flex px-4 py-4 rounded-xl border cursor-pointer hover:bg-white/5 transition-all",
                    estrategia === 'B' ? "border-amber-500/50 bg-amber-500/5" : "border-slate-800"
                )}
            >
                <div className="flex items-center h-5">
                    <input 
                        type="radio" 
                        name="estrategia" 
                        className="w-4 h-4 text-amber-500 bg-black border-slate-600 focus:ring-amber-500 focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0A0A10]" 
                        checked={estrategia === 'B'} 
                        onChange={() => setEstrategia('B')}
                    />
                </div>
                <div className="ms-3 text-sm">
                    <span className="font-bold text-amber-100 flex items-center tracking-wide">Estratégia B (Parciais 15% e 30%)</span>
                    <p className="text-[10px] font-mono text-slate-500 mt-1 uppercase tracking-widest">Vende 50% @ +15% (SL {'->'} BE) • Vende 50% restantes @ +30%</p>
                </div>
            </label>
        </div>

        {/* MARGEM & ALAVANCAGEM */}
        <div className="grid grid-cols-2 gap-6 mt-2">
            <div className="flex flex-col gap-2">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Margem US$</label>
                <input 
                    type="number" 
                    value={margin}
                    onChange={(e) => setMargin(e.target.value)}
                    className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-amber-500 rounded-lg px-4 py-3 text-sm font-bold text-white tracking-widest focus:outline-none transition-colors"
                />
            </div>
            
            <div className="flex flex-col gap-2">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Alavancagem</label>
                <input 
                    type="number" 
                    value={lev}
                    onChange={(e) => setLev(e.target.value)}
                    className="bg-[#050510] border border-slate-700 hover:border-slate-500 focus:border-amber-500 rounded-lg px-4 py-3 text-sm font-bold text-white tracking-widest focus:outline-none transition-colors"
                />
            </div>
        </div>

        <button 
           disabled={isSubmitting || !symbol}
           onClick={handleSubmit}
           className="mt-4 bg-amber-500 hover:bg-amber-400 text-black font-black uppercase tracking-widest py-4 rounded-xl flex items-center justify-center gap-3 transition-colors shadow-[0_0_20px_rgba(245,158,11,0.2)] hover:shadow-[0_0_25px_rgba(245,158,11,0.4)] relative disabled:opacity-50 disabled:cursor-not-allowed"
        >
           <PlusCircle className="w-5 h-5" />
           Criar ordem ({mode === 'SIMU' ? 'TESTE A' : mode === 'SIMU_B' ? 'TESTE B' : 'REAL'} · {estrategia})
        </button>

      </div>
    </div>
  );
}

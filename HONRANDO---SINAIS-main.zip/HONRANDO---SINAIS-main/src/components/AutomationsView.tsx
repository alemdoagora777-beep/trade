import React from 'react';
import { BotState } from '../types.js';
import { cn } from '../lib/utils.js';
import { Power, Settings2, ShieldCheck } from 'lucide-react';

export function AutomationsView({ state }: { state: BotState }) {
  const updateCfg = async (key: string, value: any) => {
    await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [key]: value })
    });
  };

  const Switch = ({ checked, onChange, label, className, offLabel = "OFF", onLabel = "ON" }: any) => (
    <div className={cn("flex items-center justify-between gap-4 px-5 py-3 border border-slate-800 rounded-xl bg-[#050510] h-[52px]", className)}>
      <span className="font-bold tracking-widest text-[11px] uppercase text-slate-400 font-mono flex-1">{label}</span>
      <div className="flex items-center gap-3">
         <div 
           onClick={() => onChange(!checked)}
           className={cn(
             "w-[42px] h-[22px] rounded-full relative transition-colors duration-300 flex items-center shrink-0 cursor-pointer border shadow-sm", 
             checked ? "bg-cyan-500 border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)]" : "bg-black border-slate-700"
           )}
         >
           <div className={cn("absolute w-4 h-4 rounded-full bg-white transition-all duration-300 drop-shadow-md", checked ? "right-1" : "left-1")} />
         </div>
         <span className={cn("text-[10px] font-black uppercase tracking-widest w-6", checked ? "text-cyan-400" : "text-slate-600")}>
            {checked ? onLabel : offLabel}
         </span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1240px] mx-auto min-h-full text-slate-300 pb-12 pt-2">
      
      {/* INTEGRAÇÕES E KILL SWITCH */}
      <div className="bg-[#0A0C16] border border-slate-800/80 rounded-xl p-6 shadow-xl flex flex-col gap-6 relative overflow-hidden">
        <h2 className="text-xs font-black text-slate-300 tracking-widest uppercase flex items-center gap-2">
           <Power className="w-4 h-4 text-amber-500" />
           INTEGRAÇÕES
        </h2>

        <div className="flex flex-col gap-3">
           {/* BINANCE */}
           <div className="flex items-center justify-between border border-[#00FFA3]/30 bg-[#00FFA3]/5 rounded-lg px-5 py-3 h-[52px]">
              <input 
                 type="password" 
                 placeholder="BINANCE API (KEY + SECRET)"
                 value={state.cfg.binanceKey || ''}
                 onChange={e => updateCfg('binanceKey', e.target.value)}
                 className="bg-transparent border-none text-[11px] font-mono tracking-widest text-white focus:outline-none w-full uppercase placeholder-slate-600"
              />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3]">
                 <ShieldCheck className="w-3.5 h-3.5" />
                 <span className="text-[9px] font-black tracking-widest uppercase">Conectado</span>
              </div>
           </div>
           
           {/* TELEGRAM TOKEN */}
           <div className="flex items-center justify-between border border-[#00FFA3]/30 bg-[#00FFA3]/5 rounded-lg px-5 py-3 h-[52px]">
              <input 
                 type="password" 
                 placeholder="TELEGRAM TOKEN"
                 value={state.cfg.tgTokenArmado || ''}
                 onChange={e => updateCfg('tgTokenArmado', e.target.value)}
                 className="bg-transparent border-none text-[11px] font-mono tracking-widest text-white focus:outline-none w-full uppercase placeholder-slate-600"
              />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3]">
                 <ShieldCheck className="w-3.5 h-3.5" />
                 <span className="text-[9px] font-black tracking-widest uppercase">Conectado</span>
              </div>
           </div>

           {/* TELEGRAM CHAT ID */}
           <div className="flex items-center justify-between border border-[#00FFA3]/30 bg-[#00FFA3]/5 rounded-lg px-5 py-3 h-[52px]">
              <input 
                 type="password" 
                 placeholder="TELEGRAM CHAT ID"
                 value={state.cfg.tgChatId || ''}
                 onChange={e => updateCfg('tgChatId', e.target.value)}
                 className="bg-transparent border-none text-[11px] font-mono tracking-widest text-white focus:outline-none w-full uppercase placeholder-slate-600"
              />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3]">
                 <ShieldCheck className="w-3.5 h-3.5" />
                 <span className="text-[9px] font-black tracking-widest uppercase">Conectado</span>
              </div>
           </div>

           {/* WEBHOOK SECRET */}
           <div className="flex items-center justify-between border border-[#00FFA3]/30 bg-[#00FFA3]/5 rounded-lg px-5 py-3 h-[52px]">
              <input 
                 type="password" 
                 placeholder="WEBHOOK SECRET"
                 value={state.cfg.lovableWebhookSecret || ''}
                 onChange={e => updateCfg('lovableWebhookSecret', e.target.value)}
                 className="bg-transparent border-none text-[11px] font-mono tracking-widest text-white focus:outline-none w-full uppercase placeholder-slate-600"
              />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3]">
                 <ShieldCheck className="w-3.5 h-3.5" />
                 <span className="text-[9px] font-black tracking-widest uppercase">Conectado</span>
              </div>
           </div>
        </div>

        <div className="border border-[#00FFA3]/30 rounded-xl p-5 bg-[#00FFA3]/5 flex justify-between items-center mt-2">
           <div>
              <h3 className="text-[#00FFA3] font-bold tracking-widest text-[11px] uppercase drop-shadow-[0_0_5px_rgba(0,255,163,0.3)]">OPERAR NA CONTA REAL</h3>
              <p className="text-[9px] text-slate-400 font-mono tracking-widest mt-1">Kill-switch global. Desligue para parar de executar ordens reais imediatamente.</p>
           </div>
           <div className="flex items-center gap-3 bg-black border border-slate-800 rounded-full pl-2 pr-3 py-1.5 cursor-pointer">
              <div className="w-[42px] h-[22px] rounded-full relative transition-colors duration-300 flex items-center shrink-0 border bg-black border-slate-700">
                 <div className="absolute w-4 h-4 rounded-full bg-slate-500 transition-all duration-300 left-1 shadow-sm" />
              </div>
              <span className="text-[12px] font-black tracking-widest text-slate-500">OFF</span>
           </div>
        </div>
      </div>

      {/* AUTOMAÇÃO DE SINAIS EXTERNOS */}
      <div className="bg-[#0A0C16] border border-amber-500/20 rounded-xl p-6 shadow-xl flex flex-col gap-6">
        <div>
           <h2 className="text-[16px] font-black text-amber-500 tracking-widest uppercase mb-1 drop-shadow-[0_0_8px_rgba(245,158,11,0.5)] flex items-center gap-2">
             AUTOMAÇÃO DE SINAIS EXTERNOS
           </h2>
           <p className="text-[10px] text-slate-500 font-mono tracking-widest uppercase mt-2 font-bold">QUANDO UM SINAL ENTRAR PELO WEBHOOK, O SISTEMA ABRE OPERAÇÃO NOS MODOS ATIVOS ABAIXO</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Switch 
            label="AUTOMÁTICO • REAL" 
            checked={state.cfg.autoReal} 
            onChange={(v: boolean) => updateCfg('autoReal', v)}
            className="border-slate-800 bg-[#050510]"
          />
          <Switch 
            label="AUTOMÁTICO • TESTE A (MOTOR A)" 
            checked={state.cfg.autoSimA} 
            onChange={(v: boolean) => updateCfg('autoSimA', v)}
            className="border-slate-800 bg-[#050510]"
          />
          <Switch 
            label="AUTOMÁTICO • TESTE B (TRADINGVIEW)" 
            checked={state.cfg.autoSimB} 
            onChange={(v: boolean) => updateCfg('autoSimB', v)}
            className="border-slate-800 bg-[#050510]"
          />
          <Switch 
            label="AUTOMÁTICO • TESTE C (NOVO MOTOR)" 
            checked={state.cfg.autoSimC || false} 
            onChange={(v: boolean) => updateCfg('autoSimC', v)}
            className="border-slate-800 bg-[#050510]"
          />
        </div>

        <div className="border border-[#00FFA3]/30 rounded-xl p-5 bg-[#00FFA3]/5">
           <h3 className="text-[#00FFA3] font-bold tracking-widest text-[10px] uppercase mb-4 flex items-center gap-2">
             <div className="w-2.5 h-2.5 rounded-full border border-[#00FFA3] flex items-center justify-center"><div className="w-1.5 h-1.5 bg-[#00FFA3] rounded-full"></div></div>
             SAÍDA PARA OPERAÇÕES REAIS AUTOMÁTICAS
           </h3>

           <div className="flex flex-col md:flex-row gap-4 mb-6">
              <label className={cn(
                  "flex items-start p-4 rounded-xl cursor-pointer flex-1 transition-all border", 
                  state.cfg.estrategiaReal === 'A' ? "border-[#00FFA3] bg-[#00FFA3]/10 text-white" : "border-slate-800 bg-black text-slate-400 hover:border-slate-600"
              )}>
                 <div className="flex items-center justify-center w-4 h-4 rounded-full border border-[#00FFA3] mt-1 mr-3 flex-shrink-0">
                    {state.cfg.estrategiaReal === 'A' && <div className="w-2 h-2 rounded-full bg-[#00FFA3]" />}
                 </div>
                 <div className="flex flex-col gap-1">
                    <span className="font-bold text-[11px] tracking-widest uppercase">SAÍDA ESTRATÉGIA A (PADRÃO GLOBAL)</span>
                    <span className="text-[10px] text-slate-300 font-mono tracking-widest mt-1">SEGURA ATÉ ALVO 100% • SL DE -25% (SAÍDA PADRONIZADA DE TODOS OS MOTORES)</span>
                 </div>
              </label>

              <label className={cn(
                  "flex items-start p-4 rounded-xl cursor-pointer flex-1 transition-all border", 
                  state.cfg.estrategiaReal === 'B' ? "border-[#00FFA3] bg-[#00FFA3]/10 text-white" : "border-slate-800 bg-black text-slate-400 hover:border-slate-600"
              )}>
                 <div className="flex items-center justify-center w-4 h-4 rounded-full border border-slate-600 mt-1 mr-3 flex-shrink-0">
                    {state.cfg.estrategiaReal === 'B' && <div className="w-2 h-2 rounded-full bg-[#00FFA3]" />}
                 </div>
                 <div className="flex flex-col gap-1">
                    <span className="font-bold text-[11px] tracking-widest uppercase text-slate-600">ESTRATÉGIA B (SAÍDA B DESATIVADA)</span>
                    <span className="text-[10px] text-slate-600 font-mono tracking-widest mt-1">SISTEMA RECONFIGURADO: REGRAS DE SAÍDA ALINHADAS À ESTRATÉGIA A</span>
                    <span className="text-[9px] text-slate-500 font-bold uppercase mt-2 flex items-center gap-1.5"><Power className="w-3 h-3" /> COMPORTAMENTO UNIFICADO À ESTRATÉGIA A</span>
                 </div>
              </label>
           </div>

           <div className="flex flex-col gap-2 mt-4">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 <Settings2 className="w-3.5 h-3.5 text-slate-500" /> LIMITE DE OPERAÇÕES REAIS SIMULTÂNEAS
              </span>
              <div className="flex items-center gap-2 border border-slate-800 bg-black rounded-lg p-1 shrink-0 h-[52px]">
                 <input 
                    type="number" 
                    value={state.cfg.maxAutoReal} 
                    onChange={e => updateCfg('maxAutoReal', parseInt(e.target.value) || 0)}
                    className="flex-1 min-w-0 w-full bg-transparent border-none text-[15px] pl-3 font-bold text-white focus:outline-none font-mono"
                 />
                 <button className="bg-[#00FFA3] hover:bg-[#00FFA3]/80 text-black px-6 h-full mr-0.5 rounded-md font-black uppercase tracking-widest text-[10px] transition-colors shrink-0">
                    SALVAR
                 </button>
              </div>
              <span className="text-[9px] text-slate-500 font-mono tracking-widest uppercase mt-1">QUANDO O NÚMERO DE OPERAÇÕES REAIS ABERTAS ATINGIR ESSE LIMITE, NOVOS SINAIS SERÃO IGNORADOS APENAS NO MODO REAL.</span>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 pt-2">
           <div className="flex flex-col gap-2">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 $ MARGEM REAL (US$)
              </span>
              <div className="flex items-center gap-2 border border-slate-800 bg-black rounded-lg p-1 shrink-0 h-[52px]">
                 <input 
                    type="number" 
                    value={state.cfg.margemPadrao} 
                    onChange={e => updateCfg('margemPadrao', parseFloat(e.target.value) || 0)}
                    className="flex-1 min-w-0 w-full bg-transparent border-none text-[15px] pl-3 font-bold text-white focus:outline-none font-mono"
                 />
                 <button className="bg-amber-500 hover:bg-amber-400 text-black px-4 lg:px-6 h-full mr-0.5 rounded-md font-black uppercase tracking-widest text-[10px] transition-colors shrink-0">
                    SALVAR
                 </button>
              </div>
           </div>

           <div className="flex flex-col gap-2">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 💵 MARGEM SIMULADOR
              </span>
              <div className="flex items-center gap-2 border border-slate-800 bg-black rounded-lg p-1 shrink-0 h-[52px]">
                 <input 
                    type="number" 
                    value={state.cfg.margemSimu} 
                    onChange={e => updateCfg('margemSimu', parseFloat(e.target.value) || 0)}
                    className="flex-1 min-w-0 w-full bg-transparent border-none text-[15px] pl-3 font-bold text-white focus:outline-none font-mono"
                 />
                 <button className="bg-amber-500 hover:bg-amber-400 text-black px-4 lg:px-6 h-full mr-0.5 rounded-md font-black uppercase tracking-widest text-[10px] transition-colors shrink-0">
                    SALVAR
                 </button>
              </div>
           </div>
           
           <div className="flex flex-col gap-2">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 ⤤ ALAVANCAGEM (X)
              </span>
              <div className="flex items-center gap-2 border border-slate-800 bg-black rounded-lg p-1 shrink-0 h-[52px]">
                 <input 
                    type="number" 
                    value={state.cfg.alavPadrao} 
                    onChange={e => updateCfg('alavPadrao', parseInt(e.target.value) || 0)}
                    className="flex-1 min-w-0 w-full bg-transparent border-none text-[15px] pl-3 font-bold text-white focus:outline-none font-mono"
                 />
                 <button className="bg-amber-500 hover:bg-amber-400 text-black px-4 lg:px-6 h-full mr-0.5 rounded-md font-black uppercase tracking-widest text-[10px] transition-colors shrink-0">
                    SALVAR
                 </button>
              </div>
           </div>

           <div className="flex flex-col gap-2">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 🔀 JUROS COMPOSTOS
              </span>
              <div className="flex items-center justify-between gap-4 px-5 border border-slate-800 rounded-lg bg-[#050510] h-[52px] shrink-0">
                  <span className="font-bold tracking-widest text-[11px] uppercase text-slate-500 font-mono flex-1">
                    STATUS
                  </span>
                  <div className="flex items-center gap-3">
                     <div className="w-[42px] h-[22px] rounded-full relative transition-colors duration-300 flex items-center shrink-0 cursor-pointer border bg-cyan-500 border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                       <div className="absolute w-4 h-4 rounded-full bg-white transition-all duration-300 drop-shadow-md right-1" />
                     </div>
                     <span className="text-[10px] font-black uppercase tracking-widest w-6 text-cyan-400">ON</span>
                  </div>
              </div>
           </div>

           <div className="flex flex-col gap-2">
              <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase flex items-center gap-1.5">
                 ⚡ LIMITE DE VOLATILIDADE (X)
              </span>
              <div className="flex items-center gap-2 border border-slate-800 bg-black rounded-lg p-1 shrink-0 h-[52px]">
                 <input 
                    type="number" 
                    step="0.1"
                    value={state.cfg.volatilityThreshold || 2.5} 
                    onChange={e => updateCfg('volatilityThreshold', parseFloat(e.target.value) || 2.5)}
                    className="flex-1 min-w-0 w-full bg-transparent border-none text-[15px] pl-3 font-bold text-white focus:outline-none font-mono"
                 />
                 <button className="bg-amber-500 hover:bg-amber-400 text-black px-4 lg:px-6 h-full mr-0.5 rounded-md font-black uppercase tracking-widest text-[10px] transition-colors shrink-0">
                    SALVAR
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

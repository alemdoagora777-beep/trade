import React, { useState, useEffect, useRef } from 'react';
import { BotState } from '../types.js';
import { Key, Shield, Info, CheckCircle2, XCircle, Loader2, Save, RefreshCw, AlertTriangle, RotateCcw, ShieldAlert, Bell } from 'lucide-react';
import { cn } from '../lib/utils.js';
import { motion } from 'motion/react';

export function SettingsView({ state }: { state: BotState }) {
  const [cfg, setCfg] = useState(state.cfg);
  const [saving, setSaving] = useState(false);
  const [testingBinance, setTestingBinance] = useState(false);
  const [testingTelegram, setTestingTelegram] = useState(false);
  const [binanceStatus, setBinanceStatus] = useState<null | { ok: boolean, msg: string }>(null);
  const [telegramStatus, setTelegramStatus] = useState<null | { ok: boolean, msg: string }>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [localRsiAlertTesting, setLocalRsiAlertTesting] = useState(false);
  
  const hasRealtimeRsiAlert = !!(state.logs && state.logs.slice(0, 3).some(log => log.includes("ALERTA RSI EXTREMO")));
  const isAlertActive = hasRealtimeRsiAlert || localRsiAlertTesting;
  
  const lastSyncedCfgRef = useRef(state.cfg);

  useEffect(() => {
    if (JSON.stringify(state.cfg) !== JSON.stringify(lastSyncedCfgRef.current)) {
      setCfg(state.cfg);
      lastSyncedCfgRef.current = state.cfg;
    }
  }, [state.cfg]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.type === 'number' ? parseFloat(e.target.value) : e.target.value;
    setCfg({ ...cfg, [e.target.name]: value });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg)
      });
      alert('Configurações salvas com sucesso!');
    } catch(e) {
      console.error(e);
      alert('Erro ao salvar.');
    } finally {
      setSaving(false);
    }
  };

  const handleResetState = async () => {
    const confirmReset = window.confirm("🚨 IMPORTANTE: Tem certeza que deseja resetar TODA a memória e dados do robô?\n\nIsso irá limpar posições abertas do simulador, o histórico de operações fechadas, os alertas de risco e todos os logs ao vivo, voltando o saldo simulado para $100.00.\n\nSuas configurações (chaves de API Binance, tokens de Telegram e limites de risco) serão mantidas perfeitamente.");
    if (!confirmReset) return;
    
    setResetting(true);
    try {
      const res = await fetch('/api/reset-state', {
        method: 'POST'
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Servidor retornou resposta que não é JSON (possível falha de roteamento ou reinício do servidor).');
      }
      const data = await res.json();
      if (data.success) {
        alert('🔄 Memória do robô limpa e reiniciada com sucesso! O sistema recomeçará agora.');
        window.location.reload();
      } else {
        alert('Erro ao tentar resetar o estado.');
      }
    } catch (e: any) {
      console.error(e);
      alert('Erro de conexão ao solicitar reset de estado.');
    } finally {
      setResetting(false);
    }
  };

  const testBinance = async () => {
    setTestingBinance(true);
    setBinanceStatus(null);
    try {
      const res = await fetch('/api/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'binance', key: cfg.binanceKey, secret: cfg.binanceSecret })
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Servidor retornou resposta que não é JSON. Aguarde o servidor completar a inicialização.');
      }
      const data = await res.json();
      setBinanceStatus({ ok: data.ok, msg: data.msg });
    } catch(e: any) {
      setBinanceStatus({ ok: false, msg: e.message });
    } finally {
      setTestingBinance(false);
    }
  };

  const testTelegram = async () => {
    setTestingTelegram(true);
    setTelegramStatus(null);
    try {
      const res = await fetch('/api/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'telegram', token1: cfg.tgTokenArmado, token2: cfg.tgTokenExecutado })
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Servidor retornou resposta que não é JSON. Aguarde o servidor completar a inicialização.');
      }
      const data = await res.json();
      setTelegramStatus({ ok: data.ok, msg: data.msg });
    } catch(e: any) {
      setTelegramStatus({ ok: false, msg: e.message });
    } finally {
      setTestingTelegram(false);
    }
  };

  const testBinanceRef = useRef(testBinance);
  const testTelegramRef = useRef(testTelegram);

  useEffect(() => {
    testBinanceRef.current = testBinance;
    testTelegramRef.current = testTelegram;
  });

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (autoRefresh) {
      testBinanceRef.current();
      testTelegramRef.current();
      interval = setInterval(() => {
        testBinanceRef.current();
        testTelegramRef.current();
      }, 30000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh]);

  return (
    <div className="flex flex-col gap-6 w-full max-w-4xl mx-auto h-full text-slate-300 pb-10 overflow-y-auto">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-widest uppercase mb-1">CHAVES & TOKENS</h1>
          <p className="text-xs text-slate-500 font-mono">Gerenciamento de credenciais e conexões externas</p>
        </div>
        <button
           onClick={() => setAutoRefresh(!autoRefresh)}
           className={cn("px-4 py-2 rounded-xl text-[10px] font-black tracking-widest uppercase flex items-center gap-2 transition-all border shadow-[0_0_10px_rgba(6,182,212,0.1)]", autoRefresh ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/50" : "bg-[#050510] text-slate-500 border-slate-700/50 hover:border-slate-500 hover:text-slate-300")}
        >
           <RefreshCw className={cn("w-4 h-4", autoRefresh && "animate-spin")} />
           AUTO-REFRESH (30S)
        </button>
      </div>

      <div className="bg-[#111326] border border-cyan-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-700/50">
           <Shield className="w-5 h-5 text-cyan-500" />
           <h2 className="text-lg font-black text-white tracking-widest uppercase">API BINANCE</h2>
        </div>
        
        <div className="flex flex-col gap-4">
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">API KEY</label>
              <input 
                 type="text" 
                 name="binanceKey"
                 value={cfg.binanceKey} 
                 onChange={handleChange}
                 placeholder="Sua Binance API Key"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">API SECRET</label>
              <input 
                 type="password" 
                 name="binanceSecret"
                 value={cfg.binanceSecret} 
                 onChange={handleChange}
                 placeholder="Sua Binance API Secret"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           
           <div className="flex justify-between items-center mt-2">
              <button 
                 onClick={testBinance} 
                 disabled={testingBinance}
                 className="bg-[#050510] border border-cyan-500/50 text-cyan-400 hover:bg-cyan-900/50 px-4 py-2 rounded-lg font-black text-[10px] tracking-widest uppercase flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                 {testingBinance ? <Loader2 className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                 Testar Conexão Binance
              </button>
              
              {binanceStatus && (
                 <div className={cn("text-xs font-mono font-bold flex items-center gap-2", binanceStatus.ok ? "text-[#00FFA3]" : "text-rose-500")}>
                    <div className="relative flex h-3 w-3 items-center justify-center">
                       <span className={cn("animate-ping absolute inline-flex h-full w-full rounded-full opacity-75", binanceStatus.ok ? "bg-[#00FFA3]" : "bg-rose-500")}></span>
                       <span className={cn("relative inline-flex rounded-full h-2 w-2", binanceStatus.ok ? "bg-[#00FFA3]" : "bg-rose-500")}></span>
                    </div>
                    {binanceStatus.ok ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                    <div className="flex flex-col items-start gap-1">
                       <span>{binanceStatus.ok ? "Conectado" : "Falha na Conexão"}</span>
                       {!binanceStatus.ok && (
                          <span className="text-[9px] bg-rose-500/10 border border-rose-500/30 px-1.5 py-0.5 rounded text-rose-400 font-medium max-w-[200px] leading-tight block whitespace-normal">
                             {binanceStatus.msg}
                          </span>
                       )}
                    </div>
                 </div>
              )}
           </div>
        </div>
      </div>

      <div className="bg-[#111326] border border-cyan-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-700/50">
           <Info className="w-5 h-5 text-cyan-500" />
           <h2 className="text-lg font-black text-white tracking-widest uppercase">TELEGRAM BOTS</h2>
        </div>
        
        <div className="flex flex-col gap-4">
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">TOKEN (GATILHO ARMADO)</label>
              <input 
                 type="text" 
                 name="tgTokenArmado"
                 value={cfg.tgTokenArmado || ''} 
                 onChange={handleChange}
                 placeholder="Token do Bot Telegram (ex: 8667082024:AAEMyr...)"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">TOKEN (ORDEM EXECUTADA)</label>
              <input 
                 type="text" 
                 name="tgTokenExecutado"
                 value={cfg.tgTokenExecutado || ''} 
                 onChange={handleChange}
                 placeholder="Token do Bot Telegram (ex: 8888159023:AAHj5n...)"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">CHAT ID</label>
              <input 
                 type="text" 
                 name="tgChatId"
                 value={cfg.tgChatId || ''} 
                 onChange={handleChange}
                 placeholder="ID do Chat/Grupo (ex: 7216099531)"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>

           <div className="flex justify-between items-center mt-2">
              <button 
                 onClick={testTelegram} 
                 disabled={testingTelegram}
                 className="bg-[#050510] border border-cyan-500/50 text-cyan-400 hover:bg-cyan-900/50 px-4 py-2 rounded-lg font-black text-[10px] tracking-widest uppercase flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                 {testingTelegram ? <Loader2 className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                 Testar Conexão Telegram
              </button>
              
              {telegramStatus && (
                 <div className={cn("text-xs font-mono font-bold flex items-center gap-2 max-w-sm text-right", telegramStatus.ok ? "text-[#00FFA3]" : "text-rose-500")}>
                    <div className="relative flex h-3 w-3 shrink-0 items-center justify-center">
                       <span className={cn("animate-ping absolute inline-flex h-full w-full rounded-full opacity-75", telegramStatus.ok ? "bg-[#00FFA3]" : "bg-rose-500")}></span>
                       <span className={cn("relative inline-flex rounded-full h-2 w-2", telegramStatus.ok ? "bg-[#00FFA3]" : "bg-rose-500")}></span>
                    </div>
                    {telegramStatus.ok ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <XCircle className="w-4 h-4 shrink-0" />}
                    <div className="flex flex-col items-end gap-1 text-right">
                       <span>{telegramStatus.ok ? "Conectado" : "Falha na Conexão"}</span>
                       {!telegramStatus.ok && (
                          <span className="text-[9px] bg-rose-500/10 border border-rose-500/30 px-1.5 py-0.5 rounded text-rose-400 font-medium max-w-[200px] leading-tight block whitespace-normal">
                             {telegramStatus.msg}
                          </span>
                       )}
                    </div>
                 </div>
              )}
           </div>
        </div>
      </div>
      
      <div className="bg-[#111326] border border-cyan-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-700/50">
           <Save className="w-5 h-5 text-cyan-500" />
           <h2 className="text-lg font-black text-white tracking-widest uppercase">GESTÃO DE RISCO E METAS</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">META DIÁRIA (US$)</label>
              <input 
                 type="number" 
                 name="dailyProfitGoal"
                 value={cfg.dailyProfitGoal || ''} 
                 onChange={handleChange}
                 placeholder="Ex: 50"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
              <p className="text-[10px] text-slate-500 italic mt-1 relative ml-1">Define o alvo de lucro em dólares (US$) para o dia (utilizado no Cockpit).</p>
           </div>
           
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">LIMITE DE PERDA DIÁRIA (US$)</label>
              <input 
                 type="number" 
                 name="dailyLossLimit"
                 value={cfg.dailyLossLimit || ''} 
                 onChange={handleChange}
                 placeholder="Ex: 20"
                 className="bg-[#050510] border border-rose-800 hover:border-rose-600 focus:border-rose-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(244,63,94,0.1)]"
              />
              <p className="text-[10px] text-slate-500 italic mt-1 relative ml-1">Alerta emitido se a perda diária total (PNL) exceder (em negativo) este valor.</p>
           </div>
           
           <div className="flex flex-col gap-1.5 mt-2">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">LIMITE DE DRAWDOWN (%) Risco Máximo</label>
              <input 
                 type="number" 
                 name="drawdownThreshold"
                 value={cfg.drawdownThreshold || ''} 
                 onChange={handleChange}
                 placeholder="Ex: 5"
                 className="bg-[#050510] border border-rose-800 hover:border-rose-600 focus:border-rose-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(244,63,94,0.1)]"
              />
              <p className="text-[10px] text-slate-500 italic mt-1 relative ml-1">Ativa um alerta visual crítico no Cockpit se o drawdown exceder este percentual em relação ao topo histórico da banca.</p>
           </div>
           
           <div className="flex flex-col gap-1.5 mt-2">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">MÁX. PERDAS CONSECUTIVAS</label>
              <input 
                 type="number" 
                 name="maxConsecutiveLosses"
                 value={cfg.maxConsecutiveLosses || ''} 
                 onChange={handleChange}
                 placeholder="Ex: 3"
                 className="bg-[#050510] border border-amber-800 hover:border-amber-600 focus:border-amber-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(245,158,11,0.1)]"
              />
              <p className="text-[10px] text-slate-500 italic mt-1 relative ml-1">Aciona alerta na log se o robô encadear trades seguidos com loss (Hit rate despencando).</p>
           </div>
        </div>
      </div>

      <motion.div 
         id="rsi-filter-settings" 
         className={cn(
           "bg-[#111326] border rounded-2xl p-6 shadow-xl flex flex-col gap-6 transition-all duration-300",
           isAlertActive 
             ? "border-rose-500 bg-[#1a0a14]" 
             : "border-emerald-800/30"
         )}
         animate={
           isAlertActive 
             ? {
                 scale: [1, 1.015, 1],
                 boxShadow: [
                   "0 0 15px rgba(244, 63, 94, 0.15)",
                   "0 0 35px rgba(244, 63, 94, 0.45)",
                   "0 0 15px rgba(244, 63, 94, 0.15)"
                 ],
                 borderColor: [
                   "rgba(244, 63, 94, 0.3)",
                   "rgba(244, 63, 94, 0.95)",
                   "rgba(244, 63, 94, 0.3)"
                 ]
               }
             : {}
         }
         transition={{
           duration: 1.6,
           repeat: Infinity,
           ease: "easeInOut"
         }}
      >
        <div className="flex items-center gap-3 pb-4 border-b border-slate-700/50">
           <Save className="w-5 h-5 text-emerald-500" />
           <h2 className="text-lg font-black text-white tracking-widest uppercase">FILTRO TÉCNICO & ALERTAS DE RSI</h2>
        </div>
        <div className="flex flex-col gap-4">
           <div className="flex items-center justify-between pb-2 border-b border-slate-800">
               <div>
                   <h3 className="text-emerald-400 font-bold text-xs tracking-widest uppercase">LIGAR FILTRO RSI</h3>
                   <p className="text-[10px] text-slate-500 mt-1 max-w-[250px]">Ignora entradas long se RSI &gt; Sobrecomprado e entradas short se RSI &lt; Sobrevendido.</p>
               </div>
               <button 
                  onClick={() => setCfg({...cfg, useRsiFilter: !cfg.useRsiFilter})}
                  className={cn("w-12 h-6 rounded-full transition-colors relative", cfg.useRsiFilter ? "bg-emerald-500" : "bg-slate-700")}
               >
                  <div className={cn("w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all", cfg.useRsiFilter ? "left-6" : "left-0.5")} />
               </button>
           </div>
           
           {cfg.useRsiFilter && (
               <div className="grid grid-cols-2 gap-4 pb-2 border-b border-slate-800/50">
                   <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">SOBRECOMPRADO (EX: 70 OU 80)</label>
                      <input 
                         type="number" 
                         name="rsiOverbought"
                         value={cfg.rsiOverbought || 80} 
                         onChange={handleChange}
                         className="bg-[#050510] border border-emerald-800 hover:border-emerald-600 focus:border-emerald-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                      />
                   </div>
                   <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">SOBREVENDIDO (EX: 30 OU 20)</label>
                      <input 
                         type="number" 
                         name="rsiOversold"
                         value={cfg.rsiOversold || 20} 
                         onChange={handleChange}
                         className="bg-[#050510] border border-emerald-800 hover:border-emerald-600 focus:border-emerald-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                      />
                   </div>
               </div>
           )}

           {/* LIVE COCKPIT ALERTS SETTINGS */}
           <div className="flex flex-col gap-4 mt-2">
               <h3 className="text-xs font-bold text-slate-300 tracking-wider uppercase border-b border-slate-800/40 pb-1">Configuração de Alerta de Extremos</h3>
               
               <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center pb-2 border-b border-slate-800">
                   <div>
                       <h4 className="text-[#00FFA3] font-bold text-[11px] tracking-widest uppercase">ALERTAS SONOROS (BEEPS)</h4>
                       <p className="text-[10px] text-slate-400 mt-0.5">Toca avisos sonoros sintetizados no navegador imediatamente ao tocar extremos.</p>
                   </div>
                   <button 
                      onClick={() => setCfg({...cfg, enableRsiAudioAlert: !cfg.enableRsiAudioAlert})}
                      className={cn("w-12 h-6 rounded-full transition-colors relative", cfg.enableRsiAudioAlert ? "bg-emerald-500" : "bg-slate-700")}
                   >
                      <div className={cn("w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all", cfg.enableRsiAudioAlert ? "left-6" : "left-0.5")} />
                   </button>
               </div>

               <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center pb-2 border-b border-slate-800">
                   <div>
                       <h4 className="text-cyan-400 font-bold text-[11px] tracking-widest uppercase">ALERTAS VISUAIS DE DESTAQUE</h4>
                       <p className="text-[10px] text-slate-400 mt-0.5">Ativa flashs coloridos e popups imediatos no painel principal ao detectar anomalias de RSI.</p>
                       
                       {/* Interactive local test button */}
                       <button
                          id="btn-test-rsi-pulse"
                          onClick={(e) => {
                             e.preventDefault();
                             setLocalRsiAlertTesting(prev => !prev);
                          }}
                          className={cn(
                             "mt-2 text-[9px] font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 border tracking-wider font-mono",
                             localRsiAlertTesting 
                               ? "bg-rose-500/20 text-rose-400 border-rose-500/50 animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.2)]" 
                               : "bg-[#060812] text-slate-400 border-slate-800 hover:text-white hover:border-slate-700"
                          )}
                       >
                          <ShieldAlert className="w-3.5 h-3.5" />
                          {localRsiAlertTesting ? "PARAR SIMULAÇÃO DE ALERTA" : "SIMULAR ALERTA DE EXTREMO (TESTAR PULSAÇÃO)"}
                       </button>
                   </div>
                   <button 
                      onClick={() => setCfg({...cfg, enableRsiVisualAlert: !cfg.enableRsiVisualAlert})}
                      className={cn("w-12 h-6 rounded-full transition-colors relative", cfg.enableRsiVisualAlert ? "bg-[#00FFA3]" : "bg-slate-700")}
                   >
                      <div className={cn("w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all", cfg.enableRsiVisualAlert ? "left-6" : "left-0.5")} />
                   </button>
               </div>

               <div className="flex flex-col gap-1.5 mt-1">
                   <label className="text-[10px] font-bold text-slate-550 tracking-widest uppercase">Moedas Monitoradas no Live Radar (Separadas por Vírgula)</label>
                   <input 
                      type="text" 
                      name="rsiMonitoredCoins"
                      value={cfg.rsiMonitoredCoins || 'BTC, ETH, SOL, XRP, ADA, BNB'} 
                      onChange={(e) => setCfg({ ...cfg, rsiMonitoredCoins: e.target.value })}
                      className="bg-[#050510] border border-emerald-800 hover:border-emerald-600 focus:border-emerald-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                      placeholder="Ex: BTC, ETH, SOL, XRP"
                   />
                   <p className="text-[10px] text-slate-550 italic mt-0.5">Define a fila de ativos cuja força relativa (RSI) é atualizada em tempo real na aba Cockpit.</p>
               </div>
           </div>
        </div>
      </motion.div>

      <div className="bg-[#111326] border border-cyan-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-700/50">
           <Info className="w-5 h-5 text-cyan-500" />
           <h2 className="text-lg font-black text-white tracking-widest uppercase">WEBHOOKS (MOTOR EXTERNO)</h2>
        </div>
        
        <div className="flex flex-col gap-4">
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">LOVABLE WEBHOOK URL</label>
              <input 
                 type="text" 
                 name="lovableWebhookUrl"
                 value={cfg.lovableWebhookUrl || ''} 
                 onChange={handleChange}
                 placeholder="URL de ingestão (ex: https://...)"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           
           <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">LOVABLE WEBHOOK SECRET</label>
              <input 
                 type="password" 
                 name="lovableWebhookSecret"
                 value={cfg.lovableWebhookSecret || ''} 
                 onChange={handleChange}
                 placeholder="Secret Key do formato (ex: 922138...)"
                 className="bg-[#050510] border border-cyan-800 hover:border-cyan-600 focus:border-cyan-400 rounded-lg px-4 py-3 text-xs font-mono text-white tracking-wider focus:outline-none transition-colors w-full shadow-[0_0_10px_rgba(6,182,212,0.1)]"
              />
           </div>
           
           <div className="flex flex-col gap-1.5 mt-2">
              <label className="text-[10px] font-bold text-slate-500 tracking-widest uppercase text-pink-500">SEU ENDPOINT PARA O TRADINGVIEW</label>
              <input 
                 type="text" 
                 readOnly
                 value={`https://<SUA-URL-AQUI>/webhook`} 
                 className="bg-[#050510]/50 border border-pink-500/30 text-pink-400 rounded-lg px-4 py-3 text-xs font-mono tracking-wider focus:outline-none w-full"
              />
              <p className="text-[10px] text-slate-500 italic mt-1 relative ml-1">Configure essa URL nos alertas do TV.</p>
           </div>
        </div>
      </div>

      {/* MAINTENANCE / RESET BLOCK */}
      <div className="bg-[#111326] border border-rose-800/30 rounded-2xl p-6 shadow-xl flex flex-col gap-6 mb-6">
        <div className="flex items-center gap-3 pb-4 border-b border-rose-500/20">
           <AlertTriangle className="w-5 h-5 text-rose-500" />
           <h2 className="text-lg font-black text-rose-500 tracking-widest uppercase">LIMPEZA E MANUTENÇÃO DO SISTEMA</h2>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
           <div>
               <h3 className="text-white font-black text-xs tracking-widest uppercase">Zerar Memória do Robô</h3>
               <p className="text-[10px] text-slate-400 italic mt-1 max-w-xl text-left">
                  Deleta todo o histórico de operações fechadas, remove posições abertas simuladas, limpa logs ao vivo e redefine os saldos simulados para $100.00.
                  <span className="text-rose-400 font-bold block mt-1">⚠️ Obs: Chaves da API Binance, tokens de Telegram e limites de risco serão totalmente preservados para seu conforto!</span>
               </p>
           </div>
           <button 
              onClick={handleResetState}
              disabled={resetting}
              className="bg-[#2a0e16] hover:bg-[#4c1221] border border-rose-500/30 hover:border-rose-500 text-rose-400 hover:text-white px-6 py-3 rounded-xl font-black text-[10px] tracking-widest uppercase flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(244,63,94,0.15)] active:scale-95 duration-150 shrink-0"
           >
              {resetting ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
              Reiniciar Bancas e Histórico
           </button>
        </div>
      </div>

      <div className="flex justify-end sticky bottom-0 bg-[#050510]/80 backdrop-blur-md p-4 rounded-xl border border-cyan-500/20 shadow-xl">
         <button 
           onClick={handleSave} 
           disabled={saving}
           className="bg-cyan-500 text-black hover:bg-cyan-400 px-8 py-3 rounded-xl font-black text-sm tracking-widest uppercase flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)]"
         >
           {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
           Salvar Configurações
         </button>
      </div>

    </div>
  );
}

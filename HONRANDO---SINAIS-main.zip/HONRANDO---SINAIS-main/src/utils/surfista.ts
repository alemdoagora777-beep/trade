import { calculateEMA, calculateSMA } from './indicators';

export interface SurfistaConfig {
    margem: number;
    alavancagem: number;
    gatilho_surf: number;
    dist_stop: number;
    gatilho_be: number;
    protecao_be: number;
    stop_fixo: number;
}

function calculateTrueRange(data: any[]) {
    const tr = [0];
    for (let i = 1; i < data.length; i++) {
        const high = data[i].high;
        const low = data[i].low;
        const prevClose = data[i - 1].close;
        tr.push(Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose)));
    }
    return tr;
}

function calculateRMA(data: number[], period: number) {
    const result = new Array(data.length).fill(null);
    let sum = 0;
    for (let i = 0; i < period; i++) sum += data[i];
    result[period - 1] = sum / period;
    for (let i = period; i < data.length; i++) {
        result[i] = (result[i - 1] * (period - 1) + data[i]) / period;
    }
    return result;
}

export function calculateSupertrend(data: any[], factor: number, period: number) {
    const tr = calculateTrueRange(data);
    const atr = calculateRMA(tr, period);

    const result = new Array(data.length).fill(null);
    const dir = new Array(data.length).fill(1); // 1 = down, -1 = up

    let finalUpper = 0;
    let finalLower = 0;

    for (let i = period; i < data.length; i++) {
        const hl2 = (data[i].high + data[i].low) / 2;
        const basicUpper = hl2 + (factor * atr[i]);
        const basicLower = hl2 - (factor * atr[i]);

        const prevClose = data[i - 1].close;
        const prevFinalUpper = finalUpper;
        const prevFinalLower = finalLower;

        finalUpper = basicUpper < prevFinalUpper || prevClose > prevFinalUpper ? basicUpper : prevFinalUpper;
        finalLower = basicLower > prevFinalLower || prevClose < prevFinalLower ? basicLower : prevFinalLower;

        let currentDir = dir[i - 1];
        let st = 0;

        if (currentDir === 1 && data[i].close > finalUpper) {
            currentDir = -1;
        } else if (currentDir === -1 && data[i].close < finalLower) {
            currentDir = 1;
        }

        if (currentDir === -1) {
            st = finalLower;
        } else {
            st = finalUpper;
        }

        dir[i] = currentDir;
        result[i] = st;
    }

    return { st: result, dir };
}

export function runSurfistaEngine(data: any[], config: SurfistaConfig) {
    if (data.length === 0) return null;

    const close = data.map(d => d.close);
    const open = data.map(d => d.open);
    const volume = data.map(d => d.volume);

    // Using SMA for 8, 21 as per PineScript
    const sma8 = calculateSMA(close, 8);
    const sma21 = calculateSMA(close, 21);
    const volMedio = calculateSMA(volume, 20);
    const { st, dir } = calculateSupertrend(data, 3, 10);
    
    // EMA 9 and 21 for general trend (fallback for BTC check)
    const ema9 = calculateEMA(close, 9);
    const ema21 = calculateEMA(close, 21);

    let in_trade = false;
    let is_long = false;
    let entry_price = 0.0;
    let max_roi = 0.0;
    let total_pnl = 0.0;
    let wins = 0;
    let loss = 0;
    let historico: { text: string, color: string }[] = [];

    const markers: any[] = [];
    const sma8Line: any[] = [];
    const sma21Line: any[] = [];
    const stLine: any[] = [];
    
    let isWin = false;

    // We process each candle
    for (let i = 0; i < data.length; i++) {
        if (i >= 21) {
            sma8Line.push({ time: data[i].time, value: sma8[i] });
            sma21Line.push({ time: data[i].time, value: sma21[i] });
            stLine.push({ time: data[i].time, value: st[i], color: dir[i] === -1 ? '#00ff00' : '#ff0062' });
        }

        if (in_trade) {
            let current_roi = 0.0;
            let roi_minimo = 0.0;

            if (is_long) {
                current_roi = ((data[i].high - entry_price) / entry_price) * config.alavancagem * 100;
                roi_minimo = ((data[i].low - entry_price) / entry_price) * config.alavancagem * 100;
            } else {
                current_roi = ((entry_price - data[i].low) / entry_price) * config.alavancagem * 100;
                roi_minimo = ((entry_price - data[i].high) / entry_price) * config.alavancagem * 100;
            }

            if (current_roi > max_roi) max_roi = current_roi;

            let sair = false;
            let roi_saida = 0.0;
            let motivo = "";

            if (roi_minimo <= (config.stop_fixo * -1)) {
                sair = true;
                roi_saida = config.stop_fixo * -1;
                motivo = "STOP 🛑";
            } else if (max_roi >= config.gatilho_surf) {
                if (roi_minimo <= (max_roi - config.dist_stop)) {
                    sair = true;
                    roi_saida = max_roi - config.dist_stop;
                    motivo = "SURF 🏄";
                }
            } else if (max_roi >= config.gatilho_be) {
                if (roi_minimo <= config.protecao_be) {
                    sair = true;
                    roi_saida = config.protecao_be;
                    motivo = "PROT 🛡️";
                }
            }

            if (sair) {
                in_trade = false;
                let pnl = config.margem * (roi_saida / 100);
                total_pnl += pnl;

                isWin = pnl > 0;
                if (isWin) wins++; else loss++;

                const col = isWin ? "#00ff00" : "#ff0062";
                const isWinIcon = isWin ? "✅" : "❌";

                historico.unshift({ text: `${isWinIcon} ${motivo}: $${pnl.toFixed(2)}`, color: col });
                if (historico.length > 5) historico.pop();
            }
        }

        if (!in_trade && i > 25) {
            const vol_aprovado = volume[i] > volMedio[i];
            const longCond = open[i] > sma8[i] && open[i] > sma21[i] && dir[i] < 0 && dir[i - 1] > 0 && vol_aprovado;
            const shortCond = open[i] < sma8[i] && open[i] < sma21[i] && dir[i] > 0 && dir[i - 1] < 0 && vol_aprovado;

            if (longCond) {
                in_trade = true; is_long = true; entry_price = open[i]; max_roi = 0.0;
                markers.push({ time: data[i].time, position: 'belowBar', color: '#00ff00', shape: 'arrowUp', text: 'COMPRA ⚡', size: 2 });
            } else if (shortCond) {
                in_trade = true; is_long = false; entry_price = open[i]; max_roi = 0.0;
                markers.push({ time: data[i].time, position: 'aboveBar', color: '#ff0062', shape: 'arrowDown', text: 'VENDA ⚡', size: 2 });
            }
        }
    }

    const lastEma9 = ema9[ema9.length - 1];
    const lastEma21 = ema21[ema21.length - 1];
    const tendencia_geral = lastEma9 > lastEma21 ? "ALTA 🟢" : "BAIXA 🔴";

    // Volatility today
    const firstBar = data[0];
    const lastBar = data[data.length - 1];
    const vol_dia_pct = firstBar.open > 0 ? ((Math.max(...data.map(d=>d.high)) - Math.min(...data.map(d=>d.low))) / firstBar.open) * 100 : 0;
    
    // Testing period approximation
    const dias_teste = (lastBar.time - firstBar.time) / 86400;

    return {
        markers,
        sma8Line,
        sma21Line,
        stLine,
        tendencia_geral,
        vol_dia_pct,
        dias_teste,
        stats: {
            wins, loss, total_pnl, historico, in_trade, max_roi, entry_price, is_long
        }
    }
}

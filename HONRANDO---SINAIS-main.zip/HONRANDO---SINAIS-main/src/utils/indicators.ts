export function calculateEMA(data: number[], period: number): number[] {
  const k = 2 / (period + 1);
  let emaArray = new Array(data.length).fill(0);
  
  if (data.length === 0) return emaArray;
  
  let ema = data[0];
  emaArray[0] = ema;
  
  for (let i = 1; i < data.length; i++) {
    ema = data[i] * k + ema * (1 - k);
    emaArray[i] = ema;
  }
  
  return emaArray;
}

export function calculateMACD(data: {time: number, close: number}[]) {
  const closePrices = data.map(d => d.close);
  const ema12 = calculateEMA(closePrices, 12);
  const ema26 = calculateEMA(closePrices, 26);
  
  const macdLineData = new Array(data.length);
  for(let i = 0; i < data.length; i++) {
    macdLineData[i] = ema12[i] - ema26[i];
  }
  
  const signalLineValues = calculateEMA(macdLineData, 9);
  
  const result = [];
  for(let i = 0; i < data.length; i++) {
    result.push({
      time: data[i].time,
      macd: macdLineData[i],
      signal: signalLineValues[i],
      histogram: macdLineData[i] - signalLineValues[i],
    });
  }
  return result;
}

export function calculateSMA(data: number[], period: number): number[] {
  const result = new Array(data.length).fill(0);
  let sum = 0;
  for (let i = 0; i < data.length; i++) {
    sum += data[i];
    if (i >= period) {
      sum -= data[i - period];
    }
    if (i >= period - 1) {
      result[i] = sum / period;
    } else {
      result[i] = sum / (i + 1);
    }
  }
  return result;
}

export function calculatePSAR(
  data: { high: number; low: number; close: number }[],
  step = 0.02,
  maxStep = 0.2
): number[] {
  const psar = new Array(data.length).fill(0);
  if (data.length === 0) return psar;

  let isLong = true;
  let af = step;
  let ep = data[0].high;
  let sar = data[0].low;

  if (data.length > 1) {
    if (data[1].close < data[0].close) {
      isLong = false;
      ep = data[0].low;
      sar = data[0].high;
    }
  }

  psar[0] = sar;

  for (let i = 1; i < data.length; i++) {
    const prevSar = sar;
    sar = prevSar + af * (ep - prevSar);

    if (isLong) {
      const prevLow1 = data[i - 1].low;
      const prevLow2 = i > 1 ? data[i - 2].low : prevLow1;
      if (sar > prevLow1) sar = prevLow1;
      if (sar > prevLow2) sar = prevLow2;

      if (data[i].low < sar) {
        isLong = false;
        sar = ep;
        ep = data[i].low;
        af = step;
      } else {
        if (data[i].high > ep) {
          ep = data[i].high;
          af = Math.min(af + step, maxStep);
        }
      }
    } else {
      const prevHigh1 = data[i - 1].high;
      const prevHigh2 = i > 1 ? data[i - 2].high : prevHigh1;
      if (sar < prevHigh1) sar = prevHigh1;
      if (sar < prevHigh2) sar = prevHigh2;

      if (data[i].high > sar) {
        isLong = true;
        sar = ep;
        ep = data[i].high;
        af = step;
      } else {
        if (data[i].low < ep) {
          ep = data[i].low;
          af = Math.min(af + step, maxStep);
        }
      }
    }
    psar[i] = sar;
  }
  return psar;
}

export function calculateDonchianChannel(
  data: { high: number; low: number }[],
  period: number
) {
  const upper = new Array(data.length).fill(0);
  const lower = new Array(data.length).fill(0);
  const middle = new Array(data.length).fill(0);

  if (data.length === 0) return { upper, lower, middle };

  for (let i = 0; i < data.length; i++) {
    const start = Math.max(0, i - period + 1);
    let maxHigh = -Infinity;
    let minLow = Infinity;
    
    for (let j = start; j <= i; j++) {
      if (data[j].high > maxHigh) maxHigh = data[j].high;
      if (data[j].low < minLow) minLow = data[j].low;
    }
    
    upper[i] = maxHigh;
    lower[i] = minLow;
    middle[i] = (maxHigh + minLow) / 2;
  }

  return { upper, lower, middle };
}

